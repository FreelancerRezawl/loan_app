<?php
require __DIR__.'/auth.php';
?>
<!doctype html>
<html lang="bn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>WBLB Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --bg:#0f1222;
      --surface:#11152b;
      --panel:#151936;
      --card:#171b34;
      --text:#e9ecf1;
      --muted:#a9b2c7;
      --brand:#6c5ce7;
      --ok:#00c29a;
      --border:rgba(255,255,255,.08);
      --shadow:0 8px 24px rgba(0,0,0,.25);
      --radius:18px;
      --radius-lg:22px;

      /* dashboard tiles */
      --tile-yellow:#ffd451;
      --tile-white:#ffffff;
    }

    /* Reset-ish */
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0;
      font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
      color:var(--text);
      background:linear-gradient(145deg,#0d1020,#0b0f1c 60%,#0a0e19);
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    /* ====== LAYOUT ====== */
    .app{
      display:grid;
      grid-template-rows:auto 1fr;
      min-height:100dvh;
    }

    /* Topbar */
    .topbar{
      display:flex;align-items:center;justify-content:space-between;
      padding:12px 16px;
      background:rgba(15,18,34,.7);
      backdrop-filter: blur(10px);
      position:sticky;top:0;z-index:20;
      border-bottom:1px solid var(--border);
    }
    .brand{display:flex;align-items:center;gap:10px;font-weight:800}
    .brand-bubble{
      width:36px;height:36px;border-radius:50%;
      background:linear-gradient(45deg,var(--brand),var(--ok));
      display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;
      box-shadow:var(--shadow); font-size:14px;
    }
    .actions{display:flex;align-items:center;gap:10px}
    .iconbtn{
      width:38px;height:38px;border-radius:12px;border:none;cursor:pointer;
      display:flex;align-items:center;justify-content:center;
      background:#151935;color:#c8d0e6;
      box-shadow:inset 0 1px 0 rgba(255,255,255,.04), var(--shadow);
    }

    /* Main */
    .main{ padding:16px; }

    /* ====== SIDEBAR ====== */
    /* Mobile: drawer from RIGHT */
    .sidebar{
      position:fixed;inset:0 0 0 auto;
      width:min(82vw,320px);
      background:linear-gradient(180deg,#121736,#11152b);
      transform:translateX(100%);
      transition:transform .25s ease;
      z-index:30;color:#dfe5f8;border-left:1px solid var(--border);
      display:flex;flex-direction:column;
    }
    .sidebar.open{ transform:translateX(0); }
    .sidebar .brand{
      padding:16px;border-bottom:1px solid var(--border);
    }
    .nav{ padding:10px; display:flex; flex-direction:column; gap:6px; }
    .nav a{
      display:flex; align-items:center; gap:12px;
      padding:12px 12px; border-radius:12px; text-decoration:none;
      color:#dce3fb; font-weight:600; border:1px solid transparent;
    }
    .nav a i{ width:26px; text-align:center; }
    .nav a:hover, .nav a.active{
      background:#161b3d; border-color:var(--border);
    }

    /* Overlay (lives in footer) */
    .overlay{
      position:fixed; inset:0; background:rgba(0,0,0,.35);
      opacity:0; visibility:hidden; transition:.2s ease; z-index:25;
    }
    .overlay.show{ opacity:1; visibility:visible; }

    /* Desktop ≥ 992px: fixed LEFT sidebar, no overlay */
    @media (min-width: 992px){
      .app{
        grid-template-columns:260px 1fr;
        grid-template-rows:auto 1fr;
      }
      .sidebar{
        position:sticky; inset:auto; transform:none; width:auto; height:100dvh; z-index:5;
        grid-row:1 / span 2; grid-column:1; border-left:none; border-right:1px solid var(--border);
      }
      .topbar{ grid-column:2; }
      .main{ grid-column:2; padding:24px; }
      .overlay{ display:none; }
    }

    /* ====== DASHBOARD PIECES (for pages that need them) ====== */
    .hero{
      background:linear-gradient(145deg,#151b38,#121632 60%,#10142d);
      border:1px solid var(--border);
      border-radius:26px; padding:18px; box-shadow:var(--shadow);
      margin-bottom:14px;
    }
    .hero h1{margin:0 0 6px 0; font-size:22px}
    .muted{ color:var(--muted); font-size:14px }

    .quick{
      display:grid; gap:14px; grid-template-columns:1fr 1fr; margin:16px 0;
    }
    .tile{
      border-radius:22px; padding:16px; cursor:pointer; text-decoration:none;
      color:#0a0e19; box-shadow:var(--shadow); border:1px solid rgba(0,0,0,.05);
      display:flex; flex-direction:column; gap:6px; min-height:120px;
    }
    .tile .t{ font-weight:800; font-size:18px }
    .tile .s{ color:#333; font-weight:600; font-size:13px }
    .tile.yellow{ background:var(--tile-yellow); }
    .tile.white{ background:var(--tile-white); }

    .cards{ display:grid; gap:14px; grid-template-columns:1fr; }
    @media (min-width:540px){ .cards{ grid-template-columns:1fr 1fr; } }
    @media (min-width:992px){ .cards{ grid-template-columns:repeat(4,1fr); } }
    .card{
      background:linear-gradient(180deg,#151936,#141938 60%,#121632);
      border:1px solid var(--border);
      border-radius:var(--radius-lg); padding:18px; box-shadow:var(--shadow);
    }
    .card .k{ color:var(--muted); margin-bottom:6px; font-size:13px }
    .card .v{ font-size:28px; font-weight:800 }

    /* Forms (reusable) */
    .form{ display:grid; gap:14px; }
    label{ font-weight:700; font-size:13px; color:#dbe3fa }
    .inp{
      background:#0f142f;border:1px solid rgba(255,255,255,.08); color:#e8eeff;
      padding:12px 14px;border-radius:12px;outline:none;width:100%;
    }
    .inp:focus{ border-color:#8393ff; box-shadow:0 0 0 3px rgba(131,147,255,.2); }
    .btn{
      padding:12px 14px;border:none;border-radius:12px;cursor:pointer;font-weight:800;
      color:#0b1126;background:linear-gradient(45deg,#ffd451,#ffefb3);
      box-shadow:var(--shadow);
    }
    .btn.secondary{
      background:linear-gradient(45deg,#cdd5ff,#e9edff); color:#0a0f23;
    }

    /* Table (responsive) */
    .table{
      width:100%; border-collapse:separate; border-spacing:0; overflow:hidden;
      background:#121632; border:1px solid var(--border); border-radius:16px;
    }
    .table th, .table td{
      padding:12px 14px; border-bottom:1px solid var(--border); text-align:left;
    }
    .table th{ color:#cdd5ff; font-weight:700; font-size:13px; background:#10142d; }
    .table tr:last-child td{ border-bottom:0; }
    @media (max-width: 720px){
      .table thead{ display:none; }
      .table, .table tbody, .table tr, .table td{ display:block; width:100%; }
      .table tr{ border-bottom:1px solid var(--border); }
      .table td{ display:flex; justify-content:space-between; align-items:center; gap:16px; }
      .table td::before{ content:attr(data-label); color:#9fb0ff; font-weight:700; font-size:12px; }
    }

    /* Visibility helpers */
    .mobile-only{ display:none; }
    .desktop-only{ display:block; }
    @media (max-width: 768px){
      .mobile-only{ display:block; }
      .desktop-only{ display:none; }
    }
    .hidden{ display:none !important; }
  </style>
</head>
<body>
<div class="app">
  <!-- Sidebar (mobile drawer RIGHT, desktop fixed LEFT) -->
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="brand-bubble">W</div>
      <div>WBLB Admin</div>
    </div>
    <nav class="nav">
      <a href="index.php" class="<?= basename($_SERVER['PHP_SELF'])==='index.php'?'active':'' ?>">
        <i class="fa-solid fa-gauge-high"></i> ড্যাশবোর্ড
      </a>
      
      <a href="users.php" class="<?= basename($_SERVER['PHP_SELF'])==='users.php'?'active':'' ?>">
        <i class="fa-solid fa-users"></i> ইউজার
      </a>
       <a href="users.php" class="<?= basename($_SERVER['PHP_SELF'])==='search_user.php'?'active':'' ?>">
        <i class="fa-solid fa-users"></i> খুঁজুন
      </a>
      <a href="loan_settings.php" class="<?= basename($_SERVER['PHP_SELF'])==='loan_settings.php'?'active':'' ?>">
        <i class="fa-solid fa-sliders"></i> লোন সেটিংস
      </a>
      <a href="loan_requests.php" class="<?= basename($_SERVER['PHP_SELF'])==='loan_requests.php'?'active':'' ?>">
        <i class="fa-solid fa-file-invoice-dollar"></i> লোন রিকোয়েস্ট
      </a>
      <a href="documents.php" class="<?= basename($_SERVER['PHP_SELF'])==='documents.php'?'active':'' ?>">
        <i class="fa-solid fa-file-lines"></i> ডকুমেন্ট
      </a>
      <a href="deposit_settings.php" class="<?= basename($_SERVER['PHP_SELF'])==='deposit_settings.php'?'active':'' ?>">
        <i class="fa-solid fa-gear"></i> ডিপোজিট সেটিংস
      </a>
      <a href="deposits.php" class="<?= basename($_SERVER['PHP_SELF'])==='deposits.php'?'active':'' ?>">
        <i class="fa-solid fa-wallet"></i> ডিপোজিট সাবমিশন
      </a>
      <a href="reviews.php" class="<?= basename($_SERVER['PHP_SELF'])==='reviews.php'?'active':'' ?>">
        <i class="fa-solid fa-star"></i> রিভিউ
      </a>
      <a href="content.php" class="<?= basename($_SERVER['PHP_SELF'])==='content.php'?'active':'' ?>">
        <i class="fa-solid fa-pen-to-square"></i> কনটেন্ট
      </a>
      <a href="logout.php">
        <i class="fa-solid fa-right-from-bracket"></i> লগ আউট
      </a>
    </nav>
  </aside>

  <!-- Topbar -->
  <header class="topbar">
    <div class="brand">
      <div class="brand-bubble">W</div>
      <div>WBLB Admin</div>
    </div>
    <div class="actions">
      <button class="iconbtn" aria-label="Notifications"><i class="fa-regular fa-bell"></i></button>
      <!-- Drawer toggle appears on mobile -->
      <button class="iconbtn" id="drawerToggle" aria-label="Menu"><i class="fa-solid fa-bars-staggered"></i></button>
    </div>
  </header>

  <!-- Main starts (close in footer.php) -->
  <main class="main">
