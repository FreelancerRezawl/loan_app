<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>MONEY RECEIPT — Bank Check</title>
<style>
  /* ===== Design Tokens ===== */
  :root{
    --bg: #eef2f7;
    --grad1: #dbeafe;
    --grad2: #c7f0ff;
    --surface: #ffffff;
    --border: rgba(15,23,42,.12);
    --shadow: 0 18px 40px rgba(2,8,23,.12);
    --muted: #5b6473;
    --ink: #0e1320;
    --brand: #0b5ed7;
    --brand-2:#0a58ca;
    --navy:#003366;         /* header “WORLD BANK” blue */
    --title:#3f9bb1;        /* MONEY RECEIPT teal */
    --text-align: center;
    --gold:#c49a03;
    --radius: 16px;
  }

  *{box-sizing:border-box}

  /* ===== Page Frame ===== */
  html,body{height:100%}
  body{
    margin:0;
    font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial, "Noto Sans", sans-serif;
    color:var(--ink);
    background:
      radial-gradient(1200px 600px at -10% -10%, var(--grad1) 0%, transparent 50%),
      radial-gradient(800px 400px at 130% 10%, var(--grad2) 0%, transparent 50%),
      var(--bg);
  }

  .wrap{ max-width:1400px; margin:28px auto; padding:0 24px; }

  /* ===== Top Bar ===== */
  .topbar{ display:flex; align-items:center; justify-content:space-between; margin-bottom:18px; }
  .titlebar{ display:flex; align-items:center; gap:10px; color:#0f3a69; font-weight:800; letter-spacing:.2px; }
  .titlebar .dot{ width:10px; height:10px; border-radius:50%; background:var(--brand) }
  .toolbar{ display:flex; gap:10px }
  .btn{ padding:10px 14px; border:1px solid var(--border); background:#fff; border-radius:10px; cursor:pointer; font-weight:700; box-shadow:0 6px 16px rgba(2,8,23,.06) }
  .btn.primary{ background:var(--brand); color:#fff; border-color:transparent }
  .btn.primary:hover{ background:var(--brand-2) }
  .btn:hover{ filter:brightness(.98) }

  /* ===== Two Column Layout ===== */
  .grid{ display:grid; grid-template-columns: 360px 1fr; gap:22px; }
  @media (max-width: 980px){ .grid{ grid-template-columns:1fr } }

  /* ===== Card Base ===== */
  .card{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:var(--radius);
    box-shadow:var(--shadow);
  }

  /* ===== Form Card ===== */
  .form{ padding:24px 20px; }
  .form h2{ margin:0 0 14px; font-size:20px; letter-spacing:.2px; }
  .group{ margin-bottom:14px }
  .group label{ display:block; margin-bottom:6px; font-size:13px; font-weight:700; color:var(--muted) }
  .input{
    width:100%; padding:12px; border:1px solid var(--border); border-radius:10px;
    background:#f8fafc; font-size:15px;
    transition:border-color .15s, box-shadow .15s, background .15s;
  }
  .input:focus{ outline:none; border-color:var(--brand); background:#fff; box-shadow:0 0 0 4px rgba(59,130,246,.25) }
  input[type="file"].input{ padding:8px; background:#fff }
  .grid2{ display:grid; grid-template-columns:1fr 1fr; gap:12px }
  @media (max-width: 480px){ .grid2{ grid-template-columns:1fr } }
  .actions{ display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:8px }
  @media (max-width:480px){ .actions{ grid-template-columns:1fr } }

  /* ===== Preview Card ===== */
  .preview{ padding:14px; }
  .canvas{
    width:100%;
    aspect-ratio: 8 / 3.5;         /* desktop preview scale */
    background:#fff;
    border:1px dashed #aab2bf;
    border-radius:14px;
    overflow:hidden;
    position:relative;
  }
  .paper{ position:absolute; inset:0; display:flex; flex-direction:column; font-family:"Times New Roman",serif; color:#000; }

  /* Header */
  .header{ display:flex; justify-content:space-between; align-items:flex-start; padding:12px 20px }
  .header-left{ line-height:1.2 }
  .bank{ color:var(--navy); font-weight:800; font-size:20px }
  .group-sub{ color:var(--navy); font-weight:700; font-size:16px }
  .bigtitle{ color:var(--title); font-weight:800; font-size:26px; margin-top:6px }
  .addr{ text-align:right; font-size:14px; line-height:1.3 }
  .divider{ height:4px; background:var(--gold); margin:4px 0 }

  /* Meta Row */
  .meta{ display:flex; justify-content:space-between; padding:6px 20px; font-size:16px }
  .meta b{ font-weight:700 }
  .dots{ border-bottom:2px dotted #666; padding:0 6px; margin-left:6px; min-width:120px; display:inline-block }

  /* Lines */
  .body{ padding:10px 20px; display:flex; flex-direction:column; gap:12px; font-size:16px }
  .line{ display:flex; gap:12px; align-items:baseline }
  .label{ font-weight:700; min-width:200px }
  .fill{ flex:1; border-bottom:2px dotted #666; padding:0 6px; font-weight:600 }
  .acct .fill{ display:flex; gap:20px; align-items:center }
  .badge{ font-weight:800 }

  /* Signature */
  .footer{ position:relative; padding:30px 20px 18px; flex:1 }
  .signbox{ position:absolute; right:20px; bottom:12px; width:320px; text-align:center }
  .sigimg{ height:60px; display:block; margin:0 auto 6px; object-fit:contain }
  .sigdate{ font-size:14px; margin-bottom:6px }
  .authbar{ border-top:2px dotted #666; padding-top:6px; font-weight:800 }

  /* ===== PRINT: convert to static flow & fixed size so nothing clips ===== */
  @media print{
    @page { size:auto; margin:10mm; } /* small margin so borders aren't cut */
    *{ -webkit-print-color-adjust:exact; print-color-adjust:exact; overflow:visible !important }
    body{ background:#fff !important; margin:0 }
    .wrap{ max-width:none; margin:0; padding:0 }
    .topbar, .form{ display:none !important }
    .preview{ padding:0; margin:0; border:0; box-shadow:none }
    .canvas{
      width:8in !important; height:3.5in !important; aspect-ratio:auto;
      border:0; margin:0 auto !important;
      page-break-inside: avoid;
      position:static !important;          /* reset scale container */
      overflow:visible !important;
    }
    .paper{
      position:static !important;          /* NORMAL FLOW => no clipping */
      inset:auto !important;
      width:8in !important; height:3.5in !important;
      display:block !important;
      overflow:visible !important;
      font-family:"Times New Roman",serif;
    }
  }
</style>
</head>
<body>
<div class="wrap">
  <div class="topbar">
    <div class="titlebar"><span class="dot"></span> Bank Check Builder</div>
    <div class="toolbar">
      <button class="btn" id="btnPreview">Preview</button>
      <button class="btn primary" id="btnPrint">Print</button>
    </div>
  </div>

  <div class="grid">
    <!-- ===== Left: Form ===== -->
    <div class="card form">
      <h2>Enter Check Details</h2>
      <div class="grid2">
        <div class="group">
          <label for="inNo">NO.</label>
          <input class="input" id="inNo" value="457821">
        </div>
        <div class="group">
          <label for="inDate">Date</label>
          <input class="input" id="inDate" type="date">
        </div>
      </div>

      <div class="group">
        <label for="inName">Received with thanks from</label>
        <input class="input" id="inName" value="MD. ARIKUR ISLAM">
      </div>

      <div class="grid2">
        <div class="group">
          <label for="inAmount">Amount (e.g., 15983)</label>
          <input class="input" id="inAmount" type="number" value="15983" min="0" step="1">
        </div>
        <div class="group">
          <label for="inAcct">Account Type</label>
          <input class="input" id="inAcct" value="Bkash">
        </div>
      </div>

      <div class="group">
        <label for="inFor">For</label>
        <input class="input" id="inFor" value="Installment">
      </div>

      <div class="grid2">
        <div class="group">
          <label for="inSigDate">Signature Date</label>
          <input class="input" id="inSigDate" type="date">
        </div>
        <div class="group">
          <label for="inSig">Signature Image</label>
          <input class="input" id="inSig" type="file" accept="image/*">
        </div>
      </div>

      <div class="actions">
        <button class="btn" id="btnPreview2">Generate Preview</button>
        <button class="btn primary" id="btnPrint2">Print</button>
      </div>
    </div>

    <!-- ===== Right: Preview ===== -->
    <div class="card preview">
      <div class="canvas">
        <div class="paper">
          <div class="header">
            <div class="header-left">
              <div class="bank">WORLD BANK</div>
              <div class="group-sub">Bangladesh Group</div>
              <div class="bigtitle">MONEY RECEIPT</div>
            </div>
            <div class="addr">
              Plot E 32,<br>
              Syed Mahbub Morshed Avenue,<br>
              Sher-e-Bangla Nagar,<br>
              Agargaon, Dhaka.
            </div>
          </div>

          <div class="divider"></div>

          <div class="meta">
            <div><b>NO</b> <span class="dots" id="pvNo">457821</span></div>
            <div><b>Date</b> <span class="dots" id="pvDate">16-July -2025</span></div>
          </div>

          <div class="body">
            <div class="line">
              <div class="label">Received with thanks from</div>
              <div class="fill" id="pvName">MD. ARIKUR ISLAM</div>
            </div>

            <div class="line">
              <div class="label">Amount</div>
              <div class="fill" id="pvAmount">15,983 BDT</div>
            </div>

            <div class="line">
              <div class="label">In word</div>
              <div class="fill" id="pvWords">Fifteen Thousand Nine Hundred Eighty - Three Taka Only</div>
            </div>

            <div class="line">
              <div class="label">For</div>
              <div class="fill" id="pvFor">Installment</div>
            </div>

            <div class="line acct">
              <div class="label">ACCT.</div>
              <div class="fill">
                <span id="pvAcct">Bkash</span>
                <span class="badge">PAID</span>
                <span id="pvAmt2">15,983 BDT</span>
              </div>
            </div>
          </div>

          <div class="footer">
            <div class="signbox">
              <img class="sigimg" id="pvSigImg" src="https://placehold.co/260x60/ffffff/ffffff?text=." alt="signature">
              <div class="sigdate" id="pvSigDate">2025-07-16</div>
              <div class="authbar">Authorized Signature</div>
            </div>
          </div>

        </div>
      </div>
    </div>

  </div>
</div>

<script>
  // Formatters
  function fmtDatePretty(iso){
    if(!iso) return '';
    const d = new Date(iso + 'T00:00:00');
    const day = String(d.getDate()).padStart(2,'0');
    const month = d.toLocaleString('en-GB',{month:'long'});
    const year = d.getFullYear();
    return `${day}-${month} -${year}`;
  }
  function toWordsIndian(n){
    n = Math.floor(Number(n)||0);
    if(n===0) return 'Zero';
    const ones=['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
    const tens=['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
    const two=d=>d<20?ones[d]:tens[Math.floor(d/10)]+(d%10?'-'+ones[d%10]:'');
    const three=d=>d<100?two(d):(ones[Math.floor(d/100)]+' Hundred'+(d%100?' and '+two(d%100):''));
    let s='',cro=Math.floor(n/1e7); n%=1e7; let lak=Math.floor(n/1e5); n%=1e5; let th=Math.floor(n/1e3); n%=1e3;
    if(cro) s+=two(cro)+' Crore '; if(lak) s+=two(lak)+' Lakh '; if(th) s+=two(th)+' Thousand '; if(n) s+=three(n);
    return s.trim();
  }

  // Update preview
  function updatePreview(){
    const no = inNo.value.trim();
    const date = inDate.value;
    const name = inName.value.trim();
    const amount = parseFloat(inAmount.value) || 0;
    const forTxt = inFor.value.trim();
    const acct = inAcct.value.trim();
    const sigDate = inSigDate.value;

    pvNo.textContent = no;
    pvDate.textContent = fmtDatePretty(date);
    pvName.textContent = name;
    const fmtAmt = amount.toLocaleString('en-IN');
    pvAmount.textContent = fmtAmt + ' BDT';
    pvAmt2.textContent = fmtAmt + ' BDT';
    pvWords.textContent = toWordsIndian(amount) + ' Taka Only';
    pvFor.textContent = forTxt;
    pvAcct.textContent = acct;
    pvSigDate.textContent = sigDate;
  }

  // Signature image
  function handleSig(e){
    const f = e.target.files && e.target.files[0];
    if(!f) return;
    const r = new FileReader();
    r.onload = ev => pvSigImg.src = ev.target.result;
    r.readAsDataURL(f);
  }

  // Wire up
  document.addEventListener('DOMContentLoaded', () => {
    const today = new Date().toISOString().split('T')[0];
    inDate.value = today;
    inSigDate.value = today;

    [inNo,inDate,inName,inAmount,inFor,inAcct,inSigDate].forEach(el => el.addEventListener('input', updatePreview));
    inSig.addEventListener('change', handleSig);

    btnPreview.onclick = updatePreview;
    btnPreview2.onclick = updatePreview;
    btnPrint.onclick = () => { updatePreview(); window.print(); };
    btnPrint2.onclick = () => { updatePreview(); window.print(); };

    updatePreview();
  });
</script>
</body>
</html>
