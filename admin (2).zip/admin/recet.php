<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Cheque Generator — The World Bank (BD)</title>

<!-- Fonts for look-alike styles (digital + clean UI) -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&family=Orbitron:wght@600&family=Roboto+Mono:wght@500&display=swap" rel="stylesheet"/>

<style>
  :root{
    --blue:#0c72b5;        /* header start */
    --blue2:#0a4e92;       /* header end   */
    --sheet:#e7f3fb;       /* cheque paper */
    --ink:#0e1b2b;
    --muted:#385977;
    --lines:#9fbad2;
    --box:#ffffff;
    --accent:#0a4e92;
    --radius:12px;
    --shadow:0 12px 28px rgba(0,0,0,.35);
  }
  *{box-sizing:border-box}
  body{
    margin:0; background:#0b1220; color:#e5e7eb;
    font-family:Poppins,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
  }
  .wrap{
    max-width:1200px; margin:0 auto; padding:16px;
    display:grid; gap:16px; grid-template-columns: 380px 1fr;
  }
  @media (max-width: 980px){ .wrap{ grid-template-columns: 1fr; } }

  /* ===== Left: Inputs ===== */
  .panel{
    background:#111b34; border:1px solid #223559; border-radius:12px; padding:14px;
  }
  .panel h2{margin:0 0 10px; font-size:18px}
  .form{display:grid; gap:10px}
  .row{display:grid; grid-template-columns:1fr 1fr; gap:8px}
  label{font-size:12px; color:#cbd5e1; font-weight:700}
  input, textarea, select{
    width:100%; padding:10px 12px; border-radius:10px; border:1px solid #2b3f64;
    background:#0f162b; color:#fff; outline:none;
  }
  textarea{min-height:68px; resize:vertical}
  .btns{display:flex; gap:8px; flex-wrap:wrap; margin-top:6px}
  .btn{
    border:0; border-radius:10px; padding:10px 14px; font-weight:800; cursor:pointer
  }
  .btn.print{background:#22c55e; color:#052e1a}
  .btn.sample{background:#475569; color:#fff}
  .btn.clear{background:#7f1d1d; color:#fff}

  /* ===== Right: Cheque ===== */
  .stage{display:grid; place-items:center}
  .cheque{
    width:100%; max-width:1000px; aspect-ratio: 25/12;           /* wide like your image */
    background:var(--sheet); color:var(--ink);
    border-radius:8px; box-shadow:var(--shadow); overflow:hidden;
    position:relative;
  }

  /* Header strip */
  .hdr{
    height:84px; padding:12px 18px;
    background:linear-gradient(90deg,var(--blue2),var(--blue));
    color:#fff; display:flex; align-items:center; justify-content:space-between; gap:12px;
  }
  .brand{display:flex;align-items:center;gap:12px}
  .logo{
    width:48px;height:48px;border-radius:50%; display:grid;place-items:center;
    background:#ffffff15;border:1px solid #ffffff33
  }
  .logo svg{width:30px;height:30px; fill:#fff}
  .bank-name{line-height:1}
  .bank-name .top{font-weight:800; font-size:24px; letter-spacing:.5px}
  .bank-name .sub{font-weight:600; opacity:.9; font-size:14px}
  .cheque-no{
    font-family:'Orbitron',system-ui; font-size:28px; letter-spacing:6px;
  }

  /* Watermark world map + left vertical watermark text */
  .wm{
    position:absolute; inset:84px 0 0 0; pointer-events:none;
    background:
      radial-gradient(ellipse at center, rgba(255,255,255,.35) 0%, rgba(255,255,255,0) 60%) center/120% 120% no-repeat,
      url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400" opacity="0.08"><rect width="800" height="400" fill="white"/></svg>');
  }
  .vertical{
    position:absolute; left:6px; top:110px; writing-mode:vertical-rl; transform:rotate(180deg);
    color:#4779a6; opacity:.25; font-weight:800; letter-spacing:2px;
  }

  /* Body area */
  .body{padding:14px 18px 12px; position:relative}
  .rowline{display:flex; align-items:center; gap:10px; margin:10px 0}
  .lab{min-width:120px; color:#2f587e; font-weight:800; letter-spacing:.5px}
  .dash{flex:1; border-bottom:2px solid var(--lines)}
  .val{min-width:280px; font-weight:700}
  .val.bold{font-weight:800}
  .box{
    background:var(--box); border:2px solid #d8e6f3; border-radius:6px; padding:8px 12px; min-width:240px;
  }

  /* Date on right boxed */
  .date-wrap{display:flex; align-items:center; gap:10px}
  .date-box{background:#fff; border:2px solid #d8e6f3; border-radius:6px; padding:10px 14px; min-width:220px; text-align:center; font-weight:700}

  /* Right column helpers */
  .rightcol{position:absolute; right:18px; top:118px; width:340px}

  .amount-words{margin-top:48px}
  .locknote{display:flex; align-items:center; gap:10px; margin-top:10px; color:#415b77; font-size:12px; font-weight:700}
  .locknote .ico{width:18px;height:18px;border:2px solid #415b77; border-radius:3px; display:grid; place-items:center}

  /* Signature section */
  .sign-area{
    position:absolute; right:18px; bottom:54px; width:360px; text-align:left;
  }
  .sign-area .line{border-bottom:2px solid var(--lines); height:30px; margin-top:28px}
  .sign-area small{color:#46698f; font-weight:700}

  /* Bottom MICR strip */
  .micr{
    position:absolute; left:0; right:0; bottom:0; height:56px; background:#e0e8f0;
    display:flex; align-items:center; justify-content:center; gap:24px; color:#0d1726; border-top:1px solid #c7d7e4;
    font-family:'Roboto Mono', monospace; font-weight:500; letter-spacing:12px; font-size:22px;
  }

  /* print only cheque */
  @media print{
    body{ background:#fff }
    .panel{ display:none !important }
    .cheque{ box-shadow:none; width:100%; max-width:none }
    @page{ size:A4 landscape; margin:12mm }
    *{ -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  }
</style>
</head>
<body>
<div class="wrap">

  <!-- ===== INPUTS ===== -->
  <div class="panel">
    <h2>Cheque Inputs</h2>
    <form class="form" oninput="update()">
      <div class="row">
        <div>
          <label>Cheque No</label>
          <input id="f_no" value="25421">
        </div>
        <div>
          <label>Date (DD/MM/YYYY)</label>
          <input id="f_date" placeholder="08/06/2025" value="">
        </div>
      </div>

      <div>
        <label>PAY to</label>
        <input id="f_payto" value="Md. Ainul Islam">
      </div>

      <div class="row">
        <div>
          <label>Amount (numeric, e.g., 50000)</label>
          <input id="f_amount" type="number" step="1" value="50000">
        </div>
        <div>
          <label>Amount in words (auto if blank)</label>
          <input id="f_words" placeholder="fifty thousand Only">
        </div>
      </div>

      <div>
        <label>To the order of</label>
        <input id="f_order" value="THE WORLD BANK">
      </div>

      <div>
        <label>RE (Remarks)</label>
        <input id="f_re" value="">
      </div>

      <div class="row">
        <div>
          <label>MICR Left</label>
          <input id="f_m1" value="0257">
        </div>
        <div>
          <label>MICR Center</label>
          <input id="f_m2" value="11048">
        </div>
      </div>
      <div class="row">
        <div>
          <label>MICR Right</label>
          <input id="f_m3" value="027117">
        </div>
        <div>
          <label>Office address (small under logo)</label>
          <input id="f_addr" value="Bangladesh">
        </div>
      </div>

      <div class="btns">
        <button class="btn print" type="button" onclick="window.print()">Print</button>
        <button class="btn sample" type="button" onclick="sample()">Sample</button>
        <button class="btn clear"  type="button" onclick="clearForm()">Clear</button>
      </div>
    </form>
  </div>

  <!-- ===== PREVIEW ===== -->
  <div class="stage">
    <div class="cheque" id="cheque">

      <div class="hdr">
        <div class="brand">
          <div class="logo">
            <!-- simple globe icon -->
            <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm7.94 9h-3.09a15.9 15.9 0 00-.86-5.03A8.02 8.02 0 0119.94 11zM12 4c.99 1.3 1.74 3.38 2.03 6h-4.06C10.26 7.38 11.01 5.3 12 4zM4.06 13h3.09c.18 1.77.62 3.45 1.28 4.84A8.02 8.02 0 014.06 13zm0-2a8.02 8.02 0 014.37-4.84A13.9 13.9 0 007.15 11H4.06zM12 20c-.99-1.3-1.74-3.38-2.03-6h4.06C13.74 16.62 12.99 18.7 12 20zm3.29-2.16A17.9 17.9 0 0016.85 13h3.09a8.02 8.02 0 01-4.65 4.84z"/></svg>
          </div>
          <div class="bank-name">
            <div class="top">THE WORLD BANK</div>
            <div class="sub" id="p_addr">Bangladesh</div>
          </div>
        </div>
        <div class="cheque-no" id="p_no">25421</div>
      </div>

      <div class="wm"></div>
      <div class="vertical">THE WORLD BANK</div>

      <div class="body">
        <!-- Right column: date & amount in words box & lock note -->
        <div class="rightcol">
          <div class="date-wrap">
            <div class="lab">DATE</div>
            <div class="date-box" id="p_date">08/06/2025</div>
          </div>
          <div class="amount-words">
            <div class="box" id="p_words">fifty thousand Only</div>
          </div>
          <div class="locknote">
            <div class="ico">🔒</div>
            <div>SECURITY FEATURED INCLUDED</div>
          </div>
        </div>

        <div class="rowline">
          <div class="lab">PAY to</div>
          <div class="dash"></div>
          <div class="val bold" id="p_payto">Md. Ainul Islam</div>
        </div>

        <div class="rowline">
          <div class="lab">A/C No</div>
          <div class="dash"></div>
          <div class="val" id="p_amount">=50,000/=</div>
        </div>

        <div class="rowline">
          <div class="lab">TO THE ORDER OF</div>
          <div class="dash"></div>
          <div class="val" id="p_order">THE WORLD BANK</div>
        </div>

        <div class="rowline">
          <div class="lab">RE</div>
          <div class="dash"></div>
          <div class="val" id="p_re"> </div>
        </div>

        <!-- Signature -->
        <div class="sign-area">
          <div style="height:48px">
            <!-- (optional) you can draw or place a signature image here -->
            <svg viewBox="0 0 200 60" width="180" height="54" style="opacity:.65">
              <path d="M10 40 C30 20, 45 50, 70 28 S110 20, 130 36 160 42, 190 30" fill="none" stroke="#2a3f63" stroke-width="3" stroke-linecap="round"/>
            </svg>
          </div>
          <div class="line"></div>
          <small>PAYER’S SIGNATURE</small>
        </div>
      </div>

      <!-- MICR -->
      <div class="micr">
        <span id="p_m1">0257</span>
        <span id="p_m2">11048</span>
        <span id="p_m3">027117</span>
      </div>
    </div>
  </div>
</div>

<script>
  const $ = s => document.querySelector(s);

  function fmt(n){
    if(!n && n!==0) return '';
    return (+n).toLocaleString('en-US', {maximumFractionDigits:0});
  }

  // amount to words (simple English)
  function toWords(num){
    num = Math.floor(Math.abs(+num || 0));
    if(num===0) return 'zero only';
    const a = ['','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen'];
    const b = ['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'];
    function chunk(n){
      let s='';
      if(n>=100){ s+=a[Math.floor(n/100)]+' hundred'; n%=100; if(n) s+=' '; }
      if(n>=20){ s+=b[Math.floor(n/10)]; n%=10; if(n) s+=' '; }
      if(n>0) s+=a[n];
      return s;
    }
    function words(n){
      const parts=[];
      const units=[['billion',1e9],['million',1e6],['thousand',1e3],['',1]];
      for(const [label,val] of units){
        const c=Math.floor(n/val)%((val===1)?1e3:1000);
        if(c) parts.push(chunk(c)+(label?` ${label}`:''));
      }
      return parts.join(' ');
    }
    const s = words(num);
    return s.charAt(0).toUpperCase()+s.slice(1)+' Only';
  }

  function update(){
    const no   = $('#f_no').value.trim() || '—';
    const date = $('#f_date').value.trim();
    const pay  = $('#f_payto').value.trim();
    const amt  = $('#f_amount').value.trim();
    const w    = $('#f_words').value.trim() || toWords(amt);
    const ord  = $('#f_order').value.trim();
    const re   = $('#f_re').value.trim();
    const m1   = $('#f_m1').value.trim();
    const m2   = $('#f_m2').value.trim();
    const m3   = $('#f_m3').value.trim();
    const addr = $('#f_addr').value.trim();

    $('#p_no').textContent = no;
    $('#p_date').textContent = date;
    $('#p_payto').textContent = pay || '—';
    $('#p_amount').textContent = amt ? ('='+fmt(amt)+'/=') : '';
    $('#p_words').textContent = w;
    $('#p_order').textContent = ord || '—';
    $('#p_re').textContent = re || ' ';
    $('#p_m1').textContent = m1;
    $('#p_m2').textContent = m2;
    $('#p_m3').textContent = m3;
    $('#p_addr').textContent = addr || 'Bangladesh';
  }

  function sample(){
    $('#f_no').value = '25421';
    $('#f_date').value = '08/06/2025';
    $('#f_payto').value = 'Md. Ainul Islam';
    $('#f_amount').value = '50000';
    $('#f_words').value = 'fifty thousand Only';
    $('#f_order').value = 'THE WORLD BANK';
    $('#f_re').value = '';
    $('#f_m1').value = '0257';
    $('#f_m2').value = '11048';
    $('#f_m3').value = '027117';
    $('#f_addr').value = 'Bangladesh';
    update();
  }
  function clearForm(){
    document.querySelectorAll('input,textarea').forEach(el => el.value='');
    update();
  }

  // init
  (function(){ sample(); })();
</script>
</body>
</html>
