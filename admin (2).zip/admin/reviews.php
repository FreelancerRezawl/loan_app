<?php include 'header.php'; include 'config.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (isset($_POST['create'])) {
    $name = trim($_POST['name']);
    $gender = trim($_POST['gender']);
    $photo = trim($_POST['photo_url']);
    $amount = max(0, (int)$_POST['amount']);
    $msg = trim($_POST['message']);

    // Validate gender
    if (!in_array($gender, ['male', 'female'])) {
      $gender = 'male';
    }

    // Sanitize inputs
    $name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    $photo = htmlspecialchars($photo, ENT_QUOTES, 'UTF-8');
    $msg = htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');

    if (!empty($name) && !empty($msg) && $amount >= 0) {
      $pdo->prepare("INSERT INTO reviews(name,gender,photo_url,amount,message) VALUES(?,?,?,?,?)")
          ->execute([$name,$gender,$photo,$amount,$msg]);
    }
  }
  if (isset($_POST['toggle'])) {
    $id = (int)$_POST['id'];
    if ($id > 0) {
      $pdo->prepare("UPDATE reviews SET is_active=1-is_active WHERE id=?")->execute([$id]);
    }
  }
  if (isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    if ($id > 0) {
      $pdo->prepare("DELETE FROM reviews WHERE id=?")->execute([$id]);
    }
  }
}

$rows=$pdo->query("SELECT * FROM reviews ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="panel">
  <h3 class="h">রিভিউ/কমেন্ট কন্ট্রোল</h3>

  <form method="post" class="form-row">
    <input class="input" name="name" placeholder="নাম" required>
    <select class="select" name="gender" style="max-width:120px">
      <option value="male">পুরুষ</option><option value="female">নারী</option>
    </select>
    <input class="input" type="number" name="amount" placeholder="পরিমাণ (যেমন 700000)" required>
    <input class="input" name="photo_url" placeholder="ছবির URL (গুগল/লিংক)">
    <input class="input" name="message" placeholder="মেসেজ" required>
    <button class="btn primary" name="create">যোগ</button>
  </form>

  <table class="table">
    <thead><tr><th>নাম</th><th>পরিমাণ</th><th>বার্তা</th><th>ছবি</th><th>স্ট্যাটাস</th><th>অ্যাকশন</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr>
        <td><?= htmlspecialchars($r['name']) ?><br><small><?= $r['gender'] ?></small></td>
        <td><?= number_format($r['amount']) ?> ৳</td>
        <td><?= htmlspecialchars($r['message']) ?></td>
        <td><?php if($r['photo_url']): ?><img src="<?= htmlspecialchars($r['photo_url']) ?>" alt="" style="width:44px;height:44px;border-radius:50%"><?php endif; ?></td>
        <td><?= $r['is_active'] ? 'Active' : 'Hidden' ?></td>
        <td class="form-row">
          <form method="post">
            <input type="hidden" name="id" value="<?= $r['id'] ?>">
            <button class="btn ghost" name="toggle"><?= $r['is_active']?'আড়াল':'দেখাও' ?></button>
            <button class="btn danger" name="delete" onclick="return confirm('ডিলিট করবেন?')">ডিলিট</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include 'footer.php'; ?>
