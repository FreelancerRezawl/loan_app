<?php
include 'header.php';
include 'config.php';

$UPLOAD_BASE_URL = 'https://bdworldbank.com/uploads/'; // change if needed

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $id        = (int)($_POST['id'] ?? 0);
  $ui_status = trim($_POST['status'] ?? '');
  $reason    = trim($_POST['reason'] ?? '');

  // UI <-> DB mapping
  $ui_to_db = ['Rejected' => 'Fail'];
  $status = $ui_to_db[$ui_status] ?? $ui_status;

  // Validate DB statuses
  $allowed_db_statuses = ['Pending', 'Process', 'Success', 'Fail'];
  if (!in_array($status, $allowed_db_statuses, true)) {
    $status = 'Pending';
  }

  // Store reason escaped (safe to render later)
  $reason = htmlspecialchars($reason, ENT_QUOTES, 'UTF-8');

  if ($id > 0) {
    $stmt = $pdo->prepare("UPDATE loan_requests SET status=?, reason=?, updated_at=NOW() WHERE id=?");
    $stmt->execute([$status, $reason, $id]);
  }
}

// Fetch rows + users + (optional) plan + documents
$rows = $pdo->query("
  SELECT
    lr.*,
    u.name, u.mobile, u.id AS uid,
    ls.amount AS plan_amount,
    d.nid_front, d.nid_back, d.user_photo, d.nominee_photo, d.signature
  FROM loan_requests lr
  JOIN users u ON u.id = lr.user_id
  LEFT JOIN loan_settings ls ON ls.id = lr.loan_id
  LEFT JOIN documents d ON d.user_id = lr.user_id
  ORDER BY lr.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Helpers
function display_status($db_status) {
  return $db_status === 'Fail' ? 'Rejected' : $db_status;
}
function build_doc_items(array $r, string $base): array {
  $map = [
    'user_photo'    => 'User Photo',
    'nid_front'     => 'NID Front',
    'nid_back'      => 'NID Back',
    'nominee_photo' => 'Nominee Photo',
    'signature'     => 'Signature',
  ];
  $items = [];
  foreach ($map as $k => $label) {
    $fname = $r[$k] ?? '';
    if (!$fname) continue;
    $safe = basename($fname);
    $url  = $base . rawurlencode($safe);
    $items[] = ['label'=>$label, 'url'=>$url];
  }
  return $items;
}
?>
<style>
  :root{
    --border: rgba(255,255,255,.10);
    --panel: #0f1e35;
    --muted: #a9b2c7;
    --brand:#2f7bff;
    --ok:#00c29a;
    --chip:#13223f;
  }

  .panel{
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    box-shadow: 0 8px 24px rgba(0,0,0,.35);
    margin: 16px;
  }
  .h{ margin:0 0 12px; font-weight:800; font-size:18px }

  /* Table wrapper */
  .table-wrap{
    overflow:auto;
    border:1px solid var(--border);
    border-radius:14px;
  }
  .table{
    width:100%;
    border-collapse:collapse;
    min-width: 920px; /* allows horizontal scroll on phones if needed */
    background: transparent;
  }
  .table th, .table td{
    padding:10px 12px;
    border-bottom:1px solid rgba(255,255,255,.06);
    text-align:left;
    vertical-align: top;
  }
  .table thead th{
    background:#16264a;
    color:#cfd7ea;
    font-weight:700;
    position: sticky;
    top: 0;
    z-index: 1;
  }
  .table tr:hover td{ background: rgba(255,255,255,.03) }

  /* Stacked rows for mobile */
  @media (max-width:640px){
    .table{ min-width:0 }
    .table thead{ display:none; }
    .table, .table tbody, .table tr, .table td{ display:block; width:100%; }
    .table tr{ border-bottom:1px solid var(--border); padding:8px }
    .table td{
      display:flex;
      flex-direction:column;   /* key: stack vertically */
      align-items:stretch;     /* key: take full width */
      gap:8px;
      border-bottom:none;
      padding:8px 4px;
    }
    .table td::before{
      content: attr(data-label);
      color:#9fb0ff; font-weight:700; font-size:12px;
      margin-bottom:2px;
    }
    /* Action cell: stack form controls and full-width buttons */
    .table td[data-label="অ্যাকশন"] .form-row{
      grid-template-columns: 1fr;
    }
    .table td[data-label="অ্যাকশন"] .form-row .btn{
      width:100%;
    }
    .actions-col{ gap:10px; } /* extra breathing space on mobile */
  }

  /* Inline form controls */
  .form-row{
    display:grid;
    grid-template-columns: 1fr auto auto;
    gap:8px;
  }
  .select, .input{
    width:100%;
    padding:10px 12px;
    border-radius:12px;
    background:#172745;
    border:1px solid var(--border);
    color:#e9ecf1;
    outline:none;
  }
  .select:focus, .input:focus{ border-color:var(--brand); box-shadow:0 0 0 2px rgba(47,123,255,.25) }

  .btn{
    appearance:none; border:0; cursor:pointer;
    padding:10px 12px; border-radius:12px; font-weight:700; font-size:14px;
    display:inline-block; text-align:center;
  }
  .btn.ok{ background:var(--ok); color:#082019 }
  .btn.secondary{
    background:linear-gradient(45deg,#cdd5ff,#e9edff);
    color:#0a0f23;
    font-weight:700;
  }
  .btn.ghost{
    background:#13223f; border:1px solid var(--border); color:#dfe6ff; font-weight:700;
    padding:8px 12px; border-radius:10px; font-size:13px;
  }

  /* Responsive grid for inline form in table */
  .table .form-row{
    grid-template-columns: 140px 1fr auto;
    gap:8px;
  }
  @media (min-width:900px){
    .table .form-row{ grid-template-columns: 160px 220px auto; }
  }
  @media (max-width:720px){
    .table .form-row{ grid-template-columns: 1fr; }
    .table .form-row .btn{ width:100% }
  }

  /* Badges */
  .badge{
    display:inline-flex; align-items:center; gap:6px;
    padding:6px 10px; border-radius:999px; font-weight:800; font-size:12px;
    background:var(--chip); border:1px solid var(--border); color:#dfe6ff;
  }
  .badge.pending{ color:#ffd451; border-color: rgba(255,212,81,.35) }
  .badge.process{ color:#7ab3ff; border-color: rgba(122,179,255,.35) }
  .badge.success{ color:#45df9b; border-color: rgba(69,223,155,.35) }
  .badge.reject{  color:#ff7b7b; border-color: rgba(255,123,123,.35) }

  .muted{ color:var(--muted); font-size:.9rem }

  /* Action cell vertical stack container */
  .actions-col{ display:flex; flex-direction:column; gap:8px; }

  /* Document gallery */
  .doc-box{
    display:none;                /* hidden by default */
    margin-top:4px;
    background:#101b36;
    border:1px solid var(--border);
    border-radius:12px;
    padding:10px;
  }
  .doc-box.open{ display:block; } /* toggled by JS */

  .doc-grid{ display:grid; grid-template-columns:repeat(2,1fr); gap:10px; }
  @media (min-width:720px){ .doc-grid{ grid-template-columns:repeat(4,1fr); } }
  .thumb{
    background:#13223f; border:1px solid var(--border); border-radius:10px; overflow:hidden;
  }
  .thumb a{ display:block; text-decoration:none; color:inherit }
  .thumb img{ width:100%; height:140px; object-fit:cover; display:block; background:#0d1528 }
  .thumb .cap{ padding:6px 8px; font-size:12px; color:#cfd7ea; display:flex; justify-content:space-between; gap:6px }
</style>

<div class="panel">
  <h3 class="h">লোন রিকোয়েস্ট</h3>

  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>ইউজার</th>
          <th>প্ল্যান</th>
          <th>টোটাল</th>
          <th>মেথড</th>
          <th>স্ট্যাটাস</th>
          <th>অ্যাকশন</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
        <?php
          $dbStatus = $r['status'];
          $uiStatus = display_status($dbStatus);
          $badgeClassMap = [
            'Pending'  => 'badge pending',
            'Process'  => 'badge process',
            'Success'  => 'badge success',
            'Fail'     => 'badge reject',
          ];
          $cls = $badgeClassMap[$dbStatus] ?? 'badge';

          $uid = (int)$r['uid'];
          $docItems = build_doc_items($r, $UPLOAD_BASE_URL);
          $hasDocs  = !empty($docItems);
        ?>
        <tr>
          <td data-label="ইউজার">
            <?= htmlspecialchars($r['name']) ?><br>
            <small class="muted">ID #<?= $uid ?> • <?= htmlspecialchars($r['mobile']) ?></small>
          </td>

          <td data-label="প্ল্যান">
            <?= number_format($r['amount']) ?> ৳ /
            <?= (int)$r['duration_months'] ?> ম /
            <?= rtrim(rtrim((string)$r['interest_rate'],'0'),'.') ?>%
          </td>

          <td data-label="টোটাল"><?= number_format($r['total_amount']) ?> ৳</td>

          <td data-label="মেথড">
            <?= htmlspecialchars($r['method']) ?><br>
            <small class="muted"><?= htmlspecialchars($r['account_number']) ?></small>
          </td>

          <td data-label="স্ট্যাটাস">
            <span class="<?= $cls ?>"><?= $uiStatus ?></span>
            <?php if(!empty($r['reason'])): ?>
              <div style="color:#ffb0b0; font-size:.85rem; margin-top:4px">
                <?= htmlspecialchars($r['reason']) ?>
              </div>
            <?php endif; ?>
          </td>

          <td data-label="অ্যাকশন">
            <div class="actions-col">
              <form method="post" class="form-row" style="align-items:center">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">

                <select name="status" class="select" aria-label="Change status">
                  <?php
                    $uiOptions = ['Pending','Process','Success','Rejected'];
                    foreach ($uiOptions as $opt):
                      $selected = ($opt === $uiStatus) ? 'selected' : '';
                  ?>
                    <option value="<?= $opt ?>" <?= $selected ?>><?= $opt ?></option>
                  <?php endforeach; ?>
                </select>

                <input class="input" name="reason" placeholder="নোট/কারণ (ঐচ্ছিক)" aria-label="Reason">
                <button class="btn ok" type="submit">সেভ</button>
              </form>

              <?php if ($hasDocs): ?>
                <button class="btn ghost" type="button"
                        onclick="toggleDocs('docs-<?= $uid ?>', this)">
                  ডকুমেন্ট দেখুন
                </button>

                <div class="doc-box" id="docs-<?= $uid ?>">
                  <div class="doc-grid">
                    <?php foreach ($docItems as $d): ?>
                      <div class="thumb">
                        <a href="<?= htmlspecialchars($d['url']) ?>" target="_blank" rel="noopener">
                          <img src="<?= htmlspecialchars($d['url']) ?>" alt="<?= htmlspecialchars($d['label']) ?>" loading="lazy">
                          <div class="cap">
                            <span><?= htmlspecialchars($d['label']) ?></span>
                            <span>Open ↗</span>
                          </div>
                        </a>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              <?php else: ?>
                <span class="muted">কোনো ডকুমেন্ট নাই</span>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  function toggleDocs(id, btn){
    const box = document.getElementById(id);
    if(!box) return;
    const isOpen = box.classList.toggle('open'); // class-based toggle (works with mobile CSS)
    if(btn){
      btn.textContent = isOpen ? 'ডকুমেন্ট লুকান' : 'ডকুমেন্ট দেখুন';
    }
  }
</script>

<?php include 'footer.php'; ?>
