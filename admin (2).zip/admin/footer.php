  </main>
</div>

<div class="overlay" id="overlay"></div>

<script>
  // Drawer logic (open/close right-side menu)
  const sidebar  = document.getElementById('sidebar');
  const overlay  = document.getElementById('overlay');
  const toggle   = document.getElementById('drawerToggle');

  function openDrawer(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
  function closeDrawer(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }

  toggle?.addEventListener('click', () => {
    sidebar.classList.contains('open') ? closeDrawer() : openDrawer();
  });
  overlay?.addEventListener('click', closeDrawer);

  // Close drawer when clicking a nav link (mobile)
  document.querySelectorAll('.nav a').forEach(a=>{
    a.addEventListener('click', closeDrawer);
  });
</script>
</body>
</html>
