<?php
/* ============================
   insurance_form.php (single file)
   - Top: AJAX lookup endpoint (?action=lookup&q=...)
   - Bottom: Full HTML page
   ============================ */

if (isset($_GET['action']) && $_GET['action'] === 'lookup') {
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

  require __DIR__ . '/config.php'; // must define $pdo (PDO)

  try { $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); } catch (Throwable $e) {}

  $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
  if ($q === '') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Missing query'], JSON_UNESCAPED_UNICODE);
    exit;
  }

  $idTry = ctype_digit($q) ? (int)$q : -1;

  // Try JOIN (if you have personal_info), else fallback to simple query
  $sqlJoin = "
    SELECT u.id, u.name, u.mobile,
           p.father, p.mother, p.village AS sa, p.post, p.thana, p.district
    FROM users u
    LEFT JOIN personal_info p ON p.user_id = u.id
    WHERE u.id = :id OR u.mobile = :mobile
    LIMIT 1
  ";
  $sqlSimple = "
    SELECT u.id, u.name, u.mobile
    FROM users u
    WHERE u.id = :id OR u.mobile = :mobile
    LIMIT 1
  ";

  $params = [':id'=>$idTry, ':mobile'=>$q];

  try {
    $st = $pdo->prepare($sqlJoin);
    $st->execute($params);
    $row = $st->fetch(PDO::FETCH_ASSOC);
  } catch (Throwable $e) {
    $st = $pdo->prepare($sqlSimple);
    $st->execute($params);
    $row = $st->fetch(PDO::FETCH_ASSOC);
  }

  if (!$row) {
    echo json_encode(['ok'=>true,'found'=>false], JSON_UNESCAPED_UNICODE);
    exit;
  }

  $data = [
    'name'     => $row['name']     ?? '',
    'father'   => $row['father']   ?? '',
    'mother'   => $row['mother']   ?? '',
    'sa'       => $row['sa']       ?? '',
    'post'     => $row['post']     ?? '',
    'thana'    => $row['thana']    ?? '',
    'district' => $row['district'] ?? '',
    'mobile'   => $row['mobile']   ?? '',
  ];

  echo json_encode(['ok'=>true,'found'=>true,'data'=>$data], JSON_UNESCAPED_UNICODE);
  exit;
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>ক্ষুদ্র ঋণ বীমা</title>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bangla:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    :root{
      --blue:#0085d9; --ink:#0b2233; --paper:#ffffff; --sheet:#f2f8ff;
      --border:#c9d8e5; --shadow:0 10px 30px rgba(0,0,0,.18);
      --seal:url('https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Government_Seal_of_Bangladesh.svg/1200px-Government_Seal_of_Bangladesh.svg.png');
    }
    *{box-sizing:border-box}
    body{margin:0;font-family:'Noto Sans Bangla',system-ui,Arial,sans-serif;color:var(--ink);background:#e8f2fb}

    /* A4 sheet */
    .sheet-wrap{max-width:210mm;margin:16px auto;padding:0 8px}
    .sheet{background:var(--sheet);border:1px solid #e5eff8;border-radius:10px;box-shadow:var(--shadow);position:relative;overflow:hidden}
    .sheet::after{content:"";position:absolute;inset:0;background-image:var(--seal);background-repeat:no-repeat;background-position:center 55%;background-size:450mm;opacity:.06;filter:grayscale(1);pointer-events:none}

    /* header */
    .header{position:relative;background:var(--blue);color:#fff;padding:18px 18px 70px}
    .header h1{margin:0;font-weight:700;letter-spacing:1px;font-size:clamp(26px,4.6vw,44px)}
    .photo-container{position:absolute;top:18px;right:18px;width:clamp(120px,22vw,170px);height:clamp(130px,24vw,185px);border:6px solid var(--blue);border-radius:8px;overflow:hidden;background:#fff;box-shadow:0 8px 18px rgba(0,0,0,.25)}
    .photo-container img{width:100%;height:100%;object-fit:cover;display:block}
    .logo-circle{position:absolute;left:50%;transform:translateX(-50%);bottom:-40px;width:110px;height:110px;border-radius:50%;background:#fff;box-shadow:0 6px 20px rgba(0,0,0,.15);display:grid;place-items:center;z-index:2;border:6px solid #eaf5ff}
    .logo-circle img{width:76px;height:76px;object-fit:contain}

    /* body */
    .content{padding:56px 16px 16px;display:grid;grid-template-columns:1.05fr .95fr;gap:16px}
    @media (max-width:820px){.content{grid-template-columns:1fr}}

    .info-box{background:#fff;border:1px solid var(--border);border-radius:8px;padding:14px}
    table{width:100%;border-collapse:collapse;margin:0 0 12px}
    th,td{border:1px solid #cfd8e3;padding:9px 10px;text-align:left}
    th{background:#f6fafd;width:120px}
    .description{border:1px solid #e2e8f0;background:#fff;padding:10px;font-size:14px;line-height:1.6}
    .logos{display:flex;justify-content:center;gap:18px;margin-top:14px}
    .logos img{width:70px;height:70px;object-fit:contain;border-radius:50%;background:#fff;border:2px solid #d9e9f6}

    .right{background:#fff;border:1px solid var(--border);border-radius:8px;padding:14px 16px}
    .section-title{font-size:20px;font-weight:700;text-align:center;margin:8px 0 6px}
    .icons{display:flex;justify-content:center;margin:6px 0}
    .icon{font-size:28px;color:var(--blue)}
    .right p,.right ol{font-size:15px;margin:8px 0 16px}
    .right ol{padding-left:18px}

    .footer{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:6px 16px 16px}
    .signature{display:flex;flex-direction:column;align-items:center}
    .signature img{width:140px;height:68px;object-fit:contain;margin-bottom:6px}
    .date{font-size:12px}
    .bottom-bar{background:var(--blue);height:28px;border-radius:0 0 10px 10px}

    /* Admin UI (not printed) */
    .form-wrap{max-width:210mm;margin:12px auto;padding:12px;background:#fff;border:1px solid #e5eff8;border-radius:10px;box-shadow:var(--shadow)}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    @media (max-width:680px){.row{grid-template-columns:1fr}}
    .group{display:flex;flex-direction:column;gap:6px}
    .group input{padding:10px 12px;border:1px solid #cfd8e3;border-radius:8px}
    .btn{background:var(--blue);color:#fff;border:0;padding:10px 14px;border-radius:8px;cursor:pointer;font-weight:700}
    .btn.secondary{background:#16a34a}
    .toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:end}

    .searchbar{display:grid;grid-template-columns:1fr auto;gap:8px;margin:8px 0 14px}
    .searchbar input{padding:10px 12px;border:1px solid #cfd8e3;border-radius:8px}

    @media print{
      @page{size:A4;margin:0}
      body{background:#fff}
      .form-wrap{display:none}
      .sheet-wrap{padding:0;margin:0}
      .sheet{border:none;box-shadow:none;border-radius:0}
    }
  </style>
</head>
<body>

  <!-- ===== Admin controls (not printed) ===== -->
  <div class="form-wrap">
    <h3 style="margin:0 0 8px">অ্যাডমিন কন্ট্রোল</h3>

    <!-- Search: ID / Mobile -->
    <div class="searchbar">
      <input id="q" placeholder="সার্চ করুন (User ID বা মোবাইল নং)">
      <button class="btn" id="searchBtn">সার্চ</button>
    </div>

    <!-- Manual form -->
    <form id="insuranceForm">
      <div class="row">
        <div class="group"><label>নাম</label><input id="name" required></div>
        <div class="group"><label>পিতা</label><input id="father" required></div>
        <div class="group"><label>মাতা</label><input id="mother" required></div>
        <div class="group"><label>সাং</label><input id="sa" required></div>
        <div class="group"><label>পোষ্ট</label><input id="post" required></div>
        <div class="group"><label>থানা</label><input id="thana" required></div>
        <div class="group"><label>জেলা</label><input id="district" required></div>
        <div class="group"><label>মোবাইল নং</label><input id="mobile" required></div>
        <div class="group"><label>ইউজার ছবি</label><input id="photo" type="file" accept="image/*"></div>
        <div class="group"><label>সিগনেচার (বাম)</label><input id="sigLeftInput" type="file" accept="image/*"></div>
        <div class="group"><label>সিগনেচার (ডান)</label><input id="sigRightInput" type="file" accept="image/*"></div>
      </div>
      <div class="toolbar">
        <button class="btn" type="submit">প্রিভিউ আপডেট</button>
        <button class="btn secondary" type="button" onclick="window.print()">Print</button>
      </div>
    </form>
    <small style="color:#475569">💡 সার্চ করেও ফিল্ড বদলাতে পারবেন—দুইভাবেই কাজ করবে। সার্চ/ফর্ম প্রিন্টে দেখা যাবে না।</small>
  </div>

  <!-- ===== Printable sheet ===== -->
  <div class="sheet-wrap">
    <div class="sheet">
      <div class="header">
       <h1>ক্ষুদ্র ঋণ বীমা</h1>
        <div class="photo-container"><img id="photoPreview" alt=""></div>
        <div class="logo-circle">
          <img src="https://www.tbsnews.net/sites/default/files/styles/amp_metadata_content_image_min_696px_wide/public/images/2022/10/02/metlife_360health.png" alt="">
        </div>
      </div>

      <div class="content">
        <!-- left -->
        <div class="info-box">
          <table>
            <tr><th>নাম</th><td id="outName"></td></tr>
            <tr><th>পিতা</th><td id="outFather"></td></tr>
            <tr><th>মাতা</th><td id="outMother"></td></tr>
            <tr><th>সাং</th><td id="outSa"></td></tr>
            <tr><th>পোষ্ট</th><td id="outPost"></td></tr>
            <tr><th>থানা</th><td id="outThana"></td></tr>
            <tr><th>জেলা</th><td id="outDistrict"></td></tr>
            <tr><th>মোবাইল নং</th><td id="outMobile"></td></tr>
          </table>

          <div class="description">
            বীমা হল সম্ভাব্য ক্ষতির ঝুঁকি ব্যবস্থাপনার একটি মাধ্যম। চুক্তির শর্তমতে অনাকাঙ্ক্ষিত ঘটনার ক্ষেত্রে নির্ধারিত সুবিধা প্রদান করা হয়।
          </div>

          <div class="logos">
            <img src="https://www.tbsnews.net/sites/default/files/styles/amp_metadata_content_image_min_696px_wide/public/images/2022/10/02/metlife_360health.png" alt="">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Government_Seal_of_Bangladesh.svg/1200px-Government_Seal_of_Bangladesh.svg.png" alt="">
            <img src="https://ifs.org.uk/sites/default/files/styles/og_image/public/2025-04/The%20World%20Bank%20Group%20logo.png?itok=-MahtDxK" alt="">
          </div>
        </div>

        <!-- right -->
        <div class="right">
          <div class="icons"><div class="icon">👥</div></div>
          <div class="section-title">মৃত্যু সুবিধা</div>
          <p>পলিসির মেয়াদ চলাকালীন সময়ে বীমাকৃত ব্যক্তি মৃত্যু ঘটলে, সুবিধাভোগীকে নির্ধারিত মূল্য প্রদান করা হবে। এবং সকল লোনের টাকা মাফ করা হবে।</p>

          <div class="icons"><div class="icon">💰</div></div>
          <div class="section-title">মেয়াদপূর্তি পূর্ব প্রদান</div>
          <ol>
            <li>মেয়াদের ১/৩ সময় অতিবাহিত হলে অভিহিত মূল্যের ৪২% প্রদান।</li>
            <li>মেয়াদের ২/৩ সময় অতিবাহিত হলে অতিরিক্ত ৩৫% প্রদান।</li>
          </ol>

          <div class="icons"><div class="icon">⚖️</div></div>
          <div class="section-title">মেয়াদপূর্তি সুবিধা</div>
          <p>মেয়াদপূর্তিতে অবশিষ্ট ৭৫% রিভার্সনারি বোনাস ও ক্যাপিটাল গ্রোথ ডিভিডেন্ডসহ (প্রযোজ্য হলে) প্রদান করা হয়।</p>
        </div>
      </div>

      <div class="footer">
        <div class="signature">
          <img id="sigLeft" src="https://via.placeholder.com/140x68?text=Signature+1" alt="">
          <div class="date" id="dateLeft">2025-07-12</div>
        </div>
        <div class="signature">
          <img id="sigRight" src="https://via.placeholder.com/140x68?text=Signature+2" alt="">
          <div class="date" id="dateRight">2025-07-12</div>
        </div>
      </div>

      <div class="bottom-bar"></div>
    </div>
  </div>

  <script>
    // Local demo dataset (optional fallback)
    const DEMO_USERS = {
      "1": {name:"MD RAHAYAN BABU", father:"", mother:"", sa:"", post:"", thana:"", district:"", mobile:"01818258488"},
      "01818258488": {name:"MD RAHAYAN BABU", father:"", mother:"", sa:"", post:"", thana:"", district:"", mobile:"01818258488"}
    };

    const $ = id => document.getElementById(id);

    function fillPreview(){
      $('outName').textContent     = $('name').value.trim();
      $('outFather').textContent   = $('father').value.trim();
      $('outMother').textContent   = $('mother').value.trim();
      $('outSa').textContent       = $('sa').value.trim();
      $('outPost').textContent     = $('post').value.trim();
      $('outThana').textContent    = $('thana').value.trim();
      $('outDistrict').textContent = $('district').value.trim();
      $('outMobile').textContent   = $('mobile').value.trim();
    }

    // Image helpers
    function setImg(input, targetEl){
      const f = input.files?.[0]; if(!f) return;
      const r = new FileReader();
      r.onload = e => targetEl.src = e.target.result;
      r.readAsDataURL(f);
    }
    $('photo').addEventListener('change', e=> setImg(e.target, $('photoPreview')));
    $('sigLeftInput').addEventListener('change', e=> setImg(e.target, $('sigLeft')));
    $('sigRightInput').addEventListener('change', e=> setImg(e.target, $('sigRight')));

    // Manual form updates preview
    $('insuranceForm').addEventListener('submit', e=>{
      e.preventDefault();
      fillPreview();
      document.querySelector('.sheet-wrap').scrollIntoView({behavior:'smooth'});
    });

    // Search by ID or Mobile — calls this same file (?action=lookup)
    $('searchBtn').addEventListener('click', async ()=>{
      const q = $('q').value.trim();
      if(!q) return;

      let data = null;

      try{
        const url = new URL(window.location.href);
        url.search = ''; // ensure clean
        url.hash = '';
        url.searchParams.set('action','lookup');
        url.searchParams.set('q', q);

        const res = await fetch(url.toString(), {headers:{'Accept':'application/json'}});
        if(res.ok){
          const json = await res.json();
          if(json.ok && json.found) data = json.data;
        }
      }catch(e){/* ignore */}

      if(!data && typeof DEMO_USERS !== 'undefined'){
        data = DEMO_USERS[q];
      }

      if(data){
        $('name').value     = data.name     ?? '';
        $('father').value   = data.father   ?? '';
        $('mother').value   = data.mother   ?? '';
        $('sa').value       = data.sa       ?? '';
        $('post').value     = data.post     ?? '';
        $('thana').value    = data.thana    ?? '';
        $('district').value = data.district ?? '';
        $('mobile').value   = data.mobile   ?? '';
        fillPreview();
        document.querySelector('.sheet-wrap').scrollIntoView({behavior:'smooth'});
      }else{
        alert('কোনো ইউজার পাওয়া যায়নি। ম্যানুয়ালি ইনপুট দিন।');
      }
    });

    // First paint
    fillPreview();
  </script>
</body>
</html>
