<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Bank Loan Approval Letter</title>
<style>
  :root{
    --navy:#0a3a5d;
    --page:#ffffff;
    --ink:#1b2533;
    --muted:#4b5563;
    --border:rgba(15,23,42,.12);
    --footer:#e7f5e1;
    --bg:#eef2f7;
    --btn:#0b5ed7;
    --btn-hover:#0949a7;
  }
  *{box-sizing:border-box}
  body{
    margin:0;
    background:var(--bg);
    font-family: Arial, Helvetica, sans-serif;  /* Force Arial or close */
    color:var(--ink);
    -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
  }

  .sheet-wrap{max-width:1020px; margin:18px auto; padding:0 10px}
  .sheet{
    background:var(--page);
    border:1px solid var(--border);
    border-radius:14px;
    overflow:hidden;
    box-shadow:0 18px 40px rgba(2,8,23,.12);
  }
  .header{
    background:var(--navy);
    color:#fff;
    padding:18px 24px;
    display:flex; align-items:center; gap:14px
  }
  .header img.logo{height:50px; width:auto; border-radius:50%}
  .header .title{line-height:1.2; font-weight:600}
  .header .title .big{font-size:22px}
  .header .title .small{font-size:14px; opacity:.9}

  .doc{padding:26px 20px; position:relative}
  h1{text-align:center; font-size:24px; margin-bottom:16px; letter-spacing:.5px; font-weight:800}

  .grid{display:grid; grid-template-columns:1fr 260px; gap:20px}
  @media(max-width:740px){.grid{grid-template-columns:1fr}}

  .kv{display:grid; grid-template-columns:auto 1fr; row-gap:8px; column-gap:10px}
  .kv .label{color:var(--muted); font-weight:700}

  .photoBox{
    position:relative; width:100%; max-width:240px; height:240px;
    border:1px solid var(--border); border-radius:10px; overflow:hidden;
    background:#f5f7fb; margin:auto
  }
  .photoBox img{width:100%; height:100%; object-fit:cover}

  /* Approved stamp as image – LEFT side */
  .stamp{
    position:absolute; left:-20px; top:70px;
    width:130px; height:130px;
    pointer-events:none;
  }
  .stamp img{width:100%; height:100%; object-fit:contain; opacity:0.9}

  .para{margin:16px 0; line-height:1.6}

  .logos{
    display:grid; grid-template-columns:auto 1fr auto; align-items:center;
    gap:16px; padding:4px 0 2px;
  }
  .logos .ifc{justify-self:start; display:flex; align-items:center}
  .logos .ifc img{height:200px; width:auto}
  .logos .mid{justify-self:center; display:flex; gap:18px; align-items:center}
  .logos .mid img{height:56px; width:auto}

  /* === Signature block: image first, label below with line === */
  .logos .right{
    justify-self:end;
    display:flex; flex-direction:column; align-items:center; gap:6px;
    min-width:210px;
  }
  .logos .right img{height:62px; width:auto; object-fit:contain}
  .logos .right .sig-line{
    width:180px; height:0; border-top:1.5px solid rgba(55,65,81,.6);
    margin-top:4px;
  }
  .logos .right .sig-label{
    font-size:14px; color:#374151; white-space:nowrap; font-weight:600;
  }

  @media(max-width:640px){
    .logos{grid-template-columns:1fr; row-gap:10px; text-align:center}
    .logos .ifc{justify-content:center}
    .logos .right{justify-content:center}
  }

  .footer{background:var(--footer); color:#1f2937; padding:10px 18px; font-size:12px; border-top:1px solid #cde7c4}

  .controls{max-width:1020px; margin:20px auto; padding:16px; background:#fff; border:1px solid var(--border); border-radius:12px; display:grid; gap:12px}
  .controls label{font-size:13px; font-weight:600}
  .controls input{width:100%; padding:8px; border:1px solid var(--border); border-radius:6px}

  .controls button{
    background:var(--btn);
    color:#fff;
    padding:10px 16px;
    border:none;
    border-radius:6px;
    font-weight:600;
    cursor:pointer;
    transition:background .2s;
  }
  .controls button:hover{background:var(--btn-hover)}

  @page{ size:A4; margin:10mm; }
  @media print{
    html, body{ background:var(--bg)!important; }
    .controls, button{ display:none !important; }
    .sheet-wrap{ max-width:1020px; margin:0 auto !important; padding:0 !important; }
    .sheet{
      border-radius:14px !important; border:1px solid var(--border) !important;
      outline:1px solid rgba(15,23,42,.06); filter:drop-shadow(0 18px 40px rgba(2,8,23,.08));
    }
  }
</style>
</head>
<body>

<form class="controls" onsubmit="return false;">
  <label>Application Date<input type="date" id="fDate" value="2025-07-12"></label>
  <label>Customer Name<input type="text" id="fName" value="MD SHOHAG ISLAM"></label>
  <label>Phone Number<input type="text" id="fPhone" value="01885576597"></label>
  <label>Loan Amount<input type="number" id="fAmount" value="600000"></label>
  <label>Loan Term (Month)<input type="number" id="fTerm" value="60"></label>
  <label>Interest Rate (%)<input type="number" step="0.01" id="fRate" value="0.2"></label>
  <label>Installment<input type="number" id="fInstall" value="11200"></label>
  <label>Customer Photo<input type="file" id="fPhoto" accept="image/*"></label>
  <label>Author Signature Photo<input type="file" id="fAuth" accept="image/*"></label>
  <button type="button" onclick="printSheet()">🖨️ Print</button>
</form>

<div class="sheet-wrap">
  <div class="sheet" id="printArea">
    <div class="header">
      <img class="logo" src="https://i1.sndcdn.com/avatars-000626773041-u6y0u6-t240x240.jpg" alt="Logo" />
      <div class="title">
        <div class="big">World Bank Microfinance Project</div>
        <div class="small">Bangladesh Group</div>
      </div>
    </div>

    <div class="doc">
      <h1>BANK LOAN APPROVAL LETTER</h1>

      <div class="grid">
        <div>
          <div class="kv">
            <div class="label">Application Date</div><div id="vDate">12, July, 2025</div>
            <div class="label">Customer Name</div><div id="vName">MD SHOHAG ISLAM</div>
            <div class="label">Phone Number</div><div id="vPhone">01885576597</div>
            <div class="label" style="grid-column:1/-1; margin-top:6px">Loan Details</div>
            <div class="label">Loan Amount</div><div id="vAmount">600000 TK</div>
            <div class="label">Loan Term</div><div id="vTerm">60 Month</div>
            <div class="label">Interest Rate</div><div id="vRate">0.2%</div>
            <div class="label">Installment</div><div id="vInstall">11,200 TK</div>
          </div>
        </div>

        <div class="photoBox">
          <img id="vPhoto" alt="Customer photo" />
          <div class="stamp">
            <img src="https://png.pngtree.com/png-vector/20221009/ourmid/pngtree-original-approved-stamp-and-badget-design-red-grunge-png-image_6293837.png" alt="Approved stamp" />
          </div>
        </div>
      </div>

      <p class="para">
        We are pleased to inform you that your loan request has been approved by our bank.
        We have carefully reviewed your application and, based on your documents and financial
        profile, we are confident in your ability to repay the loan amount requested. International
        bank proposed debt restructuring and development project appraisal.
      </p>

      <div class="logos">
        <div class="ifc">
          <img src="https://www.pfgrowth.com/wp-content/uploads/2022/05/IFC-WBG-vertical-RGB-high_0.png" alt="IFC logo" />
        </div>
        <div class="mid">
          <img src="https://www.cirt.gov.bd/wp-content/uploads/2016/08/Bangladesh-Govt-Logo.jpg" alt="Bangladesh Govt logo" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6_%E0%A6%AC%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%82%E0%A6%95%E0%A7%87%E0%A6%B0_%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A4%E0%A7%80%E0%A6%95.svg/2048px-%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6_%E0%A6%AC%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%82%E0%A6%95%E0%A7%87%E0%A6%B0_%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A4%E0%A7%80%E0%A6%95.svg.png" alt="Bangladesh Bank logo" />
        </div>
        <div class="right">
          <img id="vAuth" alt="Authorization signature" />
          <div class="sig-line"></div>
          <div class="sig-label">Authorization signature</div>
        </div>
      </div>
    </div>

    <div class="footer">
      This document has a restricted distribution and may be used by recipients only in the performance of their official; its contents may not otherwise be dismissed without World Bank authorization.
    </div>
  </div>
</div>

<script>
  function formatDate(iso){
    if(!iso) return '';
    const d=new Date(iso+"T12:00:00");
    const opts={day:'2-digit', month:'long', year:'numeric'};
    return new Intl.DateTimeFormat('en-US',opts).format(d);
  }
  fDate.addEventListener('input',e=>vDate.textContent=formatDate(e.target.value));
  fName.addEventListener('input',e=>vName.textContent=e.target.value);
  fPhone.addEventListener('input',e=>vPhone.textContent=e.target.value);
  fAmount.addEventListener('input',e=>vAmount.textContent=Number(e.target.value||0).toLocaleString()+" TK");
  fTerm.addEventListener('input',e=>vTerm.textContent=e.target.value+" Month");
  fRate.addEventListener('input',e=>vRate.textContent=e.target.value+"%");
  fInstall.addEventListener('input',e=>vInstall.textContent=Number(e.target.value||0).toLocaleString()+" TK");

  fPhoto.addEventListener('change',e=>{
    const file=e.target.files[0]; if(!file) return;
    const r=new FileReader(); r.onload=ev=>vPhoto.src=ev.target.result; r.readAsDataURL(file);
  });
  fAuth.addEventListener('change',e=>{
    const file=e.target.files[0]; if(!file) return;
    const r=new FileReader(); r.onload=ev=>document.getElementById('vAuth').src=ev.target.result; r.readAsDataURL(file);
  });

  function printSheet(){
    const html = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Bank Loan Approval Letter</title>
<style>${document.querySelector('style').innerHTML}</style>
</head>
<body>
<div class="sheet-wrap">
${document.getElementById('printArea').outerHTML}
</div>
<script>window.onload=function(){window.focus();window.print();setTimeout(()=>window.close(),50)}<\/script>
</body>
</html>`;
    const win = window.open('', '', 'width=1020,height=900');
    win.document.open(); win.document.write(html); win.document.close();
  }
</script>
</body>
</html>
