<?php
// admin/users.php — fully responsive with inline (label | value) mobile cards
session_start();
require __DIR__.'/config.php';
include __DIR__.'/header.php';

// Flash success message
$success_message = $_SESSION['success_message'] ?? null;
if ($success_message) unset($_SESSION['success_message']);

/* =========================
   Search (name or mobile)
   ========================= */
$q = trim($_GET['q'] ?? '');
$q_digits = preg_replace('/\D+/', '', $q);
$where_sql = '';
$where_params = [];

if ($q !== '') {
    $parts = [];
    $parts[] = 'u.name LIKE ?';   $where_params[] = "%{$q}%";
    $parts[] = 'u.mobile LIKE ?'; $where_params[] = "%{$q}%";
    if ($q_digits !== '' && $q_digits !== $q) {
        $parts[] = "REPLACE(REPLACE(REPLACE(REPLACE(u.mobile,'-',''),' ',''),'+88',''),'+','') LIKE ?";
        $where_params[] = "%{$q_digits}%";
    }
    $where_sql = 'WHERE ' . implode(' OR ', $parts);
}

/* === Create User === */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    $name         = trim($_POST['name'] ?? '');
    $mobile       = trim($_POST['mobile'] ?? '');
    $password     = $_POST['password'] ?? '';
    $bank_method  = trim($_POST['bank_method'] ?? '');
    $bank_account = trim($_POST['bank_account'] ?? '');

    if ($name && $mobile && $password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, mobile, password, bank_method, bank_account) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $mobile, $hashed_password, $bank_method, $bank_account]);
            $_SESSION['success_message'] = "User created successfully!";
            // hard reload same page (preserve search if present)
            $redir = $_SERVER['PHP_SELF'] . '?success=1' . ($q !== '' ? '&q='.urlencode($q) : '');
            header("Location: " . $redir);
            exit();
        } catch (PDOException $e) {
            $error_message = "Error creating user: " . $e->getMessage();
        }
    } else {
        $error_message = "Please fill in all required fields.";
    }
}

/* === Update User basic info === */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $user_id      = (int)($_POST['user_id'] ?? 0);
    $name         = trim($_POST['edit_name'] ?? '');
    $mobile       = trim($_POST['edit_mobile'] ?? '');
    $bank_method  = trim($_POST['edit_bank_method'] ?? '');
    $bank_account = trim($_POST['edit_bank_account'] ?? '');

    if ($user_id > 0 && $name && $mobile) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET name=?, mobile=?, bank_method=?, bank_account=? WHERE id=?");
            $stmt->execute([$name, $mobile, $bank_method, $bank_account, $user_id]);
            $_SESSION['success_message'] = "User updated successfully!";
            $redir = $_SERVER['PHP_SELF'] . '?success=1' . ($q !== '' ? '&q='.urlencode($q) : '');
            header("Location: " . $redir);
            exit();
        } catch (PDOException $e) {
            $error_message = "Error updating user: " . $e->getMessage();
        }
    } else {
        $error_message = "Please fill in all required fields.";
    }
}

/* === Save per-user extra amount (no label) === */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user_extra'])) {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $label = 'মান'; // fixed label for compatibility
    $value_raw = trim($_POST['extra_value'] ?? '');

    if ($user_id > 0) {
        $normalized = preg_replace('/[^\d.]/', '', $value_raw);
        $value = ($normalized !== '') ? $normalized : $value_raw;

        try {
            $st = $pdo->prepare("
                INSERT INTO user_status_extra (user_id, label, value)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE label=VALUES(label), value=VALUES(value)
            ");
            $st->execute([$user_id, $label, $value]);
            $_SESSION['success_message'] = "মান সেভ হয়েছে (User #{$user_id})!";
            $redir = $_SERVER['PHP_SELF'] . '?success=1' . ($q !== '' ? '&q='.urlencode($q) : '');
            header("Location: " . $redir);
            exit();
        } catch (PDOException $e) {
            $error_message = "Error saving amount: " . $e->getMessage();
        }
    } else {
        $error_message = "Invalid user.";
    }
}

/* === Pagination (50 per page) === */
$per_page = 50;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $per_page;

/* Total count for pagination (respect search) */
$count_sql  = "SELECT COUNT(*) FROM users u " . ($where_sql ? $where_sql : "");
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($where_params);
$total_users = (int)$count_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total_users / $per_page));

/* === Query rows (page slice) === */
$sql = "
SELECT
  u.id, u.name, u.mobile, u.bank_method, u.bank_account, u.bank_name, u.branch_name, u.account_holder, u.created_at,

  pi.nid, pi.present_address, pi.permanent_address, pi.job, pi.income, pi.family_members, pi.earning_members, pi.loan_purpose,

  ni.name  AS nominee_name,
  ni.mobile AS nominee_mobile,
  ni.relationship AS nominee_relationship,

  d.user_photo, d.nid_front, d.nid_back, d.signature, d.nominee_photo,

  lr.status       AS last_status,
  lr.amount       AS last_amount,
  lr.duration_months AS last_duration,
  lr.interest_rate AS last_interest,
  lr.total_amount AS last_total,
  lr.method       AS last_method,
  lr.account_number AS last_account,
  lr.created_at   AS last_loan_time,

  ue.label AS extra_label,
  ue.value AS extra_value

FROM users u
LEFT JOIN personal_info pi   ON pi.user_id = u.id
LEFT JOIN nominee_info  ni   ON ni.user_id = u.id
LEFT JOIN documents     d    ON d.user_id  = u.id
LEFT JOIN (
  SELECT t.*
  FROM loan_requests t
  JOIN (
    SELECT user_id, MAX(id) AS max_id
    FROM loan_requests
    GROUP BY user_id
  ) m ON m.user_id = t.user_id AND m.max_id = t.id
) lr ON lr.user_id = u.id
LEFT JOIN user_status_extra ue ON ue.user_id = u.id
{$where_sql}
ORDER BY u.id DESC
LIMIT :limit OFFSET :offset
";

$stmt = $pdo->prepare($sql);

/* bind search params first (if any), then paging params */
$i = 1;
foreach ($where_params as $p) {
    $stmt->bindValue($i++, $p, PDO::PARAM_STR);
}
$stmt->bindValue(':limit',  $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset,   PDO::PARAM_INT);

$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Helper: file link */
function thumb($path) {
    if (!$path) return '—';
    $url = '../uploads/' . htmlspecialchars($path);
    return '<a class="btn-ghost" href="' . $url . '" target="_blank" title="View file">দেখুন</a>';
}
?>

<style>
/* ===== Page-specific styles (works with shared header.css) ===== */

/* sticky search (hidden on mobile) */
.admin-topbar{
  background:#142d4c; padding:16px 12px; border-bottom:1px solid rgba(255,255,255,.08);
  position:sticky; top:62px; z-index:15; box-shadow:0 4px 12px rgba(0,0,0,.25); border-radius:0 0 12px 12px;
}
@media(min-width:992px){ .admin-topbar{ top:0; border-radius:12px; } }

/* sticky sidebar (common selectors; ensure your sidebar wrapper has one of these) */
.admin-sidebar, .sidebar, #admin-sidebar{
  position: sticky;
  top: 0;              /* adjust if you have a fixed top header, e.g., 62px */
  max-height: 100vh;   /* stay within viewport */
  overflow: auto;      /* scroll inside sidebar */
}

.search-wrap{ max-width:1100px; margin:0 auto; display:flex; gap:10px; align-items:center; }
.search-field{ flex:1; position:relative; }
.search-field input{
  width:100%; height:48px; padding:0 46px 0 44px; border-radius:12px;
  background:#1b2b44; color:#fff; border:1px solid #2f4159; outline:none; font-size:14px;
}
.search-field .icon{ position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#94a3b8; font-size:16px; }
.search-field .clear-btn{ position:absolute; right:10px; top:50%; transform:translateY(-50%); background:transparent; border:0; color:#94a3b8; font-size:16px; cursor:pointer; }
.btn-search, .btn-new{ height:48px; border:0; border-radius:10px; padding:0 16px; font-weight:800; cursor:pointer; }
.btn-search{ background:#ff8a00; color:#fff; }
.btn-new{ background:#1b2b44; color:#fff; border:1px solid #2f4159; }

.search-meta{ max-width:1100px; margin:6px auto 0; color:#cbd5e1; font-size:12px; }

.panel{
  background:#142d4c; padding:22px; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,.25);
  max-width:1300px; margin:14px auto 28px;
}
.h{ margin:0 0 16px; font-size:20px; font-weight:700; color:#fff; }

/* create user form (hidden on mobile; inline on desktop) */
.form-row{ display:flex; flex-wrap:wrap; gap:10px; align-items:center; }
@media(min-width:992px){
  .form-row{ flex-wrap:nowrap; overflow:auto; }
  .form-row > *{ flex:0 0 auto; }
}
.input,.select{ background:#1b2b44; color:#fff; border:1px solid #2f4159; border-radius:8px; padding:10px 12px; font-size:14px; }
.btn.primary{ background:#0a3d62; color:#fff; border:0; border-radius:8px; padding:10px 16px; font-weight:700; cursor:pointer; }
.btn-ghost{ display:inline-block; padding:4px 10px; border:1px solid #475569; border-radius:6px; background:transparent; color:#90cdf4; font-size:13px; text-decoration:none; }

/* table */
.table{ width:100%; border-collapse:separate; border-spacing:0 12px; }
.table thead th{
  background:#1b2b44; color:#e0e6ed; padding:12px 10px; font-size:14px; font-weight:700; border-bottom:2px solid #2f4159;
  position:sticky; top:calc(62px + 72px); z-index:5; text-align:left;
}
@media(min-width:992px){ .table thead th{ top:76px; } }
.table tbody tr{ background:#142d4c; border-radius:12px; box-shadow:0 2px 6px rgba(0,0,0,.15); }
.table tbody td{ padding:16px; font-size:13px; color:#d1d5db; vertical-align:top; border-bottom:1px solid rgba(255,255,255,.05); }
.table tbody tr:last-child td{ border-bottom:0; }

.badge{ display:inline-block; padding:4px 10px; border-radius:12px; font-size:12px; font-weight:700; }
.badge.success{ background:#0f5132; color:#d1fae5; }
.badge.pending{ background:#1e3a8a; color:#bfdbfe; }
.badge.process{ background:#7c2d12; color:#fde68a; }
.badge.reject{  background:#7f1d1d; color:#fecaca; }

/* ========== MOBILE: true inline (label | value) cards ========== */
@media(max-width: 768px){
  .admin-topbar, .desktop-only{ display:none !important; }

  .table thead{ display:none; }
  .table, .table tbody, .table tr, .table td{ display:block; width:100%; }
  .table tr{ margin-bottom:12px; border-radius:12px; overflow:hidden; }

  .table td{
    display:grid;
    grid-template-columns: 120px 1fr;
    gap:10px;
    align-items:center;
    padding:12px 14px;
  }
  .table td::before{
    content:attr(data-label);
    grid-column:1;
    color:#9fb0ff;
    font-weight:700;
    font-size:12px;
  }
  .table td > *{ grid-column:2; }

  .hide-sm{ display:none !important; }

  .user-cell-wrap{ display:flex; gap:12px; align-items:center; }
  .user-name{ font-weight:800; color:#fff; }

  .kv{ display:grid; row-gap:6px; }
  .kv .row{ display:grid; grid-template-columns: 100px 1fr; align-items:center; }
  .kv .k{ color:#9fb0ff; font-weight:700; font-size:12px; }
  .kv .v{ font-size:13px; }
  .kv .sub{ grid-column:1 / -1; color:#9ca3af; font-size:12px; margin-top:2px; }
}

/* ===== DESKTOP-ONLY FIX: remove the unwanted gap under the header ===== */
@media (min-width: 769px){
  .table{ border-spacing:0; }
  .table thead th{ top:0; }
}

/* pagination */
.pagination{
  display:flex; gap:8px; align-items:center; justify-content:center;
  margin:14px auto 0; flex-wrap:wrap;
}
.pagination a, .pagination .current{
  padding:8px 12px; border-radius:8px; border:1px solid #2f4159; text-decoration:none;
  color:#e0e6ed; background:#1b2b44; font-size:13px;
}
.pagination .current{ font-weight:800; background:#0a3d62; }
.pagination .disabled{ opacity:.5; pointer-events:none; }
</style>

<!-- Sticky Top Search Bar (hidden on mobile by CSS) -->
<div class="admin-topbar">
  <form class="search-wrap" method="get" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
    <div class="search-field">
      <i class="fa-solid fa-magnifying-glass icon"></i>
      <input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="নাম বা মোবাইল দিয়ে খুঁজুন…">
      <?php if ($q !== ''): ?>
        <button type="button" class="clear-btn" title="Clear" onclick="location.href='<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>'">
          <i class="fa-solid fa-xmark"></i>
        </button>
      <?php endif; ?>
    </div>
    <button class="btn-search" type="submit"><i class="fa-solid fa-search"></i> Search</button>
    <button class="btn-new" type="button" onclick="document.getElementById('create-user-anchor').scrollIntoView({behavior:'smooth'})">
      + New User
    </button>
  </form>
  <div class="search-meta">
    <?php if ($q !== ''): ?>
      Showing page <b><?= $page ?></b> of <b><?= $total_pages ?></b> for <b>"<?= htmlspecialchars($q) ?>"</b> • <?= number_format($total_users) ?> user(s)
    <?php else: ?>
      Showing page <b><?= $page ?></b> of <b><?= $total_pages ?></b> • <?= number_format($total_users) ?> user(s)
    <?php endif; ?>
  </div>
</div>

<div class="panel">
  <h3 class="h">ইউজার তথ্য</h3>

  <?php if ($success_message): ?>
    <div class="flash-success"><?= htmlspecialchars($success_message) ?></div>
  <?php endif; ?>
  <?php if (isset($error_message)): ?>
    <div class="flash-error"><?= htmlspecialchars($error_message) ?></div>
  <?php endif; ?>

  <!-- Create User Form (hidden on mobile by class) -->
  <div id="create-user-anchor" class="desktop-only" style="margin-bottom:20px;padding:16px;border-radius:12px;background:#1b2b44;">
    <h4 style="margin:0 0 12px 0;color:#fff;font-weight:700;">নতুন ইউজার যোগ করুন</h4>
    <form method="post" class="form-row">
      <input class="input" type="text" name="name" placeholder="নাম" required style="max-width:220px;">
      <input class="input" type="text" name="mobile" placeholder="মোবাইল" required style="max-width:220px;">
      <input class="input" type="password" name="password" placeholder="পাসওয়ার্ড" required style="max-width:220px;">
      <select name="bank_method" class="select" style="max-width:160px;">
        <option value="">ব্যাংক মেথড</option>
        <option value="bKash">bKash</option>
        <option value="Nagad">Nagad</option>
        <option value="Rocket">Rocket</option>
        <option value="Bank">Bank</option>
      </select>
      <input class="input" type="text" name="bank_account" placeholder="একাউন্ট নাম্বার" style="max-width:220px;">
      <button class="btn primary" name="create_user" type="submit">ইউজার যোগ করুন</button>
    </form>
  </div>

  <table class="table">
    <thead>
      <tr>
        <th>ইউজার</th>
        <th class="hide-sm">পার্সোনাল</th>
        <th class="hide-sm">এড্রেস</th>
        <th class="hide-sm">নমিনি</th>
        <th class="hide-sm">ডকুমেন্ট</th>
        <th>সর্বশেষ লোন</th>
        <th class="hide-sm">ব্যাংক/পেমেন্ট</th>
        <th class="hide-sm" style="min-width:280px">স্ট্যাটাস – অতিরিক্ত (শুধু “মান”)</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td data-label="ইউজার">
          <div class="user-cell-wrap">
            <?php if (!empty($r['user_photo'])): ?>
              <img src="../uploads/<?= htmlspecialchars($r['user_photo']) ?>" style="width:44px;height:44px;border-radius:50%;object-fit:cover;">
            <?php else: ?>
              <div style="width:44px;height:44px;border-radius:50%;background:#22395d;display:grid;place-items:center;color:#dfe8f7;font-weight:800;">
                <?= strtoupper(mb_substr($r['name'] ?? 'U', 0, 1, 'UTF-8')) ?>
              </div>
            <?php endif; ?>
            <div>
              <div class="user-name"><?= htmlspecialchars($r['name'] ?? '—') ?></div>
              <small style="color:#9ca3af;"><?= htmlspecialchars($r['mobile'] ?? '—') ?></small><br>
              <small style="color:#64748b;">ID #<?= (int)$r['id'] ?> • <?= htmlspecialchars($r['created_at']) ?></small>
            </div>
          </div>
        </td>

        <td class="hide-sm" data-label="পার্সোনাল">
          NID: <b><?= htmlspecialchars($r['nid'] ?? '—') ?></b><br>
          পেশা: <?= htmlspecialchars($r['job'] ?? '—') ?><br>
          আয়: <?= $r['income'] !== null ? number_format($r['income']).' ৳' : '—' ?><br>
          পরিবার: <?= htmlspecialchars($r['family_members'] ?? '—') ?>,
          উপার্জনকারী: <?= htmlspecialchars($r['earning_members'] ?? '—') ?><br>
          উদ্দেশ্য: <?= htmlspecialchars($r['loan_purpose'] ?? '—') ?>
        </td>

        <td class="hide-sm" style="max-width:280px;word-break:break-word;" data-label="এড্রেস">
          বর্তমান: <?= htmlspecialchars($r['present_address'] ?? '—') ?><br>
          স্থায়ী: <?= htmlspecialchars($r['permanent_address'] ?? '—') ?>
        </td>

        <td class="hide-sm" data-label="নমিনি">
          নাম: <?= htmlspecialchars($r['nominee_name'] ?? '—') ?><br>
          মোবাইল: <?= htmlspecialchars($r['nominee_mobile'] ?? '—') ?><br>
          সম্পর্ক: <?= htmlspecialchars($r['nominee_relationship'] ?? '—') ?>
        </td>

        <td class="hide-sm" data-label="ডকুমেন্ট">
          ইউজার ছবি: <?= thumb($r['user_photo']) ?><br>
          NID ফ্রন্ট: <?= thumb($r['nid_front']) ?><br>
          NID ব্যাক: <?= thumb($r['nid_back']) ?><br>
          স্বাক্ষর: <?= thumb($r['signature']) ?><br>
          নমিনি ছবি: <?= thumb($r['nominee_photo']) ?>
        </td>

        <td data-label="সর্বশেষ লোন">
          <?php if ($r['last_amount'] !== null): ?>
            <div class="kv">
              <div class="row"><span class="k">পরিমাণ</span><span class="v"><b><?= number_format($r['last_amount']) ?> ৳</b></span></div>
              <div class="row"><span class="k">মেয়াদ</span><span class="v"><?= (int)$r['last_duration'] ?> মাস</span></div>
              <div class="row"><span class="k">সুদ</span><span class="v"><?= (float)$r['last_interest'] ?>%</span></div>
              <div class="row"><span class="k">মোট</span><span class="v"><?= number_format($r['last_total']) ?> ৳</span></div>
              <div class="row"><span class="k">মেথড</span><span class="v"><?= htmlspecialchars($r['last_method'] ?? '—') ?></span></div>
              <div class="row"><span class="k">একাউন্ট</span><span class="v"><?= htmlspecialchars($r['last_account'] ?? '—') ?></span></div>
              <div class="row"><span class="k">স্ট্যাটাস</span>
                <span class="v">
                  <?php
                    $status_map = [
                      'Pending'  => 'badge pending',
                      'Process'  => 'badge process',
                      'Success'  => 'badge success',
                      'Rejected' => 'badge reject'
                    ];
                    $cls = $status_map[$r['last_status']] ?? 'badge';
                  ?>
                  <span class="<?= $cls ?>"><?= htmlspecialchars($r['last_status'] ?? '—') ?></span>
                </span>
              </div>
              <div class="sub"><?= htmlspecialchars($r['last_loan_time']) ?></div>
            </div>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>

        <td class="hide-sm" data-label="ব্যাংক/পেমেন্ট">
          মেথড: <?= htmlspecialchars($r['bank_method'] ?? '—') ?><br>
          একাউন্ট: <?= htmlspecialchars($r['bank_account'] ?? '—') ?><br>
          ব্যাংক: <?= htmlspecialchars($r['bank_name'] ?? '—') ?><br>
          ব্রাঞ্চ: <?= htmlspecialchars($r['branch_name'] ?? '—') ?><br>
          একাউন্ট হোল্ডার: <?= htmlspecialchars($r['account_holder'] ?? '—') ?>
        </td>

        <td class="hide-sm" data-label="স্ট্যাটাস – অতিরিক্ত (মান)">
          <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <input type="hidden" name="user_id" value="<?= (int)$r['id'] ?>">
            <input class="input" type="number" step="0.01" min="0" name="extra_value"
                   value="<?= htmlspecialchars($r['extra_value'] ?? '') ?>"
                   placeholder="মান" style="max-width:140px;font-size:13px;">
            <button class="btn primary" name="save_user_extra" type="submit" style="padding:8px 12px;font-size:13px;">সেভ</button>
            <?php if ($r['extra_value'] !== null && $r['extra_value'] !== ''): ?>
              <div style="font-size:12px;color:#cbd5e1;background:rgba(255,255,255,.05);padding:4px 8px;border-radius:4px;margin-top:4px;">
                দেখাবে: <b><?= htmlspecialchars(is_numeric($r['extra_value']) ? number_format((float)$r['extra_value'], 2) : $r['extra_value']) ?></b> <?= is_numeric($r['extra_value']) ? '৳' : '' ?>
              </div>
            <?php endif; ?>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <?php
    // build base url preserving q
    $base = htmlspecialchars($_SERVER['PHP_SELF']);
    $qs   = [];
    if ($q !== '') $qs['q'] = $q;
    $mk = function($p) use ($base, $qs){
      $qs['page'] = $p;
      return $base . '?' . http_build_query($qs);
    };
  ?>
  <div class="pagination">
    <a class="<?= $page <= 1 ? 'disabled' : '' ?>" href="<?= $page <= 1 ? '#' : $mk($page-1) ?>">&laquo; Prev</a>
    <span class="current">Page <?= $page ?> / <?= $total_pages ?></span>
    <a class="<?= $page >= $total_pages ? 'disabled' : '' ?>" href="<?= $page >= $total_pages ? '#' : $mk($page+1) ?>">Next &raquo;</a>
  </div>
</div>

<?php include __DIR__.'/footer.php'; ?>
