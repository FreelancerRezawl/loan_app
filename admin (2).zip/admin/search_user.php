<?php
// search_user.php
require __DIR__.'/auth.php';
session_start();
require __DIR__.'/config.php';

$err   = '';
$q     = trim($_POST['q'] ?? '');
$type  = $_POST['type'] ?? ''; // 'user' | 'loan'
$user  = null;
$loans = [];
$docs  = null;
$pers  = null;
$nomi  = null;

// Where your uploaded files are served from (relative to THIS file)
$UPLOAD_BASE_URL = '../uploads/';

function fetch_user_by_q(PDO $pdo, string $q) {
  $isId = ctype_digit($q);
  if ($isId) {
    $st = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $st->execute([$q]);
    $u = $st->fetch(PDO::FETCH_ASSOC);
    if ($u) return $u;
  }
  $st = $pdo->prepare("SELECT * FROM users WHERE mobile = ?");
  $st->execute([$q]);
  return $st->fetch(PDO::FETCH_ASSOC) ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($q === '') {
    $err = 'অনুগ্রহ করে ইউজার নাম্বার দিন';
  } elseif (!in_array($type, ['user','loan'], true)) {
    $err = 'আপনি কী দেখতে চান নির্বাচন করুন';
  } else {
    $user = fetch_user_by_q($pdo, $q);
    if (!$user) {
      $err = 'মিল পাওয়া যায়নি (ভুল ইউজার আইডি/মোবাইল)';
    } else {
      $uid = (int)$user['id'];
      if ($type === 'user') {
        $st = $pdo->prepare("SELECT * FROM personal_info WHERE user_id=?");
        $st->execute([$uid]);
        $pers = $st->fetch(PDO::FETCH_ASSOC) ?: null;

        $st = $pdo->prepare("SELECT * FROM nominee_info WHERE user_id=?");
        $st->execute([$uid]);
        $nomi = $st->fetch(PDO::FETCH_ASSOC) ?: null;

        $st = $pdo->prepare("SELECT * FROM documents WHERE user_id=?");
        $st->execute([$uid]);
        $docs = $st->fetch(PDO::FETCH_ASSOC) ?: null;
      } else {
        $st = $pdo->prepare("SELECT id, amount, duration_months, interest_rate, total_amount, method, account_number, status, created_at
                             FROM loan_requests WHERE user_id=? ORDER BY created_at DESC, id DESC LIMIT 100");
        $st->execute([$uid]);
        $loans = $st->fetchAll(PDO::FETCH_ASSOC);
      }
    }
  }
}
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WBLB Admin — Search</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
  /* ===== Admin layout (same style as your other pages) ===== */
  :root{
    --bg:#0f1222; --surface:#11152b; --panel:#151936; --card:#171b34;
    --text:#e9ecf1; --muted:#a9b2c7; --brand:#6c5ce7; --ok:#00c29a;
    --border:rgba(255,255,255,.08); --shadow:0 8px 24px rgba(0,0,0,.25);
    --radius:18px; --radius-lg:22px; --tile-yellow:#ffd451; --tile-white:#ffffff;
  }
  *{box-sizing:border-box}
  html,body{height:100%}
  body{
    margin:0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    color:var(--text);
    background:linear-gradient(145deg,#0d1020,#0b0f1c 60%,#0a0e19);
    -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;
  }
  .app{ display:grid; grid-template-rows:auto 1fr; min-height:100dvh; }
  .topbar{
    display:flex;align-items:center;justify-content:space-between; padding:12px 16px;
    background:rgba(15,18,34,.7); backdrop-filter: blur(10px);
    position:sticky; top:0; z-index:20; border-bottom:1px solid var(--border);
  }
  .brand{display:flex;align-items:center;gap:10px;font-weight:800}
  .brand-bubble{
    width:36px;height:36px;border-radius:50%;
    background:linear-gradient(45deg,var(--brand),var(--ok));
    display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;
    box-shadow:var(--shadow); font-size:14px;
  }
  .actions{display:flex;align-items:center;gap:10px}
  .iconbtn{
    width:38px;height:38px;border-radius:12px;border:none;cursor:pointer;
    display:flex;align-items:center;justify-content:center;
    background:#151935;color:#c8d0e6;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.04), var(--shadow);
  }

  /* Sidebar (mobile drawer RIGHT / desktop fixed LEFT) */
  .sidebar{
    position:fixed; inset:0 0 0 auto; width:min(82vw,320px);
    background:linear-gradient(180deg,#121736,#11152b);
    transform:translateX(100%); transition:transform .25s ease;
    z-index:30; color:#dfe5f8; border-left:1px solid var(--border);
    display:flex; flex-direction:column;
  }
  .sidebar.open{ transform:translateX(0); }
  .sidebar .brand{ padding:16px;border-bottom:1px solid var(--border); }
  .nav{ padding:10px; display:flex; flex-direction:column; gap:6px; }
  .nav a{
    display:flex; align-items:center; gap:12px;
    padding:12px 12px; border-radius:12px; text-decoration:none;
    color:#dce3fb; font-weight:600; border:1px solid transparent;
  }
  .nav a i{ width:26px; text-align:center; }
  .nav a:hover, .nav a.active{ background:#161b3d; border-color:var(--border); }

  .overlay{ position:fixed; inset:0; background:rgba(0,0,0,.35);
    opacity:0; visibility:hidden; transition:.2s ease; z-index:25; }
  .overlay.show{ opacity:1; visibility:visible; }

  .main{ padding:16px; }
  @media (min-width: 992px){
    .app{ grid-template-columns:260px 1fr; grid-template-rows:auto 1fr; }
    .sidebar{ position:sticky; inset:auto; transform:none; width:auto; height:100dvh; z-index:5;
      grid-row:1 / span 2; grid-column:1; border-left:none; border-right:1px solid var(--border); }
    .topbar{ grid-column:2; }
    .main{ grid-column:2; padding:24px; }
    .overlay{ display:none; }
  }

  /* ===== Your search page styles (unchanged visuals), scoped ===== */
  .search-page{
    /* replaces your original body centering */
    display:flex; justify-content:center; align-items:flex-start;
    min-height:calc(100dvh - 70px); /* leave room for topbar */
  }
  .search-page .wrap{width:100%; max-width:860px; padding:16px 14px 60px}
  .search-page .card{
    background:#0f1e35; border:1px solid var(--border);
    border-radius:16px; padding:16px; box-shadow:0 8px 24px rgba(0,0,0,.35);
  }

  .search-page .search{display:grid; grid-template-columns:1fr; gap:10px}
  .search-page .input{
    width:100%; padding:12px 14px; border-radius:12px;
    background:#172745; border:1px solid var(--border); color:#e9ecf1; font-size:16px; outline:none;
  }
  .search-page .input::placeholder{color:#8ea0bf}
  .search-page .input:focus{border-color:#2f7bff; box-shadow:0 0 0 2px rgba(47,123,255,.25)}
  .search-page .btn{appearance:none; border:0; cursor:pointer; padding:12px 14px; border-radius:12px; font-weight:700; font-size:15px}
  .search-page .btn.primary{background:#2f7bff; color:#fff}
  .search-page .btn.alt{background:#1f335a; color:#fff}
  .search-page .err{margin-top:10px; background:#391417; color:#ffc7c7; border:1px solid #5a1f24; padding:10px 12px; border-radius:10px}

  .search-page .title{font-size:18px; font-weight:800; margin:0 0 8px}
  .search-page .sub{color:#a9b2c7; font-size:13px; margin-bottom:10px}

  .search-page .grid{display:grid; gap:12px}
  @media (min-width:720px){
    .search-page .search{grid-template-columns:1fr auto auto}
    .search-page .grid{grid-template-columns:1fr 1fr}
  }
  .search-page .kv{display:grid; grid-template-columns:140px 1fr; gap:8px; padding:10px 12px; background:#13223f; border:1px solid var(--border); border-radius:12px}
  .search-page .kv .k{color:#a9b2c7}

  .search-page .tag{display:inline-flex; gap:6px; align-items:center; padding:6px 10px; border-radius:999px; background:#13223f; border:1px solid var(--border); font-size:12px; color:#cfd7ea}

  .search-page .table-wrap{overflow:auto; border:1px solid var(--border); border-radius:14px}
  .search-page table{width:100%; border-collapse:collapse; min-width:760px}
  .search-page th, .search-page td{padding:10px 12px; text-align:left; border-bottom:1px solid rgba(255,255,255,.06)}
  .search-page th{background:#16264a; color:#cfd7ea; font-weight:700}
  .search-page tr:hover td{background:rgba(255,255,255,.03)}
  .search-page .status{font-weight:800}
  .search-page .status.Pending{color:#ffd451}
  .search-page .status.Process{color:#7ab3ff}
  .search-page .status.Success{color:#45df9b}
  .search-page .status.Fail{color:#ff7b7b}

  .search-page .section{margin-top:16px}
  .search-page .muted{color:#a9b2c7}

  /* Document gallery */
  .search-page .doc-grid{display:grid; grid-template-columns:repeat(2,1fr); gap:12px}
  @media (min-width:720px){ .search-page .doc-grid{grid-template-columns:repeat(4,1fr)} }
  .search-page .thumb{background:#13223f; border:1px solid var(--border); border-radius:12px; overflow:hidden}
  .search-page .thumb a{display:block; text-decoration:none; color:inherit}
  .search-page .thumb img{display:block; width:100%; height:160px; object-fit:cover; background:#0d1528}
  .search-page .thumb .cap{padding:8px 10px; font-size:13px; display:flex; justify-content:space-between; align-items:center; gap:8px}
  .search-page .thumb .cap .open{font-size:12px; color:#9fb5ff; text-decoration:underline}

  /* Modal viewer */
  .modal{
    position:fixed; inset:0; background:rgba(0,0,0,.8);
    display:none; align-items:center; justify-content:center; padding:16px; z-index:9999;
  }
  .modal.open{display:flex}
  .modal img{max-width:100%; max-height:90dvh; display:block; border-radius:12px}
  .modal .close{
    position:absolute; top:12px; right:12px; background:#111a30; border:1px solid var(--border);
    color:#fff; border-radius:999px; padding:8px 12px; font-weight:700; cursor:pointer;
  }
</style>
</head>
<body>
<div class="app">
  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="brand-bubble">W</div>
      <div>WBLB Admin</div>
    </div>
    <nav class="nav">
      <a href="index.php"><i class="fa-solid fa-gauge-high"></i> ড্যাশবোর্ড</a>
      <a href="search_user.php" class="active"><i class="fa-solid fa-magnifying-glass"></i> খুঁজুন</a>
      <a href="users.php"><i class="fa-solid fa-users"></i> ইউজার</a>
      <a href="loan_settings.php"><i class="fa-solid fa-sliders"></i> লোন সেটিংস</a>
      <a href="loan_requests.php"><i class="fa-solid fa-file-invoice-dollar"></i> লোন রিকোয়েস্ট</a>
      <a href="documents.php"><i class="fa-solid fa-file-lines"></i> ডকুমেন্ট</a>
      <a href="deposit_settings.php"><i class="fa-solid fa-gear"></i> ডিপোজিট সেটিংস</a>
      <a href="deposits.php"><i class="fa-solid fa-wallet"></i> ডিপোজিট সাবমিশন</a>
      <a href="reviews.php"><i class="fa-solid fa-star"></i> রিভিউ</a>
      <a href="content.php"><i class="fa-solid fa-pen-to-square"></i> কনটেন্ট</a>
      <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> লগ আউট</a>
    </nav>
  </aside>

  <!-- Topbar -->
  <header class="topbar">
    <div class="brand">
      <div class="brand-bubble">W</div>
      <div>WBLB Admin</div>
    </div>
    <div class="actions">
      <button class="iconbtn" aria-label="Notifications"><i class="fa-regular fa-bell"></i></button>
      <button class="iconbtn" id="drawerToggle" aria-label="Menu"><i class="fa-solid fa-bars-staggered"></i></button>
    </div>
  </header>

  <!-- Main -->
  <main class="main">
    <!-- Your original search page content (unchanged visuals) -->
    <section class="search-page">
      <div class="wrap">
        <div class="card">
          <div class="title">Search</div>
          <div class="sub">Enter <b>User Number</b> (mobile or user ID), then choose what to view.</div>

          <form method="post" class="search" autocomplete="off">
            <input class="input" type="text" name="q" placeholder="User Number (e.g., 017XXXXXX or 1)" value="<?= htmlspecialchars($q) ?>" required>
            <button class="btn alt"     type="submit" name="type" value="user">User Details</button>
            <button class="btn primary" type="submit" name="type" value="loan">Loan Details</button>
          </form>

          <?php if ($err): ?><div class="err"><?= htmlspecialchars($err) ?></div><?php endif; ?>
        </div>

        <?php if ($user && $type === 'user'): ?>
          <div class="card section">
            <div class="title">User Details</div>
            <div class="grid">
              <div class="kv"><div class="k">User ID</div><div><?= (int)$user['id'] ?></div></div>
              <div class="kv"><div class="k">Name</div><div><?= htmlspecialchars($user['name'] ?? '') ?></div></div>
              <div class="kv"><div class="k">Mobile</div><div><?= htmlspecialchars($user['mobile'] ?? '') ?></div></div>
              <div class="kv"><div class="k">Created</div><div><?= htmlspecialchars($user['created_at'] ?? '') ?></div></div>
              <div class="kv"><div class="k">Bank Method</div><div><?= htmlspecialchars($user['bank_method'] ?? '—') ?></div></div>
              <div class="kv"><div class="k">Bank Account</div><div><?= htmlspecialchars($user['bank_account'] ?? '—') ?></div></div>
              <div class="kv"><div class="k">Bank Name</div><div><?= htmlspecialchars($user['bank_name'] ?? '—') ?></div></div>
              <div class="kv"><div class="k">Branch</div><div><?= htmlspecialchars($user['branch_name'] ?? '—') ?></div></div>
              <div class="kv"><div class="k">Account Holder</div><div><?= htmlspecialchars($user['account_holder'] ?? '—') ?></div></div>
            </div>

            <div class="section">
              <div class="title">Personal Info</div>
              <?php if ($pers): ?>
                <div class="grid">
                  <div class="kv"><div class="k">NID</div><div><?= htmlspecialchars($pers['nid'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Job</div><div><?= htmlspecialchars($pers['job'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Income</div><div><?= htmlspecialchars($pers['income'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Family Members</div><div><?= htmlspecialchars($pers['family_members'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Earning Members</div><div><?= htmlspecialchars($pers['earning_members'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Loan Purpose</div><div><?= htmlspecialchars($pers['loan_purpose'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Present Address</div><div><?= htmlspecialchars($pers['present_address'] ?? ($pers['address'] ?? '—')) ?></div></div>
                  <div class="kv"><div class="k">Permanent Address</div><div><?= htmlspecialchars($pers['permanent_address'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">House Own</div><div><?= htmlspecialchars($pers['house_own'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Car Own</div><div><?= htmlspecialchars($pers['car_own'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Name (PI)</div><div><?= htmlspecialchars($pers['name'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Mobile (PI)</div><div><?= htmlspecialchars($pers['mobile'] ?? '—') ?></div></div>
                </div>
              <?php else: ?>
                <div class="muted">No personal info found.</div>
              <?php endif; ?>
            </div>

            <div class="section">
              <div class="title">Nominee</div>
              <?php if ($nomi): ?>
                <div class="grid">
                  <div class="kv"><div class="k">Name</div><div><?= htmlspecialchars($nomi['name']) ?></div></div>
                  <div class="kv"><div class="k">Mobile</div><div><?= htmlspecialchars($nomi['mobile'] ?? '—') ?></div></div>
                  <div class="kv"><div class="k">Relationship</div><div><?= htmlspecialchars($nomi['relationship']) ?></div></div>
                </div>
              <?php else: ?>
                <div class="muted">No nominee info found.</div>
              <?php endif; ?>
            </div>

            <div class="section">
              <div class="title">Documents</div>
              <?php
                $docItems = [];
                if ($docs) {
                  $map = [
                    'nid_front'     => 'NID Front',
                    'nid_back'      => 'NID Back',
                    'user_photo'    => 'User Photo',
                    'nominee_photo' => 'Nominee Photo',
                    'signature'     => 'Signature',
                  ];
                  foreach ($map as $k => $label) {
                    $fname = $docs[$k] ?? '';
                    if (!empty($fname)) {
                      $safe = basename($fname);
                      $url  = $UPLOAD_BASE_URL . rawurlencode($safe);
                      $docItems[] = ['label'=>$label, 'url'=>$url, 'safe'=>$safe];
                    }
                  }
                }
              ?>
              <?php if (!empty($docItems)): ?>
                <div class="doc-grid">
                  <?php foreach ($docItems as $d): ?>
                    <div class="thumb">
                      <a href="<?= htmlspecialchars($d['url']) ?>" target="_blank" rel="noopener">
                        <img src="<?= htmlspecialchars($d['url']) ?>" alt="<?= htmlspecialchars($d['label']) ?>" loading="lazy"
                             onclick="openModal('<?= htmlspecialchars($d['url']) ?>'); return false;">
                      </a>
                      <div class="cap">
                        <span><?= htmlspecialchars($d['label']) ?></span>
                        <a class="open" href="<?= htmlspecialchars($d['url']) ?>" target="_blank" rel="noopener">Open original</a>
                      </div>
                    </div>
                  <?php endforeach; ?>
                </div>
              <?php else: ?>
                <div class="muted">No documents uploaded.</div>
              <?php endif; ?>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($user && $type === 'loan'): ?>
          <div class="card section">
            <div class="title">Loan Details for <span class="tag">#<?= (int)$user['id'] ?></span> <span class="tag"><?= htmlspecialchars($user['name']) ?></span></div>
            <?php if (!$loans || count($loans) === 0): ?>
              <div class="muted">No loan requests found.</div>
            <?php else: ?>
              <div class="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>ID</th><th>Amount</th><th>Months</th><th>Interest %</th><th>Total</th>
                      <th>Method</th><th>Account / Notes</th><th>Status</th><th>Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($loans as $L): ?>
                      <tr>
                        <td><?= (int)$L['id'] ?></td>
                        <td><?= number_format((float)$L['amount'], 2) ?></td>
                        <td><?= (int)$L['duration_months'] ?></td>
                        <td><?= rtrim(rtrim((string)$L['interest_rate'], '0'), '.') ?></td>
                        <td><?= number_format((float)$L['total_amount'], 2) ?></td>
                        <td><?= htmlspecialchars($L['method'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($L['account_number'] ?? '—') ?></td>
                        <td class="status <?= htmlspecialchars($L['status']) ?>"><?= htmlspecialchars($L['status']) ?></td>
                        <td><?= htmlspecialchars($L['created_at']) ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
  </main>

  <!-- Mobile drawer overlay -->
  <div class="overlay" id="overlay"></div>
</div>

<!-- Fullscreen Image Modal (unchanged) -->
<div class="modal" id="docModal" onclick="closeModal()">
  <button class="close" type="button" onclick="closeModal(); event.stopPropagation();">✕ Close</button>
  <img id="docModalImg" src="" alt="Document">
</div>

<script>
  // Sidebar drawer controls
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const toggle  = document.getElementById('drawerToggle');
  if (toggle) {
    toggle.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      overlay.classList.toggle('show');
    });
  }
  if (overlay) overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });

  // Document modal (unchanged)
  function openModal(src){
    const m = document.getElementById('docModal');
    const img = document.getElementById('docModalImg');
    img.src = src;
    m.classList.add('open');
  }
  function closeModal(){
    const m = document.getElementById('docModal');
    const img = document.getElementById('docModalImg');
    img.src = '';
    m.classList.remove('open');
  }
</script>
</body>
</html>
