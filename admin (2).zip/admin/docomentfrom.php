<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ডকুমেন্ট ফরম লিংক</title>
  <style>
    body {
      margin: 0;
      font-family: "Noto Sans Bengali", Arial, sans-serif;
      background: #0f1222;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .card {
      background: #1b1f36;
      padding: 20px 30px;
      border-radius: 12px;
      max-width: 400px;
      text-align: center;
      box-shadow: 0 8px 20px rgba(0,0,0,0.4);
    }

    h1 {
      font-size: 22px;
      margin-bottom: 20px;
      font-weight: bold;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
    }

    .btn {
      display: block;
      padding: 12px 10px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: bold;
      text-decoration: none;
      color: #fff;
      transition: 0.3s;
    }

    .btn:hover {
      opacity: 0.8;
      transform: translateY(-2px);
    }

    /* Button colors */
    .blue   { background: #2d9cdb; }
    .green  { background: #27ae60; }
    .pink   { background: #e056fd; }
    .yellow { background: #f1c40f; color:#111; }
    .orange { background: #e67e22; }
    .red    { background: #c0392b; }
    .cyan   { background: #16a085; }
  </style>
</head>
<body>
  <div class="card">
    <h1>ডকুমেন্ট ফরম লিংক</h1>
    <div class="grid">
      <a href="approval.php" class="btn blue">১. ঋণ অনুমোদন পত্র</a>
      <a href="ongikar.php" class="btn green">২. চুক্তি  পত্র</a>
      <a href="idcard.php" class="btn pink">৩. আইডি কার্ড  </a>
      <a href="#" class="btn yellow">৪. জীবন বীমা</a>
      <a href="#" class="btn orange">৫. Online data</a>
      <a href="check.php" class="btn red">৬. Check Book</a>
      <a href="loan_documents.pdf" class="btn orange">৭. Stamp Paper</a>
      <a href="reset_password.php" class="btn cyan">৮. পাসওয়ার্ড পরিবর্তন</a>
    </div>
  </div>
</body>
</html>
