<?php
// index.php — One file: PHP + HTML + CSS + JS
require __DIR__.'/auth.php';
require __DIR__.'/config.php';

$u = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$r = (int)$pdo->query("SELECT COUNT(*) FROM loan_requests")->fetchColumn();
$p = (int)$pdo->query("SELECT COUNT(*) FROM loan_requests WHERE status='Pending'")->fetchColumn();
$s = (int)$pdo->query("SELECT COUNT(*) FROM loan_requests WHERE status='Success'")->fetchColumn();
?>
<!doctype html>
<html lang="bn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>WBLB Admin — ড্যাশবোর্ড</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --bg:#0f1222; --surface:#11152b; --panel:#151936; --card:#171b34;
      --text:#e9ecf1; --muted:#a9b2c7; --brand:#6c5ce7; --ok:#00c29a;
      --border:rgba(255,255,255,.08); --shadow:0 8px 24px rgba(0,0,0,.25);
      --radius:18px; --radius-lg:22px; --tile-yellow:#ffd451; --tile-white:#ffffff;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0; font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
      color:var(--text);
      background:linear-gradient(145deg,#0d1020,#0b0f1c 60%,#0a0e19);
      -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;
    }
    .app{ display:grid; grid-template-rows:auto 1fr; min-height:100dvh; }
    .topbar{
      display:flex; align-items:center; justify-content:space-between;
      padding:12px 16px; background:rgba(15,18,34,.7); backdrop-filter:blur(10px);
      position:sticky; top:0; z-index:20; border-bottom:1px solid var(--border);
    }
    .brand{ display:flex; align-items:center; gap:10px; font-weight:800 }
    .brand-bubble{
      width:36px;height:36px;border-radius:50%;
      background:linear-gradient(45deg,var(--brand),var(--ok));
      display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900;
      box-shadow:var(--shadow); font-size:14px;
    }
    .actions{display:flex;align-items:center;gap:10px}
    .iconbtn{
      width:38px;height:38px;border-radius:12px;border:none;cursor:pointer;
      display:flex;align-items:center;justify-content:center;
      background:#151935;color:#c8d0e6;
      box-shadow:inset 0 1px 0 rgba(255,255,255,.04), var(--shadow);
    }
    .main{ padding:16px; }
    .sidebar{
      position:fixed; inset:0 0 0 auto; width:min(82vw,320px);
      background:linear-gradient(180deg,#121736,#11152b);
      transform:translateX(100%); transition:transform .25s ease;
      z-index:30; color:#dfe5f8; border-left:1px solid var(--border);
      display:flex; flex-direction:column;
    }
    .sidebar.open{ transform:translateX(0); }
    .sidebar .brand{ padding:16px; border-bottom:1px solid var(--border); }
    .nav{ padding:10px; display:flex; flex-direction:column; gap:6px; }
    .nav a{
      display:flex; align-items:center; gap:12px; padding:12px 12px;
      border-radius:12px; text-decoration:none; color:#dce3fb; font-weight:600;
      border:1px solid transparent;
    }
    .nav a i{ width:26px; text-align:center; }
    .nav a:hover, .nav a.active{ background:#161b3d; border-color:var(--border); }
    .overlay{
      position:fixed; inset:0; background:rgba(0,0,0,.35);
      opacity:0; visibility:hidden; transition:.2s ease; z-index:25;
    }
    .overlay.show{ opacity:1; visibility:visible; }
    @media (min-width: 992px){
      .app{ grid-template-columns:260px 1fr; grid-template-rows:auto 1fr; }
      .sidebar{
        position:sticky; inset:auto; transform:none; width:auto; height:100dvh; z-index:5;
        grid-row:1 / span 2; grid-column:1; border-left:none; border-right:1px solid var(--border);
      }
      .topbar{ grid-column:2; }
      .main{ grid-column:2; padding:24px; }
      .overlay{ display:none; }
    }
    .hero{
      background:linear-gradient(145deg,#151b38,#121632 60%,#10142d);
      border:1px solid var(--border); border-radius:26px; padding:18px;
      box-shadow:var(--shadow); margin-bottom:14px;
    }
    .hero h1{ margin:0 0 6px 0; font-size:22px }
    .muted{ color:var(--muted); font-size:14px }
    .quick{
      display:grid; gap:16px; grid-template-columns:repeat(2,minmax(0,1fr)); margin:16px 0;
    }
    @media (min-width:640px){ .quick{ grid-template-columns:repeat(3,1fr); } }
    @media (min-width:992px){ .quick{ grid-template-columns:repeat(4,1fr); } }
    @media (min-width:1200px){ .quick{ grid-template-columns:repeat(5,1fr); } }
    .tile{
      border-radius:22px; padding:18px; cursor:pointer; text-decoration:none;
      color:#0a0e19; box-shadow:var(--shadow); border:1px solid rgba(0,0,0,.05);
      display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:110px;
      transition: transform .12s ease;
    }
    .tile:hover{ transform: translateY(-2px); }
    .tile .ico{ font-size:28px; margin-bottom:10px; }
    .tile .t{ font-weight:800; font-size:16px; line-height:1.2; text-align:center; }
    .tile.yellow{ background:var(--tile-yellow); }
    .desktop-only{ display:none !important; }
  </style>
</head>
<body>
  <div class="app">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
      <div class="brand">
        <div class="brand-bubble">W</div>
        <div>WBLB Admin</div>
      </div>
      <nav class="nav">
        <a href="index.php" class="active"><i class="fa-solid fa-palette"></i> ড্যাশবোর্ড</a>
        <a href="search_user.php"><i class="fa-solid fa-magnifying-glass"></i> খুঁজুন</a>
        <a href="docomentfrom.php"><i class="fa-solid fa-file-signature"></i> সকল ডকুমেন্ট</a>
        <a href="users.php"><i class="fa-solid fa-users"></i> ইউজার</a>
        <a href="loan_settings.php"><i class="fa-solid fa-sliders"></i> লোন সেটিংস</a>
        <a href="loan_requests.php"><i class="fa-solid fa-file-invoice-dollar"></i> লোন রিকোয়েস্ট</a>
        <a href="documents.php"><i class="fa-solid fa-file-lines"></i> ডকুমেন্ট</a>
        <a href="deposit_settings.php"><i class="fa-solid fa-gear"></i> ডিপোজিট সেটিংস</a>
        <a href="deposits.php"><i class="fa-solid fa-wallet"></i> ডিপোজিট সাবমিশন</a>
        <a href="reviews.php"><i class="fa-solid fa-star"></i> রিভিউ</a>
        <a href="content.php"><i class="fa-solid fa-pen-to-square"></i> কনটেন্ট</a>

        <!-- ✅ NEW: Check & Approval -->
        <a href="check.php"><i class="fa-solid fa-clipboard-check"></i> চেক</a>
        <a href="approval.php"><i class="fa-solid fa-square-check"></i> অ্যাপ্রুভাল</a>
        <!-- /NEW -->

        <a href="add_admin.php"><i class="fa-solid fa-plus"></i> এডমিন যোক্ত করুন </a>
        <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> লগ আউট</a>
      </nav>
    </aside>

    <!-- Topbar -->
    <header class="topbar">
      <div class="brand">
        <div class="brand-bubble">W</div>
        <div>WBLB Admin</div>
      </div>
      <div class="actions">
        <button class="iconbtn" aria-label="Notifications"><i class="fa-regular fa-bell"></i></button>
        <button class="iconbtn" id="drawerToggle" aria-label="Menu"><i class="fa-solid fa-bars-staggered"></i></button>
      </div>
    </header>

    <!-- Main -->
    <main class="main">
      <section class="hero">
        <h1>Hi,</h1>
        <div class="muted">World Bank, Welcome to Your Dashboard.</div>
      </section>

      <!-- Tiles: visible on BOTH mobile & desktop -->
      <div class="quick">
        <a class="tile yellow" href="index.php">
          <div class="ico"><i class="fa-solid fa-palette"></i></div>
          <div class="t">ড্যাশবোর্ড</div>
        </a>
        <a class="tile yellow" href="search_user.php">
          <div class="ico"><i class="fa-solid fa-magnifying-glass"></i></div>
          <div class="t">খুঁজুন</div>
        </a>
        <a class="tile yellow" href="docomentfrom.php">
  <div class="ico"><i class="fa-solid fa-file-signature"></i></div>
  <div class="t">সকল ডকুমেন্ট</div>
</a>

        <a class="tile yellow" href="users.php">
          <div class="ico"><i class="fa-solid fa-users"></i></div>
          <div class="t">ইউজার</div>
        </a>
        <a class="tile yellow" href="loan_settings.php">
          <div class="ico"><i class="fa-solid fa-sliders"></i></div>
          <div class="t">লোন সেটিংস</div>
        </a>
        <a class="tile yellow" href="loan_requests.php">
          <div class="ico"><i class="fa-solid fa-file-invoice-dollar"></i></div>
          <div class="t">লোন রিকোয়েস্ট</div>
        </a>
        <a class="tile yellow" href="documents.php">
          <div class="ico"><i class="fa-solid fa-file-lines"></i></div>
          <div class="t">ডকুমেন্ট</div>
        </a>
        <a class="tile yellow" href="deposit_settings.php">
          <div class="ico"><i class="fa-solid fa-gear"></i></div>
          <div class="t">ডিপোজিট সেটিংস</div>
        </a>
        <a class="tile yellow" href="deposits.php">
          <div class="ico"><i class="fa-solid fa-wallet"></i></div>
          <div class="t">ডিপোজিট সাবমিশন</div>
        </a>
        <a class="tile yellow" href="reviews.php">
          <div class="ico"><i class="fa-solid fa-star"></i></div>
          <div class="t">রিভিউ</div>
        </a>
        <a class="tile yellow" href="content.php">
          <div class="ico"><i class="fa-solid fa-pen-to-square"></i></div>
          <div class="t">কনটেন্ট</div>
        </a>

        <!-- ✅ NEW: Check & Approval tiles -->
        <a class="tile yellow" href="check.php">
          <div class="ico"><i class="fa-solid fa-clipboard-check"></i></div>
          <div class="t">চেক</div>
        </a>
        <a class="tile yellow" href="approval.php">
          <div class="ico"><i class="fa-solid fa-square-check"></i></div>
          <div class="t">অ্যাপ্রুভাল</div>
        </a>
         <a class="tile yellow" href="idcard.php">
          <div class="ico"><i class="fa-solid fa-id-card"></i></div>
          <div class="t">আইডি কার্ড </div>
        </a>
        <!-- /NEW -->

        <a class="tile yellow" href="logout.php">
          <div class="ico"><i class="fa-solid fa-right-from-bracket"></i></div>
          <div class="t">লগ আউট</div>
        </a>
      </div>

      <!-- (Optional) Keep counters hidden; remove .desktop-only if you want them back)
      <div class="cards desktop-only">
        <div class="card"><div class="k">ইউজার</div><div class="v"><?= $u ?></div></div>
        <div class="card"><div class="k">মোট রিকোয়েস্ট</div><div class="v"><?= $r ?></div></div>
        <div class="card"><div class="k">পেন্ডিং</div><div class="v"><?= $p ?></div></div>
        <div class="card"><div class="k">সাকসেস</div><div class="v"><?= $s ?></div></div>
      </div>
      -->
    </main>
  </div>

  <!-- Overlay -->
  <div class="overlay" id="overlay"></div>

  <script>
    // Drawer logic (open/close right-side menu)
    const sidebar  = document.getElementById('sidebar');
    const overlay  = document.getElementById('overlay');
    const toggle   = document.getElementById('drawerToggle');

    function openDrawer(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeDrawer(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }

    toggle?.addEventListener('click', () => {
      sidebar.classList.contains('open') ? closeDrawer() : openDrawer();
    });
    overlay?.addEventListener('click', closeDrawer);

    // Close drawer when clicking a nav link (mobile)
    document.querySelectorAll('.nav a').forEach(a=>{
      a.addEventListener('click', closeDrawer);
    });
  </script>
</body>
</html>
