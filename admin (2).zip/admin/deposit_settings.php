<?php
// admin/deposit_settings.php
include 'header.php';
include 'config.php';

// Optional: Admin authentication gatekeeping
// if (!is_admin()) { header("Location: login.php"); exit; }

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payable  = isset($_POST['payable_amt']) ? floatval($_POST['payable_amt']) : 0;
    $bkash    = trim($_POST['bkash_agent'] ?? '');
    $nagad    = trim($_POST['nagad_agent'] ?? '');
    $note     = trim($_POST['note_html'] ?? '');
    $active   = isset($_POST['is_active']) ? 1 : 0;

    $stmt = $pdo->prepare("UPDATE deposit_settings
                           SET payable_amt=?, bkash_agent=?, nagad_agent=?, note_html=?, is_active=?, updated_by=?
                           WHERE id=1");
    $stmt->execute([$payable, $bkash, $nagad, $note, $active, $_SESSION['admin_id'] ?? null]);
    $msg = "সেটিংস আপডেট হয়েছে।";
}

$st = $pdo->query("SELECT * FROM deposit_settings WHERE id=1");
$set = $st->fetch(PDO::FETCH_ASSOC);
if (!$set) { die("deposit_settings missing. Run SQL migration."); }
?>

<!-- Custom Styles -->
<style>
    body {
        background-color: #0c1428;
        color: #e0e6f1;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .panel {
        margin: 2rem auto;
        max-width: 90%;
        padding: 0;
    }

    .card {
        background: #1a237e;
        border: none;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        overflow: hidden;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.4);
    }

    .card-header {
        background: #151b54;
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid #2d3775;
        font-size: 1.25rem;
        font-weight: 600;
        color: #ffffff;
        letter-spacing: 0.5px;
    }

    .card-body {
        background: #f8f9fa; /* Light background for comfortable reading */
        padding: 1.5rem;
    }

    .form-label {
        font-weight: 600;
        color: #333; /* Dark label for better visibility */
        margin-bottom: 0.5rem;
        font-size: 0.95rem;
    }

    .form-control {
        background: #ffffff; /* White background */
        border: 1px solid #ced4da;
        color: #222; /* Black text — easy to read */
        border-radius: 6px;
        padding: 0.75rem;
        transition: all 0.2s ease;
        font-size: 1rem;
        box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);
    }

    .form-control:focus {
        outline: none;
        border-color: #64b5f6;
        box-shadow: 0 0 0 3px rgba(100, 181, 246, 0.2);
        color: #000;
    }

    .form-check-input {
        width: 1.25rem;
        height: 1.25rem;
        border-radius: 50%;
        background: #ffffff;
        border: 1px solid #ced4da;
        cursor: pointer;
    }

    .form-check-input:checked {
        background: #64b5f6;
        border-color: #64b5f6;
    }

    .form-check-label {
        color: #333;
        font-weight: 500;
        margin-left: 0.5rem;
    }

    .btn {
        background: #64b5f6;
        border: none;
        color: #000;
        font-weight: 600;
        padding: 0.75rem 1.5rem;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 1rem;
    }

    .btn:hover {
        background: #4fc3f7;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(100, 181, 246, 0.3);
    }

    .alert-success {
        background: #4caf50;
        color: white;
        padding: 0.75rem;
        border-radius: 6px;
        margin-bottom: 1.5rem;
        font-weight: 500;
        text-align: center;
        border: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .text-muted {
        color: #6c757d !important;
    }

    .row {
        margin: 1rem 0;
    }

    .col-md-6 {
        padding: 0.5rem;
    }

    .mb-3 {
        margin-bottom: 1.5rem;
    }

    .mt-3 {
        margin-top: 1.5rem;
    }

    .small-text {
        font-size: 0.875rem;
        color: #6c757d;
        display: block;
        margin-top: 0.25rem;
    }

    textarea.form-control {
        resize: vertical;
        min-height: 100px;
    }
</style>

<div class="panel">
    <div class="card">
        <div class="card-header">
            📥 ডিপোজিট সেটিংস
        </div>
        <div class="card-body">
            <?php if ($msg): ?>
                <div class="alert alert-success">
                    <?= htmlspecialchars($msg) ?>
                </div>
            <?php endif; ?>

            <form method="POST">
               

                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="bkash_agent" class="form-label">বিকাশ এজেন্ট নাম্বার</label>
                        <input type="text" class="form-control" id="bkash_agent" name="bkash_agent"
                               value="<?= htmlspecialchars($set['bkash_agent']) ?>" placeholder="01XXXXXXXXX">
                    </div>
                    <div class="col-md-6">
                        <label for="nagad_agent" class="form-label">নগদ এজেন্ট নাম্বার</label>
                        <input type="text" class="form-control" id="nagad_agent" name="nagad_agent"
                               value="<?= htmlspecialchars($set['nagad_agent']) ?>" placeholder="01XXXXXXXXX">
                    </div>
                </div>

                <div class="mb-3 mt-3">
                    <label for="note_html" class="form-label">নোট/বার্তা (HTML অনুমোদিত)</label>
                    <textarea name="note_html" id="note_html" class="form-control" rows="3"
                              placeholder="উদাহরণ: &quot;আপনার একাউন্টে টাকা পাঠানোর জন্য ব্যাংক ফি ...&quot;"><?= htmlspecialchars($set['note_html']) ?></textarea>
                    <span class="small-text">উদাহরণ: “আপনার একাউন্টে টাকা পাঠানোর জন্য ব্যাংক ফি প্রদান করুন”</span>
                </div>

                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" name="is_active" id="is_active"
                           <?= $set['is_active'] ? 'checked' : '' ?>>
                    <label class="form-check-label" for="is_active">পেজটি অ্যাকটিভ</label>
                </div>

                <button type="submit" class="btn">💾 সেভ করুন</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>