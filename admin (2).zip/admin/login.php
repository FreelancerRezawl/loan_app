<?php
include 'config.php';
session_start();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $pass  = $_POST['password'] ?? '';

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $err = 'ভুল ইমেইল ফরম্যাট';
  } elseif ($email === '' || $pass === '') {
    $err = 'ইমেইল ও পাসওয়ার্ড দিন';
  } else {
    $st = $pdo->prepare("SELECT * FROM admins WHERE email=?");
    $st->execute([$email]);
    $a = $st->fetch();
    if ($a && password_verify($pass, $a['password'])) {
      $_SESSION['admin_id'] = $a['id'];
      $_SESSION['admin_email'] = $a['email'];
      header("Location: index.php");
      exit;
    } else {
      $err = 'ভুল ইমেইল/পাসওয়ার্ড';
    }
  }
}
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login</title>
<link rel="stylesheet" href="assets/admin.css">
<style>
  :root {
    --bg:#0d1528;
    --card:#0f1e35;
    --text:#e9ecf1;
    --muted:#a9b2c7;
    --brand:#6c5ce7;
    --border:rgba(255,255,255,0.08);
  }

  body {
    margin:0;
    font-family:system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    background:var(--bg);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
    color:var(--text);
  }

  .login {
    width:100%;
    max-width:420px;
    padding:20px;
  }

  .card {
    background:var(--card);
    border:1px solid var(--border);
    border-radius:16px;
    padding:24px;
    box-shadow:0 6px 20px rgba(0,0,0,0.35);
  }

  .title {
    font-weight:800;
    margin:0 0 16px;
    font-size:22px;
    text-align:center;
  }

  .err {
    background:#3a0b0b;
    color:#ffc7c7;
    padding:10px 12px;
    border-radius:10px;
    margin-bottom:14px;
    font-size:14px;
  }

  label {
    display:block;
    margin-bottom:6px;
    color:var(--muted);
    font-size:14px;
  }

  .input {
    width:100%;
    padding:12px;
    border-radius:10px;
    border:1px solid var(--border);
    background:#1b2a44;
    color:var(--text);
    font-size:15px;
    outline:none;
  }

  .input:focus {
    border-color:var(--brand);
    box-shadow:0 0 0 2px rgba(108,92,231,0.3);
  }

  .btn {
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    font-size:16px;
    cursor:pointer;
    transition:0.2s;
  }

  .btn.primary {
    background:var(--brand);
    color:#fff;
    font-weight:600;
  }

  .btn.primary:hover {
    opacity:0.9;
  }
</style>
</head>
<body>
<div class="login">
  <div class="card">
    <h3 class="title">Admin Login</h3>
    <?php if ($err): ?>
      <div class="err"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>
    <form method="post">
      <label>ইমেইল</label>
      <input class="input" type="email" name="email" required>
      <div style="height:14px"></div>
      <label>পাসওয়ার্ড</label>
      <input class="input" type="password" name="password" required>
      <div style="height:18px"></div>
      <button class="btn primary" type="submit">লগ ইন</button>
    </form>
  </div>
</div>
</body>
</html>
