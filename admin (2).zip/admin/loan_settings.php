<?php
include 'header.php';
include 'config.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (isset($_POST['create'])) {
    $amt = max(0, (int)$_POST['amount']);
    $dur = max(1, (int)$_POST['duration_months']);
    $rate = max(0, (float)$_POST['interest_rate']);
    if ($amt > 0 && $dur > 0 && $rate >= 0) {
      $pdo->prepare("INSERT INTO loan_settings(amount,duration_months,interest_rate) VALUES (?,?,?)")
          ->execute([$amt,$dur,$rate]);
    }
  }
  if (isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $amt = max(0, (int)$_POST['amount']);
    $dur = max(1, (int)$_POST['duration_months']);
    $rate = max(0, (float)$_POST['interest_rate']);
    if ($id > 0 && $amt > 0 && $dur > 0 && $rate >= 0) {
      $pdo->prepare("UPDATE loan_settings SET amount=?, duration_months=?, interest_rate=? WHERE id=?")
          ->execute([$amt,$dur,$rate,$id]);
    }
  }
  if (isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    if ($id > 0) {
      $pdo->prepare("DELETE FROM loan_settings WHERE id=?")->execute([$id]);
    }
  }
}

$rows = $pdo->query("SELECT * FROM loan_settings ORDER BY amount ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
  :root{
    --border: rgba(255,255,255,.10);
    --panel: #0f1e35;
    --muted: #a9b2c7;
    --ok:#00c29a; --danger:#e5484d; --brand:#2f7bff;
  }

  .panel{
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    box-shadow: 0 8px 24px rgba(0,0,0,.35);
    margin: 16px;
  }
  .h{ margin:0 0 12px; font-weight:800; font-size:18px }

  /* Create form */
  .form-row{
    display: grid;
    grid-template-columns: 1fr;
    gap: 10px;
    margin-bottom: 14px;
  }
  @media (min-width:720px){
    .form-row{ grid-template-columns: 1fr 1fr 1fr auto; }
  }
  .input{
    width:100%;
    padding:12px 14px;
    border-radius:12px;
    background:#172745;
    border:1px solid var(--border);
    color:#e9ecf1;
    outline:none;
  }
  .input:focus{ border-color:var(--brand); box-shadow:0 0 0 2px rgba(47,123,255,.25) }

  .btn{
    appearance:none; border:0; cursor:pointer;
    padding:12px 14px; border-radius:12px; font-weight:700; font-size:14px;
  }
  .btn.primary{ background:var(--brand); color:#fff }
  .btn.ok{ background:var(--ok); color:#082019 }
  .btn.danger{ background:#3a0b0b; color:#ffc7c7; border:1px solid #5a1f24 }

  /* Table */
  .table-wrap{
    overflow:auto;
    border:1px solid var(--border);
    border-radius:14px;
  }
  .table{
    width:100%;
    border-collapse:collapse;
    min-width:760px; /* enables horizontal scroll on small screens */
    background:transparent;
  }
  .table th, .table td{
    padding:10px 12px;
    border-bottom:1px solid rgba(255,255,255,.06);
    text-align:left;
  }
  .table thead th{
    background:#16264a;
    color:#cfd7ea;
    font-weight:700;
  }
  .table tr:hover td{ background: rgba(255,255,255,.03) }

  /* Inline edit form inside table cell */
  .table .form-row{
    grid-template-columns: 1fr 1fr 1fr auto auto;
    gap:8px;
  }
  .table .input{ min-width: 110px; }
  @media (max-width:720px){
    .table .form-row{
      grid-template-columns: 1fr 1fr;
      grid-auto-rows: minmax(40px, auto);
    }
    .table .form-row .btn{ width:100% } /* buttons full width on mobile */
  }

  /* Optional stacked-table pattern for very small screens */
  @media (max-width:640px){
    .table{ min-width:0 } /* allow stacked mode */
    .table thead{ display:none; }
    .table, .table tbody, .table tr, .table td{ display:block; width:100%; }
    .table tr{ border-bottom:1px solid var(--border); padding:8px }
    .table td{
      display:flex; justify-content:space-between; align-items:center; gap:12px;
      border-bottom:none;
    }
    .table td::before{
      content: attr(data-label);
      color:#9fb0ff; font-weight:700; font-size:12px;
    }
  }

  /* Utilities */
  .row-actions{ display:flex; gap:8px; }
</style>

<div class="panel">
  <h3 class="h">লোন প্ল্যান</h3>

  <form method="post" class="form-row">
    <input class="input" type="number" name="amount" placeholder="পরিমাণ (৳)" required>
    <input class="input" type="number" name="duration_months" placeholder="মেয়াদ (মাস)" required>
    <input class="input" step="0.01" type="number" name="interest_rate" placeholder="সুদ (%)" required>
    <button class="btn primary" name="create">যোগ করুন</button>
  </form>

  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>পরিমাণ</th>
          <th>মেয়াদ</th>
          <th>সুদ</th>
          <th>অ্যাকশন</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
          <tr>
            <td data-label="পরিমাণ"><?= number_format($r['amount']) ?> ৳</td>
            <td data-label="মেয়াদ"><?= (int)$r['duration_months'] ?> মাস</td>
            <td data-label="সুদ"><?= rtrim(rtrim((string)$r['interest_rate'],'0'),'.') ?>%</td>
            <td data-label="অ্যাকশন">
              <form method="post" class="form-row" style="align-items:center">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <input class="input" type="number" name="amount" value="<?= (int)$r['amount'] ?>">
                <input class="input" type="number" name="duration_months" value="<?= (int)$r['duration_months'] ?>">
                <input class="input" step="0.01" type="number" name="interest_rate" value="<?= (float)$r['interest_rate'] ?>">
                <button class="btn ok" name="update">আপডেট</button>
                <button class="btn danger" name="delete" onclick="return confirm('ডিলিট করবেন?')">ডিলিট</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'footer.php'; ?>
