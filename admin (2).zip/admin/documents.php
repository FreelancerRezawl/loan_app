<?php 
include 'header.php'; 
include 'config.php';

$rows = $pdo->query("
  SELECT u.id, u.name, u.mobile, d.nid_front, d.nid_back, d.user_photo, d.nominee_photo, d.signature
  FROM users u
  LEFT JOIN documents d ON d.user_id = u.id
  ORDER BY u.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

function thumb($path) {
  if (!$path) return '—';
  $file = basename($path); // নিরাপত্তার জন্য কেবল ফাইলনেম
  $url  = 'https://bdworldbank.com/uploads/'.rawurlencode($file);
  return '<a class="btn ghost" href="'.$url.'" target="_blank" rel="noopener">দেখুন</a>';
}
?>

<style>
  :root{
    --border: rgba(255,255,255,.10);
    --panel: #0f1e35;
    --muted: #a9b2c7;
  }
  .panel{
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    box-shadow: 0 8px 24px rgba(0,0,0,.35);
    margin: 16px;
  }
  .h{ margin:0 0 12px; font-weight:800; font-size:18px }

  /* Wrapper for horizontal scroll on phones */
  .table-wrap{
    overflow:auto;
    border:1px solid var(--border);
    border-radius:14px;
  }

  .table{
    width:100%;
    border-collapse:collapse;
    min-width: 820px; /* allow scroll on narrow screens */
    background: transparent;
  }
  .table th, .table td{
    padding:10px 12px;
    border-bottom:1px solid rgba(255,255,255,.06);
    text-align:left;
    vertical-align: middle;
  }
  .table thead th{
    background:#16264a;
    color:#cfd7ea;
    font-weight:700;
    position: sticky;
    top: 0;
    z-index: 1;
  }
  .table tr:hover td{ background: rgba(255,255,255,.03) }

  /* Stacked layout for very small screens */
  @media (max-width:640px){
    .table{ min-width:0 }
    .table thead{ display:none; }
    .table, .table tbody, .table tr, .table td{ display:block; width:100%; }
    .table tr{ border-bottom:1px solid var(--border); padding:8px }
    .table td{
      display:flex; justify-content:space-between; gap:12px; border-bottom:none; padding:8px 4px;
    }
    .table td::before{
      content: attr(data-label);
      color:#9fb0ff; font-weight:700; font-size:12px; min-width:120px;
    }
  }

  /* Compact user cell */
  .user-cell .id{
    color:var(--muted); font-size:.9rem; display:block; margin-top:2px;
  }

  /* Ghost button */
  .btn{
    appearance:none; border:0; cursor:pointer;
    padding:8px 12px; border-radius:10px; font-weight:700; font-size:13px;
    display:inline-block; text-align:center;
  }
  .btn.ghost{
    background:#13223f;
    border:1px solid var(--border);
    color:#dfe6ff;
  }
  .btn.ghost:hover{ filter:brightness(1.1) }
</style>

<div class="panel">
  <h3 class="h">ইউজার ডকুমেন্ট</h3>

  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th>ইউজার</th>
          <th>ইউজার ছবি</th>
          <th>NID ফ্রন্ট</th>
          <th>NID ব্যাক</th>
          <th>নমিনি ছবি</th>
          <th>স্বাক্ষর</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
        <tr>
          <td data-label="ইউজার">
            <div class="user-cell">
              <strong><?= htmlspecialchars($r['name'] ?? '—') ?></strong>
              <span class="id">ID #<?= (int)$r['id'] ?> • <?= htmlspecialchars($r['mobile'] ?? '—') ?></span>
            </div>
          </td>
          <td data-label="ইউজার ছবি"><?= thumb($r['user_photo']) ?></td>
          <td data-label="NID ফ্রন্ট"><?= thumb($r['nid_front']) ?></td>
          <td data-label="NID ব্যাক"><?= thumb($r['nid_back']) ?></td>
          <td data-label="নমিনি ছবি"><?= thumb($r['nominee_photo']) ?></td>
          <td data-label="স্বাক্ষর"><?= thumb($r['signature']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'footer.php'; ?>
