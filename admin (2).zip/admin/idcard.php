<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>World Bank – ID Card (Form + Print)</title>
<style>
  :root{
    --navy:#0a3a5d;
    --ink:#0e1320;
    --muted:#4b5563;
    --gold:#f1c40f;
    --pill:#e74c3c;
    --paper:#ffffff;
    --bg:#ececec;
    --radius:14px;
    --shadow:0 14px 30px rgba(2,8,23,.18);
  }
  *{box-sizing:border-box}
  html,body{height:100%}
  body{
    margin:0;
    background:var(--bg);
    font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
    color:var(--ink);
  }

  .wrap{max-width:1100px; margin:28px auto; padding:0 16px;
    display:grid; grid-template-columns: 1.1fr .9fr; gap:22px;}
  @media (max-width:920px){.wrap{grid-template-columns:1fr}}

  .panel{background:#fff; border-radius:16px; box-shadow:var(--shadow);}
  .panel h2{margin:0; padding:16px 18px; border-bottom:1px solid rgba(15,23,42,.08); font-size:18px;}
  .panel .pad{padding:18px}

  .grid{display:grid; gap:14px}
  .grid-2{grid-template-columns:1fr 1fr}
  .field label{display:block; font-size:13px; color:#334155; margin:0 0 6px 2px}
  .field input{width:100%; padding:10px 12px; border:1px solid rgba(15,23,42,.15); border-radius:10px; font-size:15px;}
  .actions{display:flex; gap:10px; margin-top:6px; flex-wrap:wrap}
  .btn{border:0; background:var(--navy); color:#fff; padding:10px 14px; border-radius:10px; font-weight:600; cursor:pointer;}
  .btn.secondary{background:#475569}
  .btn:active{transform:translateY(1px)}

  .stage{display:flex; justify-content:center; align-items:center; padding:22px; background:#eef2f7; border-radius:0 0 16px 16px}
  .id-card{width:340px; height:540px; background:var(--paper); border-radius:12px; box-shadow:0 10px 28px rgba(0,0,0,.22); overflow:hidden; position:relative;}
  .header{background:var(--navy); color:#fff; text-align:center; padding:16px 10px;}
  .header h1{margin:0; font-size:22px}
  .header p{margin:6px 0 0; font-size:13px; line-height:1.35}

  .photo{width:128px; height:128px; border-radius:50%; margin:20px auto 10px; border:4px solid var(--gold); overflow:hidden; background:#f9fafb; position:relative;}
  .photo img{width:100%; height:100%; object-fit:cover; display:block}
  .photo .ph{position:absolute; inset:0; display:flex; align-items:center; justify-content:center; color:#9ca3af; font-size:14px}

  .info{text-align:center; padding:2px 16px}
  .name{margin:8px 0 6px; font-size:20px; font-weight:800; color:#111827}
  .role{display:inline-block; padding:6px 14px; background:var(--pill); color:#fff; border-radius:8px; font-weight:700; font-size:14px}

  .details{padding:12px 22px 0; font-size:14px}
  .details p{margin:8px 0; color:#111}
  .details b{font-weight:700}

  .barcode{position:absolute; left:50%; transform:translateX(-50%); bottom:22px; text-align:center;}
  .barcode img{height:50px; display:none;}

  @media print{
    body{background:#fff}
    .wrap{display:block}
    .panel:first-child{display:none}
    .panel:last-child{box-shadow:none}
    .stage{background:#fff; padding:0}
    .id-card{box-shadow:none; margin:0 auto}
  }
</style>
</head>
<body>

<div class="wrap">
  <div class="panel">
    <h2>Fill ID details</h2>
    <div class="pad">
      <div class="grid grid-2">
        <div class="field"><label>Full Name</label><input id="name" type="text" value="MD. SUMAN"></div>
        <div class="field"><label>Role</label><input id="role" type="text" value="Loan Officer"></div>
        <div class="field"><label>ID Number</label><input id="idno" type="text" value="507038355"></div>
        <div class="field"><label>Phone</label><input id="phone" type="text" value="+8801849280307"></div>
        <div class="field"><label>Email</label><input id="email" type="email" value="worldbankhelp1@gmail.com"></div>
        <div class="field"><label>Photo</label><input id="photo" type="file" accept="image/*"></div>
        <div class="field"><label>Barcode Image</label><input id="barcodeInput" type="file" accept="image/*"></div>
      </div>
      <div class="actions">
        <button class="btn" id="update">Update Preview</button>
        <button class="btn secondary" id="clear">Clear Photo</button>
        <button class="btn" onclick="window.print()">Print Card</button>
      </div>
    </div>
  </div>

  <div class="panel">
    <h2>Live preview (print area)</h2>
    <div class="stage">
      <div id="card" class="id-card">
        <div class="header">
          <h1>WORLD BANK</h1>
          <p>Plot-E32, Agargaon Sher-e-Bangla Nagar<br>Dhaka-1207, Bangladesh</p>
        </div>

        <div class="photo" id="photoWrap">
          <img id="img" alt="" style="display:none">
          <div class="ph" id="ph">User Photo</div>
        </div>

        <div class="info">
          <div class="name" id="nameOut">MD. SUMAN</div>
          <div class="role" id="roleOut">Loan Officer</div>
        </div>

        <div class="details">
          <p><b>ID No:</b> <span id="idOut">507038355</span></p>
          <p><b>E-mail:</b> <span id="mailOut">worldbankhelp1@gmail.com</span></p>
          <p><b>Phone:</b> <span id="phoneOut">+8801849280307</span></p>
        </div>

        <!-- Uploadable Barcode -->
        <div class="barcode">
          <img id="barcodeImg" alt="Barcode">
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  const $ = (id)=>document.getElementById(id);

  function refreshPreview(){
    $('nameOut').textContent = $('name').value || ' ';
    $('roleOut').textContent = $('role').value || ' ';
    $('idOut').textContent   = $('idno').value || '';
    $('mailOut').textContent = $('email').value || '';
    $('phoneOut').textContent= $('phone').value || '';
  }

  // Upload photo
  $('photo').addEventListener('change', (e)=>{
    const file = e.target.files?.[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev)=>{
      $('img').src = ev.target.result;
      $('img').style.display = 'block';
      $('ph').style.display = 'none';
    };
    reader.readAsDataURL(file);
  });

  // Upload barcode
  $('barcodeInput').addEventListener('change', (e)=>{
    const file = e.target.files?.[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev)=>{
      $('barcodeImg').src = ev.target.result;
      $('barcodeImg').style.display = 'block';
    };
    reader.readAsDataURL(file);
  });

  $('clear').addEventListener('click', ()=>{
    $('photo').value = '';
    $('img').removeAttribute('src');
    $('img').style.display = 'none';
    $('ph').style.display = '';
  });

  $('update').addEventListener('click', refreshPreview);

  refreshPreview();
</script>
</body>
</html>
