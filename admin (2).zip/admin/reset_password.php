<?php
// reset_password.php (one-field search + Save + Show/Hide password)
require __DIR__.'/auth.php';
require __DIR__.'/config.php'; // $pdo (PDO)

session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
$CSRF = $_SESSION['csrf'];

$foundUser = null;
$notice=""; $error="";

/* ---------- SEARCH ---------- */
if (isset($_POST['act']) && $_POST['act']==='search') {
  $q = trim($_POST['q'] ?? '');
  if ($q==='') {
    $error = "ইউজার আইডি অথবা মোবাইল নম্বর লিখুন।";
  } else {
    try{
      if (ctype_digit($q)) {
        $stmt = $pdo->prepare("SELECT id,name,mobile FROM users WHERE id = ?");
        $stmt->execute([ (int)$q ]);
        $foundUser = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$foundUser) {
          $stmt = $pdo->prepare("SELECT id,name,mobile FROM users WHERE mobile = ?");
          $stmt->execute([ $q ]);
          $foundUser = $stmt->fetch(PDO::FETCH_ASSOC);
        }
      } else {
        $stmt = $pdo->prepare("SELECT id,name,mobile FROM users WHERE mobile = ?");
        $stmt->execute([ $q ]);
        $foundUser = $stmt->fetch(PDO::FETCH_ASSOC);
      }
      if (!$foundUser) $error = "কোনো ইউজার পাওয়া যায়নি।";
    } catch(Exception $e){
      $error = "সার্চ করতে সমস্যা হয়েছে!";
    }
  }
}

/* ---------- SAVE PASSWORD ---------- */
if (isset($_POST['act']) && $_POST['act']==='save') {
  if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
    $error = "সিকিউরিটি টোকেন অকার্যকর। আবার চেষ্টা করুন।";
  } else {
    $uid = (int)($_POST['uid'] ?? 0);
    $pass1 = trim($_POST['pass1'] ?? '');
    $pass2 = trim($_POST['pass2'] ?? '');
    if (!$uid) {
      $error = "ইউজার নির্ধারণ করা হয়নি।";
    } elseif ($pass1==='' || strlen($pass1)<6) {
      $error = "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।";
    } elseif ($pass1 !== $pass2) {
      $error = "দুটি পাসওয়ার্ড মিলছে না।";
    } else {
      try{
        $hash = password_hash($pass1, PASSWORD_BCRYPT, ['cost'=>11]);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ? LIMIT 1");
        $stmt->execute([$hash, $uid]);
        $notice = "পাসওয়ার্ড সংরক্ষণ করা হয়েছে।";
        $stmt = $pdo->prepare("SELECT id,name,mobile FROM users WHERE id=?");
        $stmt->execute([$uid]);
        $foundUser = $stmt->fetch(PDO::FETCH_ASSOC);
      } catch(Exception $e){
        $error = "পাসওয়ার্ড সেভ করতে সমস্যা হয়েছে!";
      }
    }
  }
}
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin — পাসওয়ার্ড রিসেট</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  :root{--bg:#1b1f36;--surface:#21264a;--panel:#262b56;--text:#e8ecff;--muted:#a9b2d6;
        --border:rgba(255,255,255,.10);--shadow:0 10px 28px rgba(0,0,0,.35);--radius:16px}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
  .wrap{max-width:820px;margin:28px auto;padding:0 14px}
  .card{background:linear-gradient(180deg,var(--surface),var(--panel));border:1px solid var(--border);
        border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden}
  .head{padding:16px 18px;border-bottom:1px solid var(--border);display:flex;gap:10px;align-items:center}
  .ttl{font-size:18px;font-weight:800}
  .section{padding:18px}
  label{display:block;font-size:13px;color:var(--muted);margin:0 0 6px 2px}
  input{width:100%;padding:12px;border-radius:12px;background:#1e2344;border:1px solid var(--border);color:var(--text);outline:none}
  .row{display:grid;gap:12px;grid-template-columns:1fr 1fr}
  @media (max-width:680px){.row{grid-template-columns:1fr}}
  .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}
  .btn{border:0;border-radius:12px;padding:12px 16px;cursor:pointer;font-weight:700;background:#3340a1;color:#fff}
  .btn.secondary{background:#3a4169}
  .msg{margin:14px 18px;padding:12px 14px;border-radius:12px;font-weight:600}
  .ok{background:rgba(22,199,154,.12);border:1px solid rgba(22,199,154,.35)}
  .err{background:rgba(255,93,93,.12);border:1px solid rgba(255,93,93,.35)}
  .usercard{margin:6px 18px 0;padding:10px 12px;border:1px dashed var(--border);border-radius:12px;background:#1e2344}
  .pw-wrap{position:relative}
  .toggle-eye{position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:0;color:#cfd6ff;font-size:18px;cursor:pointer}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="head"><i class="fa-solid fa-key"></i><div class="ttl">পাসওয়ার্ড রিসেট (অ্যাডমিন)</div></div>

    <?php if($notice): ?><div class="msg ok"><i class="fa-regular fa-circle-check"></i> <?= htmlspecialchars($notice) ?></div><?php endif; ?>
    <?php if($error): ?><div class="msg err"><i class="fa-regular fa-circle-xmark"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- ONE SEARCH FIELD -->
    <form method="post" class="section" autocomplete="off">
      <input type="hidden" name="act" value="search">
      <label>সার্চ (User ID বা Mobile)</label>
      <input type="text" name="q" placeholder="যেমন: 12 অথবা 01XXXXXXXXX">
      <div class="actions"><button class="btn"><i class="fa-solid fa-magnifying-glass"></i> সার্চ</button></div>
    </form>

    <?php if($foundUser): ?>
      <div class="usercard">
        <strong>ID:</strong> <?= (int)$foundUser['id'] ?> |
        <strong>নাম:</strong> <?= htmlspecialchars($foundUser['name'] ?? '') ?> |
        <strong>মোবাইল:</strong> <?= htmlspecialchars($foundUser['mobile'] ?? '') ?>
      </div>

      <!-- SAVE PASSWORD FORM -->
      <form method="post" class="section" autocomplete="off">
        <input type="hidden" name="act" value="save">
        <input type="hidden" name="csrf" value="<?= $CSRF ?>">
        <input type="hidden" name="uid" value="<?= (int)$foundUser['id'] ?>">

        <div class="row">
          <div class="pw-wrap">
            <label>নতুন পাসওয়ার্ড</label>
            <input id="pass1" type="password" name="pass1" minlength="6" required>
            <button class="toggle-eye" type="button" data-target="pass1"><i class="fa-regular fa-eye"></i></button>
          </div>
          <div class="pw-wrap">
            <label>পাসওয়ার্ড নিশ্চিত করুন</label>
            <input id="pass2" type="password" name="pass2" minlength="6" required>
            <button class="toggle-eye" type="button" data-target="pass2"><i class="fa-regular fa-eye"></i></button>
          </div>
        </div>

        <div class="actions">
          <button class="btn" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Password</button>
          <button class="btn secondary" type="button" id="gen"><i class="fa-solid fa-wand-magic-sparkles"></i> Generate</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>

<script>
  // Show/Hide password
  document.querySelectorAll('.toggle-eye').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.dataset.target;
      const input = document.getElementById(id);
      if (!input) return;
      input.type = input.type === 'password' ? 'text' : 'password';
      btn.innerHTML = input.type === 'password'
        ? '<i class="fa-regular fa-eye"></i>'
        : '<i class="fa-regular fa-eye-slash"></i>';
    });
  });

  // Random generator
  function randomPass(len=10){
    const chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%";
    let s=""; for(let i=0;i<len;i++) s+=chars[Math.floor(Math.random()*chars.length)];
    return s;
  }
  document.getElementById('gen')?.addEventListener('click', ()=>{
    const p=randomPass(10);
    document.getElementById('pass1').value=p;
    document.getElementById('pass2').value=p;
    document.getElementById('pass1').type='text';
    document.getElementById('pass2').type='text';
  });
</script>
</body>
</html>
