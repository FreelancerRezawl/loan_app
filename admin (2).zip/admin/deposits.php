<?php
require 'header.php';
require 'config.php';

session_start();
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id  = (int)($_POST['id'] ?? 0);
    $act = $_POST['action'] ?? '';

    $map = ['approve' => 'Approved', 'reject' => 'Rejected', 'pending' => 'Pending'];
    $status = $map[$act] ?? null;

    if ($id > 0 && $status) {
        try {
            $stmt = $pdo->prepare("UPDATE deposits SET status=? WHERE id=?");
            $stmt->execute([$status, $id]);

            $_SESSION['flash'] = $stmt->rowCount() > 0
                ? ['ok', "ID #{$id} → {$status}"]
                : ['err', "ID #{$id} পাওয়া যায়নি বা ইতিমধ্যে একই স্ট্যাটাস।"];
        } catch (Throwable $e) {
            $_SESSION['flash'] = ['err', "DB ত্রুটি: ".$e->getMessage()];
        }
    } else {
        $_SESSION['flash'] = ['err', 'ভ্যালিড আইডি/অ্যাকশন পাওয়া যায়নি।'];
    }

    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Fetch deposits WITH user info
try {
    $q = $pdo->query("
        SELECT 
            d.id, 
            d.user_id, 
            d.method, 
            d.amount, 
            d.slip_path, 
            d.status, 
            d.created_at,
            u.name AS user_name,
            u.mobile AS user_mobile
        FROM deposits d
        LEFT JOIN users u ON u.id = d.user_id
        ORDER BY d.id DESC
    ");
    $rows = $q->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    die("<div style='padding:2rem; background:#f8d7da; color:#721c24; border:1px solid #f5c6cb; border-radius:8px; font-weight:bold;'>
        🚫 ডাটাবেস ত্রুটি: " . htmlspecialchars($e->getMessage()) . "
    </div>");
}
?>

<!-- Custom Styles -->
<style>
    body {
        background-color: #0c1428;
        color: #e0e6f1;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .panel {
        margin: 2rem auto;
        max-width: 95%;
        padding: 0;
    }

    h3.h {
        color: #ffffff;
        font-weight: 600;
        margin-bottom: 1.5rem;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid #64b5f6;
    }

    .alert {
        padding: 0.8rem 1.2rem;
        border-radius: 6px;
        margin-bottom: 1.5rem;
        font-weight: 500;
        text-align: center;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    .alert-success {
        background: #4caf50;
        color: #fff;
        border: none;
    }

    .alert-danger {
        background: #f44336;
        color: #fff;
        border: none;
    }

    .table-container {
        background: #0f223f;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    }

    .table {
        width: 100%;
        border-collapse: collapse;
    }

    .table thead th {
        background: #0a1a30;
        color: #ffffff;
        font-weight: 600;
        padding: 1rem;
        vertical-align: middle;
        border: none;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .table tbody td {
        background: #0f223f;
        color: #e0e6f1;
        padding: 1rem;
        vertical-align: middle;
        border: none;
        font-size: 0.95rem;
        border-top: 1px solid #0b1c33;
    }

    .table tbody tr:nth-child(even) {
        background: #0d1f38;
    }

    .table tbody tr:hover {
        background: #132b4d !important;
        transform: scale(1.005);
        transition: all 0.2s ease;
    }

    .badge {
        font-weight: 500;
        padding: 0.4rem 0.7rem;
        border-radius: 20px;
        font-size: 0.8rem;
    }

    /* Dropdown Styles */
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-btn {
        background: #64b5f6;
        color: #000;
        padding: 0.35rem 0.75rem;
        font-size: 0.85rem;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 0.25rem;
        transition: all 0.2s ease;
    }

    .dropdown-btn:hover {
        background: #4fc3f7;
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }

    .dropdown-content {
        display: none;
        position: absolute;
        right: 0;
        background: #0f223f;
        min-width: 160px;
        box-shadow: 0 8px 16px rgba(0,0,0,0.2);
        border-radius: 8px;
        z-index: 1000;
        border: 1px solid #0b1c33;
        overflow: hidden;
    }

    .dropdown-content a,
    .dropdown-content button {
        color: #e0e6f1;
        padding: 0.5rem 1rem;
        text-decoration: none;
        display: block;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        font-size: 0.85rem;
        transition: background 0.2s ease;
        width: 100%;
        text-align: center;
    }

    .dropdown-content button:hover {
        background: #132b4d;
    }

    .dropdown-content .approve {
        color: #4caf50;
    }

    .dropdown-content .reject {
        color: #f44336;
    }

    .dropdown-content .pending {
        color: #ffc107;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    a {
        color: #64b5f6;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    .text-muted {
        color: #9ca3af !important;
    }

    .user-info {
        font-size: 0.9rem;
    }

    .user-name {
        font-weight: 600;
        color: #ffffff;
    }

    .user-mobile {
        color: #a0c8ff;
        font-size: 0.9em;
    }

    .user-meta {
        color: #b0bec5;
        font-size: 0.85em;
    }

    @media (max-width: 768px) {
        .panel {
            margin: 1rem;
            max-width: 98%;
        }

        .table thead th,
        .table tbody td {
            padding: 0.75rem;
            font-size: 0.85rem;
        }

        h3.h {
            font-size: 1.2rem;
        }

        .dropdown-content {
            min-width: 140px;
            right: -10px;
        }

        .dropdown-btn {
            padding: 0.3rem 0.6rem;
            font-size: 0.8rem;
        }
    }
</style>

<div class="panel">
    <h3 class="h">📥 ডিপোজিট সাবমিশন</h3>

    <?php if ($flash): ?>
        <div class="alert <?= $flash[0]==='ok' ? 'alert-success' : 'alert-danger' ?>">
            <?= htmlspecialchars($flash[1]) ?>
        </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="table table-sm table-bordered align-middle">
            <thead>
                <tr>
                    <th style="width:60px">ID</th>
                    <th>ইউজার</th>
                    <th>মেথড</th>
                    <th style="width:120px">পরিমাণ</th>
                    <th>স্লিপ</th>
                    <th style="width:110px">স্ট্যাটাস</th>
                    <th style="width:150px">সময়</th>
                    <th style="width:150px">অ্যাকশন</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">
                            <i class="fa-solid fa-inbox me-2"></i> কোনো রেকর্ড নেই
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach($rows as $r): ?>
                        <tr>
                            <td class="fw-bold">#<?= (int)$r['id'] ?></td>
                            <td class="user-info">
                                <div class="user-name"><?= htmlspecialchars($r['user_name'] ?? '—') ?></div>
                                <div class="user-mobile"><?= htmlspecialchars($r['user_mobile'] ?? '—') ?></div>
                                <div class="user-meta">ID #<?= (int)$r['user_id'] ?> • <?= date('d M, Y H:i', strtotime($r['created_at'])) ?></div>
                            </td>
                            <td><?= htmlspecialchars($r['method'] ?: '—') ?></td>
                            <td class="fw-bold"><?= number_format((float)$r['amount'], 2) ?> ৳</td>
                            <td>
                                <?php if (!empty($r['slip_path'])): ?>
                                    <a href="../uploads/<?= rawurlencode($r['slip_path']) ?>" target="_blank" class="text-decoration-none">
                                        <i class="fa-solid fa-image me-1"></i> ভিউ
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $badge = 'secondary';
                                    if ($r['status'] === 'Approved') $badge = 'success';
                                    elseif ($r['status'] === 'Rejected') $badge = 'danger';
                                    elseif ($r['status'] === 'Pending') $badge = 'warning text-dark';
                                ?>
                                <span class="badge bg-<?= $badge ?>"><?= htmlspecialchars($r['status']) ?></span>
                            </td>
                            <td><?= date('d M, H:i', strtotime($r['created_at'])) ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="dropdown-btn">
                                        <i class="fa-solid fa-ellipsis-vertical"></i> অ্যাকশন
                                    </button>
                                    <div class="dropdown-content">
                                        <form method="POST">
                                            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                            <button type="submit" name="action" value="approve" class="approve">
                                                <i class="fa-solid fa-check"></i> অ্যাপ্রুভ
                                            </button>
                                        </form>
                                        <form method="POST">
                                            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                            <button type="submit" name="action" value="reject" class="reject">
                                                <i class="fa-solid fa-xmark"></i> রিজেক্ট
                                            </button>
                                        </form>
                                        <?php if ($r['status'] !== 'Pending'): ?>
                                            <form method="POST">
                                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                                <button type="submit" name="action" value="pending" class="pending">
                                                    <i class="fa-solid fa-clock-rotate-left"></i> পেন্ডিং
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require 'footer.php'; ?>