<?php
// add_admin.php
// Requires: config.php defining $pdo (PDO connection).

session_start();
require __DIR__ . '/config.php';

// OPTIONAL: simple auth gate (uncomment/replace with your own logic)
// if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }

// ---------- CSRF ----------
if (empty($_SESSION['csrf'])) {
  $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

// ---------- HANDLE CREATE ----------
$flash = ['type' => '', 'msg' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    $flash = ['type'=>'err', 'msg'=>'Invalid CSRF token. Reload the page.'];
  } else {
    $email = trim($_POST['email'] ?? '');
    $pass  = (string)($_POST['password'] ?? '');
    $pass2 = (string)($_POST['password2'] ?? '');

    // Basic validation
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $flash = ['type'=>'err','msg'=>'সঠিক ইমেইল দিন।'];
    } elseif (strlen($pass) < 6) {
      $flash = ['type'=>'err','msg'=>'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।'];
    } elseif ($pass !== $pass2) {
      $flash = ['type'=>'err','msg'=>'পাসওয়ার্ড ও কনফার্ম পাসওয়ার্ড মিলছে না।'];
    } else {
      try {
        // Ensure table exists (safe-guard). Matches your exported schema: id,email,password,created_at
        $pdo->exec("
          CREATE TABLE IF NOT EXISTS admins (
            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // Unique email check
        $st = $pdo->prepare("SELECT id FROM admins WHERE email = :e LIMIT 1");
        $st->execute([':e'=>$email]);
        if ($st->fetch()) {
          $flash = ['type'=>'err','msg'=>'এই ইমেইলটি আগেই রয়েছে।'];
        } else {
          $hash = password_hash($pass, PASSWORD_DEFAULT);
          $ins = $pdo->prepare("INSERT INTO admins (email,password) VALUES (:e,:p)");
          $ins->execute([':e'=>$email, ':p'=>$hash]);
          $flash = ['type'=>'ok','msg'=>'অ্যাডমিন সফলভাবে যোগ হয়েছে।'];
        }
      } catch (Throwable $e) {
        $flash = ['type'=>'err','msg'=>'সার্ভার/ডাটাবেস ত্রুটি: '.$e->getMessage()];
      }
    }
  }
}

// ---------- FETCH LIST ----------
$admins = [];
try {
  $q = $pdo->query("SELECT id, email, created_at FROM admins ORDER BY id DESC");
  $admins = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  // table may not exist yet; will be created on first POST
}

?>
<!doctype html>
<html lang="bn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Add Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --bg:#0f1222; --surface:#1b1f36; --panel:#22274a; --card:#1f2443;
      --text:#e9ecf1; --muted:#a9b2c7; --brand:#6c5ce7; --ok:#00c29a; --err:#ff6b6b;
      --border:rgba(255,255,255,.08); --shadow:0 8px 24px rgba(0,0,0,.35);
      --radius:18px;
    }
    *{box-sizing:border-box}
    body{margin:0;background:linear-gradient(145deg,#0d1020,#0b0f1c 60%,#0a0e19);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--text);}
    .wrap{max-width:900px;margin:32px auto;padding:16px;}
    .card{background:var(--surface); border:1px solid var(--border); border-radius:24px; box-shadow:var(--shadow); padding:20px;}
    h1{margin:0 0 10px 0;font-size:24px}
    p.muted{color:var(--muted); margin:0 0 16px 0}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
    @media (max-width:800px){.grid{grid-template-columns:1fr}}
    .field{display:flex;flex-direction:column;gap:8px}
    label{font-weight:700; color:#dfe5f8}
    input{
      padding:12px 12px;border:1px solid var(--border);border-radius:12px;background:#121530;color:#e9ecf1;outline:none;
    }
    .btn{
      background:var(--brand); color:#fff; border:none; border-radius:12px; padding:12px 16px;
      font-weight:800; cursor:pointer; box-shadow:var(--shadow);
    }
    .row{display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin-top:10px}
    .flash{border-radius:12px; padding:12px 14px; margin:10px 0; font-weight:700}
    .flash.ok{background:rgba(0,194,154,.12); border:1px solid rgba(0,194,154,.35); color:#9ff2dd}
    .flash.err{background:rgba(255,107,107,.12); border:1px solid rgba(255,107,107,.35); color:#ffd7d7}
    .table{width:100%; border-collapse:collapse; margin-top:18px; background:#141935; border-radius:16px; overflow:hidden}
    .table th,.table td{padding:12px; border-bottom:1px solid #222a55}
    .table th{background:#182046; text-align:left; color:#d0d7f0}
    .table tr:hover{background:#171f44}
    .eye{position:absolute; right:12px; top:50%; transform:translateY(-50%); cursor:pointer; color:#c8d0e6}
    .rel{position:relative}
    small.help{color:#9aa6c6}
    .note{color:#9aa6c6; font-size:13px; margin-top:6px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1><i class="fa-solid fa-user-shield"></i> Add Admin</h1>
      <p class="muted">নিচের ফর্ম থেকে নতুন অ্যাডমিন যুক্ত করুন। ইমেইল একবারই ব্যবহার করা যাবে।</p>

      <?php if($flash['msg']): ?>
        <div class="flash <?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['msg']) ?></div>
      <?php endif; ?>

      <form method="post" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
        <div class="grid">
          <div class="field">
            <label for="email">ইমেইল</label>
            <input id="email" name="email" type="email" placeholder="admin@example.com" required>
          </div>

          <div class="field rel">
            <label for="password">পাসওয়ার্ড</label>
            <input id="password" name="password" type="password" minlength="6" required>
            <i class="fa-regular fa-eye eye" onclick="toggle('password',this)" title="Show/Hide"></i>
            <small class="help">কমপক্ষে ৬ অক্ষর</small>
          </div>

          <div class="field rel">
            <label for="password2">কনফার্ম পাসওয়ার্ড</label>
            <input id="password2" name="password2" type="password" minlength="6" required>
            <i class="fa-regular fa-eye eye" onclick="toggle('password2',this)" title="Show/Hide"></i>
          </div>
        </div>

        <div class="row">
          <button class="btn" type="submit"><i class="fa-solid fa-plus"></i> Create Admin</button>
        </div>
        <div class="note">টেবিল স্ট্রাকচার: <code>admins(id, email, password, created_at)</code>—তোমার এক্সপোর্ট অনুযায়ী।</div>
      </form>

      <table class="table">
        <thead><tr><th>ID</th><th>Email</th><th>Created</th></tr></thead>
        <tbody>
          <?php if(!$admins): ?>
            <tr><td colspan="3" style="color:#9aa6c6">কোনো অ্যাডমিন পাওয়া যায়নি।</td></tr>
          <?php else: foreach($admins as $a): ?>
            <tr>
              <td>#<?= (int)$a['id'] ?></td>
              <td><?= htmlspecialchars($a['email']) ?></td>
              <td><?= htmlspecialchars($a['created_at'] ?? '') ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    function toggle(id, el){
      const i = document.getElementById(id);
      if(!i) return;
      i.type = (i.type === 'password') ? 'text' : 'password';
      el.classList.toggle('fa-eye-slash');
    }
  </script>
</body>
</html>
