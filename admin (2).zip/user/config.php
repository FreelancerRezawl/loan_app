<?php
// config.php - Database & Core Functions

// === DATABASE CONFIGURATION ===
$host = "localhost";  // Almost always 'localhost' in cPanel
$dbname = "bdworldb_maindatabase";
$username = "bdworldb_maindatabase"; // DB user
$password = "bdworldb_maindatabase"; // 🔐 Replace with your real password

// === CREATE PDO CONNECTION ===
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("<h3 style='color: red; text-align: center;'>ডাটাবেজ কানেকশন ফেইল: সেটিংস চেক করুন</h3>");
}

// === HELPER FUNCTIONS ===
function redirect($url) {
    header("Location: $url");
    exit();
}

function alert($msg, $type = "success") {
    $_SESSION['alert'] = "<div class='alert alert-$type text-center'>$msg</div>";
}

// Session Start
session_start();
?>