<?php
// user/rin.php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: ../index.php"); exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $amount = isset($_POST['amount']) ? intval($_POST['amount']) : 0;
  $months = isset($_POST['duration_months']) ? intval($_POST['duration_months']) : 0;

  if ($amount <= 0 || $months <= 0) {
    $error = "ঋণের পরিমাণ ও মেয়াদ নির্বাচন করুন।";
  } else {
    $_SESSION['loan_amount'] = $amount;
    $_SESSION['loan_months'] = $months;
    header("Location: transfer_method.php");
    exit();
  }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <!-- ✅ Proper responsive viewport; content centered via max-width -->
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
  <title>ঋণের আবেদন</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
<style>
  :root{
    --brand:#0b3d62;
    --brand-dark:#092f4d;
    --border:#d5e1f0;
    --text:#22313f;
    --muted:#6b7b93;
    --ring:0 0 0 3px rgba(11,61,98,.15);
    --app-max:420px;
    --footer-h:72px;
  }
  *{ box-sizing:border-box; }
  html,body{
    margin:0; padding:0; width:100%; min-height:100%;
    overflow-x:hidden;
    background:#f7f9fc; color:var(--text);
    font-family:'SolaimanLipi',system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  }
  .app{
    max-width:var(--app-max);
    margin:0 auto;
    padding:10px 10px calc(var(--footer-h) + env(safe-area-inset-bottom) + 12px);
  }

  .topbar{
    background:var(--brand); color:#fff; padding:10px 12px; border-radius:10px;
    display:flex; align-items:center; gap:8px; margin-bottom:12px;
  }
  .topbar a{ color:#fff; text-decoration:none; font-weight:700; }

  h6{ font-weight:800; margin:0 0 8px; color:var(--text); font-size:1rem; }
  .section-card{
    background:#fff; border-radius:12px; box-shadow:0 1px 6px rgba(0,0,0,.06);
    border:1px solid var(--border); padding:12px; margin-bottom:12px;
  }

  /* Compact grid: 4 cols (>=380px), 3 cols (<380px) */
  .grid-select{
    display:grid; grid-template-columns:repeat(4,1fr); gap:6px;
  }
  @media (max-width: 380px){
    .grid-select{ grid-template-columns:repeat(3,1fr); }
  }
  .grid-select button{
    border:1px solid #d0d7de; border-radius:10px; padding:8px 4px; background:#fff;
    font-weight:800; font-size:.72rem; line-height:1.2; cursor:pointer; transition:.2s;
  }
  .grid-select button.active{ background:var(--brand); color:#fff; border-color:var(--brand); }
  .grid-select button:hover:not(.active){ background:#eef3f7; }

  .btn-next{
    display:block; width:100%; height:46px; font-weight:800; border-radius:12px;
    background:var(--brand); border:none; color:#fff; font-size:.95rem;
    margin:6px 0 0;
  }
  .btn-next:hover{ background:var(--brand-dark); }
  .btn-next:focus{ outline:none; box-shadow:var(--ring); }

  .alert{ border-radius:10px; margin-bottom:12px; }

  /* Footer (centered, within app width) */
  .footer-nav{
    position:fixed; bottom:0; left:50%; transform:translateX(-50%);
    width:100%; max-width:var(--app-max);
    background:var(--brand); color:#fff; z-index:1000;
    display:flex; justify-content:space-around; align-items:center;
    padding:8px 6px; border-radius:12px 12px 0 0; box-shadow:0 -6px 16px rgba(0,0,0,.25);
  }
  .footer-nav a{ flex:1; color:#fff; text-decoration:none; text-align:center; font-size:.85rem; }
  .footer-nav i{ font-size:1.2rem; display:block; margin-bottom:4px; }
  .footer-nav span{ font-size:.8rem; }
  .footer-nav a.active i,.footer-nav a.active span{ filter:brightness(1.1); }

  .mini{ color:var(--muted); font-size:.9rem; margin-top:6px; }
</style>

</head>
<body>
<div class="app">

  <div class="topbar">
    <a href="index.php"><i class="fa-solid fa-chevron-left"></i></a>
    <span style="font-weight:800;">ঋণের আবেদন</span>
  </div>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" id="loanForm">
    <!-- ঋণের মেয়াদ -->
    <h6>ঋণের মেয়াদ</h6>
    <div class="section-card">
      <div class="grid-select" id="monthsGrid">
        <button type="button" data-value="12">১২ মাস</button>
        <button type="button" data-value="24">২৪ মাস</button>
        <button type="button" data-value="36">৩৬ মাস</button>
        <button type="button" data-value="48">৪৮ মাস</button>
        <button type="button" data-value="60">৬০ মাস</button>
      </div>
      <input type="hidden" name="duration_months" id="monthsInput">
    </div>

    <!-- ঋণের পরিমাণ -->
    <h6>ঋণের পরিমাণ</h6>
    <div class="section-card">
      <div class="grid-select" id="amountGrid">
        <?php 
          $amounts = [50000,100000,150000,200000,250000,300000,350000,400000,450000,500000,550000,600000,650000,700000,750000,800000,850000,900000,950000,1000000,1100000,1200000,1250000,1300000,1350000,1400000,1450000,1500000,1550000,1600000,1650000,1700000,1750000,1800000,1850000,1900000,1950000,2000000];
          foreach($amounts as $a): ?>
            <button type="button" data-value="<?= $a ?>"><?= number_format($a) ?> ৳</button>
        <?php endforeach; ?>
      </div>
      <input type="hidden" name="amount" id="amountInput">
    </div>

    <!-- EMI -->
    <div class="section-card">
      <h6>প্রতিমাসে কিস্তির পরিমাণ:</h6>
      <div class="mb-0" id="emiAmount">
        <p style="color:#555;font-size:.98rem;margin:0;">প্রথমে ঋণের মেয়াদ ও পরিমাণ নির্বাচন করুন</p>
      </div>
      <div class="mini" id="emiInfo"></div>
    </div>

    <button type="submit" class="btn-next">পরবর্তী</button>
  </form>

</div>

<!-- Footer -->
<nav class="footer-nav">
  <a href="index.php" class="active"><i class="fas fa-home"></i><span>হোম</span></a>
  <a href="installments.php"><i class="fas fa-credit-card"></i><span>কিস্তি</span></a>
  <a href="profile.php"><i class="fas fa-user"></i><span>প্রোফাইল</span></a>
</nav>

<script>
  // ✅ 0.20% per month (simple interest), same as dashboard
  const MONTHLY_INTEREST_PERCENT = 0.20;   // 0.20%/month
  const MONTHLY_RATE = MONTHLY_INTEREST_PERCENT / 100; // 0.002

  function handleGrid(gridId, inputId){
    const grid=document.getElementById(gridId);
    const input=document.getElementById(inputId);
    grid.querySelectorAll("button").forEach(btn=>{
      btn.addEventListener("click",()=>{
        grid.querySelectorAll("button").forEach(b=>b.classList.remove("active"));
        btn.classList.add("active");
        input.value = btn.dataset.value;
        calculateEMI();
      });
    });
  }
  handleGrid("monthsGrid","monthsInput");
  handleGrid("amountGrid","amountInput");

  function formatBDT(n, frac=0){
    try{
      return new Intl.NumberFormat('bn-BD',{style:'currency',currency:'BDT',maximumFractionDigits:frac}).format(n);
    }catch(e){
      const rounded = (frac ? n : Math.round(n));
      return rounded.toLocaleString('bn-BD') + ' ৳';
    }
  }

  function calculateEMI(){
    const amount = parseInt(document.getElementById('amountInput').value)||0;
    const months = parseInt(document.getElementById('monthsInput').value)||0;
    const emiBox = document.getElementById('emiAmount');
    const infoBox = document.getElementById('emiInfo');

    if(amount<=0 || months<=0){
      emiBox.innerHTML='<p style="color:#555;font-size:.98rem;margin:0;">প্রথমে ঋণের মেয়াদ ও পরিমাণ নির্বাচন করুন</p>';
      infoBox.textContent='';
      return;
    }

    // Simple interest per month:
    // Total = P * (1 + r * n), EMI = Total / n
    const interest = amount * MONTHLY_RATE * months;
    const total    = amount + interest;
    const emi      = total / months;

    emiBox.innerHTML = `<p style="font-size:1.05rem;color:#22313f;margin:0;"><strong>প্রতিমাসের কিস্তি:</strong> ${formatBDT(emi)}</p>`;
    infoBox.textContent = `হার: ${MONTHLY_INTEREST_PERCENT.toFixed(2)}%/মাস • মেয়াদ: ${months} মাস • মূলধন: ${formatBDT(amount)} • সুদ: ${formatBDT(interest)} • মোট: ${formatBDT(total)}`;
  }

  document.addEventListener('DOMContentLoaded', calculateEMI);
</script>
</body>
</html>
