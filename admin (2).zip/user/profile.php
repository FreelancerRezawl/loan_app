<?php
include '../config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$name = $_SESSION['user_name'] ?? '';

// Fetch mobile
$mobile = '';
$stmt = $pdo->prepare("SELECT mobile FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
if ($user) $mobile = $user['mobile'];

// Fetch profile photo
$photo_url = '';
$stmt = $pdo->prepare("SELECT user_photo FROM documents WHERE user_id = ?");
$stmt->execute([$user_id]);
$doc = $stmt->fetch();
if ($doc && !empty($doc['user_photo'])) {
    $fn = basename($doc['user_photo']);
    $photo_url = "../uploads/" . rawurlencode($fn);
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <title>প্রোফাইল</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <style>
    body{background:#f5f7fa;max-width:420px;margin:0 auto;padding-bottom:90px;font-family:system-ui;}
    .header-box{
      background:#0a3d62;color:#fff;text-align:center;padding:24px 14px 30px;
      border-radius:0 0 14px 14px;position:relative;
    }
    .avatar{
      width:90px;height:90px;border-radius:50%;overflow:hidden;
      border:3px solid #fff;box-shadow:0 4px 10px rgba(0,0,0,.2);
      margin:0 auto 10px;background:#fff;display:flex;align-items:center;justify-content:center;
    }
    .avatar img{width:100%;height:100%;object-fit:cover;}
    .avatar i{font-size:2rem;color:#0a3d62;}
    .header-box .name{font-size:1.2rem;font-weight:600;margin:0;}
    .header-box .mobile{font-size:.95rem;margin:4px 0 6px;}
    .verified{font-size:.85rem;color:#d4fcd4;}
    .menu-list{margin:16px 10px;}
    .menu-item{
      display:flex;align-items:center;justify-content:space-between;
      background:#fff;padding:14px 16px;margin-bottom:10px;
      border-radius:12px;box-shadow:0 2px 6px rgba(0,0,0,.05);
      text-decoration:none;color:#2c3e50;
    }
    .menu-left{display:flex;align-items:center;gap:12px;}
    .menu-icon{
      width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;
      background:#f0f4f8;color:#0a3d62;font-size:1.2rem;
    }
    .menu-text h6{margin:0;font-size:1rem;font-weight:600;}
    .menu-text small{display:block;color:#6b7b93;font-size:.85rem;}
    .logout-btn{
      display:block;width:calc(100% - 20px);margin:20px auto 0;
      background:#dc3545;color:#fff;font-size:1.1rem;font-weight:600;
      text-align:center;padding:14px;border:none;border-radius:12px;
    }
    .logout-btn:hover{background:#b02a37;}
    /* Footer Nav (deep blue) */
    .footer-nav{
      position:fixed;bottom:0;left:0;right:0;
      background:#0a3d62;color:#fff;
      display:flex;justify-content:space-around;max-width:420px;margin:0 auto;
      padding:8px 0;z-index:1000;border-top-left-radius:14px;border-top-right-radius:14px;
    }
    .footer-nav a{flex:1;text-align:center;color:#fff;text-decoration:none;font-size:.85rem;}
    .footer-nav i{display:block;font-size:1.3rem;margin-bottom:3px;}
    
  </style>
</head>
<body>

<div class="header-box">
  <div class="avatar">
    <?php if ($photo_url): ?>
      <img src="<?= htmlspecialchars($photo_url) ?>" alt="প্রোফাইল ছবি">
    <?php else: ?>
      <i class="fa-solid fa-user"></i>
    <?php endif; ?>
  </div>
  <div class="name"><?= htmlspecialchars($name) ?></div>
  <div class="mobile"><?= htmlspecialchars($mobile) ?></div>
  <div class="verified"><i class="fa-solid fa-circle-check"></i> Verified Account</div>
</div>

<div class="menu-list">
  <a href="profile2.php" class="menu-item">
    <div class="menu-left">
      <div class="menu-icon"><i class="fa-solid fa-user"></i></div>
      <div class="menu-text">
        <h6>ব্যক্তিগত তথ্য</h6>
        <small>ব্যক্তিগত তথ্য দেখুন</small>
      </div>
    </div>
    <i class="fa-solid fa-angle-right"></i>
  </a>

  <a href="#" class="menu-item">
    <div class="menu-left">
      <div class="menu-icon"><i class="fa-solid fa-university"></i></div>
      <div class="menu-text">
        <h6>ব্যাংক একাউন্ট</h6>
        <small>ব্যাংক একাউন্ট দেখুন</small>
      </div>
    </div>
    <i class="fa-solid fa-angle-right"></i>
  </a>

  <a href="#" class="menu-item">
    <div class="menu-left">
      <div class="menu-icon"><i class="fa-solid fa-money-bill-wave"></i></div>
      <div class="menu-text">
        <h6>টাকা উত্তোলন</h6>
        <small>আপনার টাকা উত্তোলন করুন</small>
      </div>
    </div>
    <i class="fa-solid fa-angle-right"></i>
  </a>

  <a href="#" class="menu-item">
    <div class="menu-left">
      <div class="menu-icon"><i class="fa-solid fa-download"></i></div>
      <div class="menu-text">
        <h6>অ্যাপ ডাউনলোড</h6>
        <small>অ্যাপ ডাউনলোড করুন</small>
      </div>
    </div>
    <i class="fa-solid fa-angle-right"></i>
  </a>

  <a href="terms.php" class="menu-item">
    <div class="menu-left">
      <div class="menu-icon"><i class="fa-solid fa-book"></i></div>
      <div class="menu-text">
        <h6>নিয়মাবলী ও শর্তাবলী</h6>
        <small>শর্তাবলী পড়ুন</small>
      </div>
    </div>
    <i class="fa-solid fa-angle-right"></i>
  </a>

  <a href="#" class="menu-item">
    <div class="menu-left">
      <div class="menu-icon"><i class="fa-solid fa-key"></i></div>
      <div class="menu-text">
        <h6>পাসওয়ার্ড পরিবর্তন</h6>
        <small>নতুন পাসওয়ার্ড দিন</small>
      </div>
    </div>
    <i class="fa-solid fa-angle-right"></i>
  </a>
</div>

<button onclick="window.location.href='../logout.php'" class="logout-btn">
  <i class="fa-solid fa-right-from-bracket"></i> লগ আউট
</button>

<!-- Bottom Navigation -->
<div class="footer-nav">
  <a href="index.php">
    <i class="fa-solid fa-house"></i>
    হোম
  </a>
  <a href="installments.php">
    <i class="fa-solid fa-credit-card"></i>
    কিস্তি/কার্ড
  </a>
  <a href="profile.php" class="active">
    <i class="fa-solid fa-user"></i>
    প্রোফাইল
  </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
