<?php
// user/terms.php - Terms & Conditions
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <title>নিয়মাবলী ও শর্তাবলী</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <style>
    body {
      font-family: system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: #f4f6f9;
      padding-bottom: 70px;
      margin: 0;
      color: #2c3e50;
    }
    .page-container {
      padding: 16px;
      background: #fff;
      border-radius: 12px;
      margin: 16px auto;
      max-width: 720px; /* wider on large devices */
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }
    h2 {
      font-size: 1.15rem;
      font-weight: 700;
      margin-bottom: 10px;
      color: #0a3d62;
    }
    .section {
      margin-bottom: 20px;
      text-align: justify;
    }
    .section p {
      margin: 0 0 8px;
      font-size: .95rem;
      line-height: 1.55;
      color: #333;
    }
    .footer-nav {
      position: fixed;
      bottom: 0;
      width: 100%;
      background: #0a3d62;
      color: white;
      padding: 8px 0;
      z-index: 1000;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-around;
      text-align: center;
    }
    .footer-nav a { 
      color: white; 
      font-size: 0.85rem; 
      text-decoration: none; 
      flex:1;
    }
    .footer-nav i { font-size: 1.2rem; display: block; margin-bottom: 4px; }
    
  </style>
</head>
<body>

<div class="page-container">

  <div class="section">
    <h2>📜 নিয়মাবলী ও শর্তাবলী</h2>
    <p>আমাদের কাছ থেকে খুব সহজে আপনি ঘরে বসে ঋণ নিতে পারবেন। আমাদের কাছ থেকে ৫০ হাজার থেকে ২০ লক্ষ টাকা পর্যন্ত ঋণ নিতে পারবেন।</p>
  </div>

  <div class="section">
    <h2>💳 ঋণ পরিশোধ</h2>
    <p>আপনাকে প্রতিমাসের ১-১০ তারিখের মধ্যে আমাদের কোম্পানির বিকাশ/নগদ কিস্তি দিতে হবে।</p>
    <p>আপনি যদি কোনো মাসে কিস্তি দিতে সক্ষম না হন তবে আপনি ২ মাসের কিস্তি একসাথে দিতে পারবেন।</p>
    <p>যদি ২ মাসের বেশি হয়ে যায়, তাহলে আপনাকে অতিরিক্ত কিছু পরিমাণ জরিমানা দিতে হতে পারে।</p>
  </div>

  <div class="section">
    <h2>⚠️ সতর্কতা</h2>
    <p>প্রয়োজন ছাড়া ফোন বা মেসেজ করা থেকে বিরত থাকুন।</p>
    <p>আপনার যদি কোনো অভিযোগ থাকে বা আপনি যদি অন্য কোথাও থেকে প্রতারণার শিকার হয়ে থাকেন, তাহলে আপনি আমাদেরকে অভিযোগ জানাতে পারবেন।</p>
    <p>ভুল তথ্য দেওয়া থেকে বিরত থাকুন। ভুল বা মিথ্যা তথ্য দিলে সংস্থা ব্যবস্থা নিতে বাধ্য থাকবে।</p>
  </div>

  <div class="section">
    <h2>📑 জামানত সম্পর্কে</h2>
    <p>আপনার ঋণ গ্রহণের সক্ষমতা যাচাই করার জন্য কিছু ক্ষেত্রে সামর্থ্যগত নির্দিষ্ট পরিমাণ সম্পদ জমা দিতে হতে পারে অথবা জীবন বীমা করতে হতে পারে।</p>
    <p>✅ জামানত অর্থ আপনার ঋণ সম্পূর্ণ পরিশোধ হওয়ার পর ফেরত দেওয়া হবে।</p>
    <p>✅ বীমার অর্থ কিস্তির মেয়াদ শেষ সম্পূর্ণ ফেরত দেওয়া হবে।</p>
    <p>✅ এটি একটি নিরাপদমূলক ব্যবস্থা, যা আপনাকে ও আমাদের উভয় পক্ষকে আর্থিক সুরক্ষা নিশ্চিত করতে সাহায্য করবে।</p>
  </div>

  <div class="section">
    <h2>📝 তথ্য সংশোধন</h2>
    <p>একাউন্ট নাম্বার বা ব্যক্তিগত তথ্য ভুল হলে সংশোধন ফি দিতে হবে।</p>
    <p>পাসওয়ার্ড ভুলে গেলে আমাদের গ্রাহক প্রতিনিধির সাথে যোগাযোগ করুন।</p>
  </div>

  <div class="section">
    <h2>💰 লোন পেতে কতদিন লাগতে পারে?</h2>
    <p>আপনার লোন সম্পূর্ণ হতে কতদিন লাগবে, তা মূলত আবেদনকৃত ঋণের পরিমাণের উপর নির্ভর করে।</p>
    <p>সাধারণত, এটি সম্পন্ন হতে ১ থেকে ৫ কার্যদিবস সময় লাগতে পারে।</p>
  </div>

  <div class="section">
    <h2>🎧 অভিযোগ</h2>
    <p>যেকোনো অভিযোগ বা লেনদেনজনিত সমস্যার ক্ষেত্রে অনুগ্রহ করে আমাদের অফিসে জানাবেন।</p>
  </div>

</div>

<!-- Bottom Navigation -->
<div class="footer-nav">
  <a href="index.php">
    <i class="fas fa-home"></i>
    হোম
  </a>
  <a href="installments.php">
    <i class="fas fa-credit-card"></i>
    কিস্তি/কার্ড
  </a>
  <a href="profile.php" class="active">
    <i class="fas fa-user"></i>
    প্রোফাইল
  </a>
</div>

</body>
</html>
