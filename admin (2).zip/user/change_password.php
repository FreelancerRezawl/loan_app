<?php
// user/change_password.php
include '../config.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($current) || empty($new) || empty($confirm)) {
        $error = "সব ফিল্ড পূরণ করুন।";
    } elseif ($new !== $confirm) {
        $error = "নতুন পাসওয়ার্ড মিলছে না।";
    } elseif (strlen($new) < 6) {
        $error = "পাসওয়ার্ড কমপক্ষে 6 অক্ষরের হতে হবে।";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();

            if ($user && password_verify($current, $user['password'])) {
                $hashed = password_hash($new, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                if ($stmt->execute([$hashed, $user_id])) {
                    $message = "পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে।";
                } else {
                    $error = "ডাটাবেজ আপডেট ব্যর্থ।";
                }
            } else {
                $error = "বর্তমান পাসওয়ার্ড ভুল।";
            }
        } catch (Exception $e) {
            $error = "ত্রুটি: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=420, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <title>পাসওয়ার্ড পরিবর্তন</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
  <style>
    /* Reset & Global */
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background: #f7f9fc;
      padding-bottom: 70px;
      margin: 0;
      overflow-x: hidden;
      max-width: 420px;
      margin: 0 auto;
      position: relative;
    }

    .container {
      max-width: 420px;
      width: 100%;
      padding: 20px 15px 80px;
    }

    h5 {
      font-weight: 600;
      color: #2c3e50;
      margin-bottom: 20px;
      text-align: center;
    }

    /* Form Styles */
    .form-label {
      font-weight: 500;
      color: #34495e;
      margin-bottom: 8px;
    }

    .form-control {
      height: 52px;
      border: 1px solid #ced4da;
      border-radius: 12px;
      font-size: 1rem;
      padding: 0 15px;
    }

    .form-control:focus {
      border-color: #0a3d62;
      box-shadow: 0 0 0 3px rgba(10, 61, 98, 0.1);
    }

    /* Alerts */
    .alert {
      border-radius: 12px;
      padding: 12px 16px;
      font-size: 0.95rem;
    }

    /* Change Password Button */
    .btn-warning {
      background-color: #f39c12;
      border: none;
      color: white;
      height: 50px;
      font-size: 1.1rem;
      font-weight: 600;
      border-radius: 12px;
      width: 100%;
    }

    .btn-warning:hover {
      background-color: #e67e22;
    }

    /* Footer Navigation */
    .footer-nav {
      position: fixed;
      bottom: 0;
      width: 100%;
      background: #0a3d62;
      color: white;
      padding: 8px 0;
      z-index: 1000;
      max-width: 420px;
      margin: 0 auto;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-around;
      text-align: center;
    }

    .footer-nav a {
      color: white;
      font-size: 0.85rem;
      text-decoration: none;
    }

    .footer-nav i {
      font-size: 1.2rem;
      display: block;
      margin-bottom: 4px;
    }
  </style>
</head>
<body>

<div class="container">
  <h5>পাসওয়ার্ড পরিবর্তন করুন</h5>

  <?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="mb-3">
      <label class="form-label">বর্তমান পাসওয়ার্ড</label>
      <input type="password" name="current_password" class="form-control" required />
    </div>

    <div class="mb-3">
      <label class="form-label">নতুন পাসওয়ার্ড</label>
      <input type="password" name="new_password" class="form-control" required minlength="6" />
    </div>

    <div class="mb-3">
      <label class="form-label">নতুন পাসওয়ার্ড নিশ্চিত করুন</label>
      <input type="password" name="confirm_password" class="form-control" required minlength="6" />
    </div>

    <button type="submit" class="btn btn-warning btn-lg mt-3">পরিবর্তন করুন</button>
  </form>
</div>

<!-- Bottom Navigation -->
<div class="footer-nav">
  <a href="index.php">
    <i class="fas fa-home"></i>
    হোম
  </a>
  <a href="installments.php">
    <i class="fas fa-credit-card"></i>
    কিস্তি/কার্ড
  </a>
  <a href="profile.php">
    <i class="fas fa-user"></i>
    প্রোফাইল
  </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>