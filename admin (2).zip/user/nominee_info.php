<?php
// nominee.php (compact/minimal centered)
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }
$user_id = $_SESSION['user_id'];
$message = '';

// Ensure utf8mb4 for Bangla text
try {
  if (isset($pdo)) {
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
  }
} catch (Exception $e) { /* ignore */ }

// Convert Bangla digits → English digits
function bn2en_digits($str){
  $bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
  $en = ['0','1','2','3','4','5','6','7','8','9'];
  return str_replace($bn, $en, $str);
}

// Allow Bangla + English letters (space, dot, hyphen, apostrophe allowed)
function valid_bn_en_text($str){
  return (bool)preg_match('/^[\p{Bengali}A-Za-z\.\-\'\s]+$/u', $str);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $name         = trim($_POST['name'] ?? '');
  $mobile_input = trim($_POST['mobile'] ?? '');
  $relationship = trim($_POST['relationship'] ?? '');

  $mobile = bn2en_digits($mobile_input);

  if ($name === '' || $relationship === '' || $mobile === '') {
    $message = "সব ঘর পূরণ করুন।";
  } elseif (!valid_bn_en_text($name)) {
    $message = "নামের ক্ষেত্রে শুধু বাংলা/ইংরেজি বর্ণ, স্পেস, (.), (-), (') ব্যবহার করুন।";
  } elseif (!valid_bn_en_text($relationship)) {
    $message = "সম্পর্ক ঘরে শুধু বাংলা/ইংরেজি বর্ণ, স্পেস, (.), (-), (') ব্যবহার করুন।";
  } elseif (!preg_match('/^[0-9]{10,14}$/', $mobile)) {
    $message = "মোবাইল নম্বর ১০–১৪ ডিজিটের ইংরেজি অঙ্কে দিন।";
  } else {
    try{
      $stmt = $pdo->prepare("SELECT 1 FROM nominee_info WHERE user_id=?");
      $stmt->execute([$user_id]);

      if($stmt->rowCount()>0){
        $pdo->prepare("UPDATE nominee_info SET name=?, mobile=?, relationship=? WHERE user_id=?")
            ->execute([$name,$mobile,$relationship,$user_id]);
      }else{
        $pdo->prepare("INSERT INTO nominee_info (user_id,name,mobile,relationship) VALUES (?,?,?,?)")
            ->execute([$user_id,$name,$mobile,$relationship]);
      }
      header("Location: documents.php?msg=nominee_saved");
      exit();
    }catch(Exception $e){
      $message = "ত্রুটি: ".$e->getMessage();
    }
  }
}

// Load existing data
$stmt = $pdo->prepare("SELECT * FROM nominee_info WHERE user_id=?");
$stmt->execute([$user_id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>নমিনি তথ্য</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  :root{
    --brand:#0b3d62;
    --bg:#f5f7fa; 
    --text:#1f2a37; 
    --muted:#6b7b93;
    --border:#d5deea;
    --app-max:420px;
    --footer-h:68px;
  }
  *{ box-sizing:border-box; }
  html,body{
    margin:0; padding:0; width:100%; min-height:100%;
    background:var(--bg); color:var(--text); overflow-x:hidden;
    font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,'SolaimanLipi',sans-serif;
  }
  .page{
    max-width:var(--app-max); margin:0 auto;
    padding:10px 10px calc(var(--footer-h) + env(safe-area-inset-bottom) + 12px);
  }

  /* Compact card */
  .card-like{
    background:#fff; border:1px solid var(--border);
    border-radius:10px; padding:12px;
    box-shadow:0 4px 14px rgba(0,0,0,.04);
  }

  /* Compact stepper */
  .stepper{ display:flex; justify-content:space-between; gap:6px; margin-bottom:10px; }
  .step{ width:33.33%; display:flex; flex-direction:column; align-items:center; gap:4px; }
  .dot{
    width:26px; height:26px; border-radius:50%; display:grid; place-items:center;
    font-weight:700; font-size:.85rem;
  }
  .dot.active{ background:var(--brand); color:#fff; }
  .dot.inactive{ background:#e9eef5; color:#44546a; }
  .sublabel{ font-size:.78rem; font-weight:700; color:#2d3b4b; }
  .muted{ color:var(--muted); }

  .title{
    font-weight:800; font-size:1rem; text-align:center;
    margin:4px 0 10px;
  }

  /* Compact form */
  .form-label{
    color:#2f3f54; font-weight:600; font-size:.85rem;
    margin-bottom:4px;
  }
  .form-control{
    height:40px; border-radius:10px; font-size:.95rem; padding:.4rem .65rem;
  }
  .form-control:focus{
    border-color:var(--brand);
    box-shadow:0 0 0 3px rgba(11,61,98,.12);
  }
  .mb-3{ margin-bottom:.65rem !important; }
  .mb-2{ margin-bottom:.5rem !important; }

  .form-text{ font-size:.78rem; color:var(--muted); margin-top:4px; }

  .btn-next, .btn-secondary{
    height:40px; border-radius:10px; font-weight:700; border:0; font-size:.92rem;
  }
  .btn-next{ background:var(--brand); color:#fff; }
  .btn-next:hover{ background:#092f4d; }
  .btn-secondary{ background:#e9eef5; color:#1c2a3a; }
  .btn-secondary:hover{ background:#dfe7f2; }

  /* Footer (compact) */
  .footer-nav{
    position:fixed; left:50%; transform:translateX(-50%);
    bottom:0; width:100%; max-width:var(--app-max);
    background:var(--brand); color:#fff; z-index:999;
    padding:8px 6px; display:flex; justify-content:space-around; gap:6px;
    border-top-left-radius:10px; border-top-right-radius:10px;
    box-shadow:0 -6px 16px rgba(0,0,0,.2);
  }
  .footer-nav a{
    color:#fff; text-decoration:none; font-size:.82rem; line-height:1.1;
    display:flex; flex-direction:column; align-items:center; gap:2px; flex:1;
  }
  .footer-nav i{ font-size:1.05rem; }
</style>
</head>
<body>
  <div class="page">
    <!-- Stepper -->
    <div class="stepper card-like">
      <div class="step">
        <div class="dot inactive">1</div>
        <div class="sublabel muted">আপনার তথ্য</div>
      </div>
      <div class="step">
        <div class="dot active">2</div>
        <div class="sublabel">নমিনির তথ্য</div>
      </div>
      <div class="step">
        <div class="dot inactive">3</div>
        <div class="sublabel muted">ছবি</div>
      </div>
    </div>

    <!-- Form card -->
    <div class="card-like">
      <h5 class="title">নমিনি তথ্য</h5>

      <?php if($message): ?>
        <div class="alert alert-danger" style="border-radius:10px; padding:.5rem .75rem; font-size:.9rem;"><?= htmlspecialchars($message) ?></div>
      <?php endif; ?>

      <form method="POST" id="nomineeForm" novalidate>
        <div class="mb-3">
          <label class="form-label">নাম (বাংলা/English)</label>
          <input type="text" name="name" class="form-control"
            placeholder="উদাহরণ: রহিম উদ্দিন / Rahim Uddin"
            value="<?= htmlspecialchars($data['name'] ?? '') ?>" required autocomplete="name">
        </div>

        <div class="mb-3">
          <label class="form-label">মোবাইল নম্বর (English digits only)</label>
          <input type="tel" name="mobile" inputmode="numeric" pattern="[0-9]{10,14}"
            class="form-control" placeholder="উদাহরণ: 017XXXXXXXX"
            value="<?= htmlspecialchars(bn2en_digits($data['mobile'] ?? '')) ?>"
            required title="শুধু ইংরেজি 0-9 ডিজিট, 10–14 সংখ্যা" aria-describedby="mobileHelp">
          <div id="mobileHelp" class="form-text"></div>
        </div>

        <div class="mb-2">
          <label class="form-label">সম্পর্ক (বাংলা/English)</label>
          <input type="text" name="relationship" class="form-control"
            placeholder="যেমন: স্ত্রী / Wife, ভাই / Brother"
            value="<?= htmlspecialchars($data['relationship'] ?? '') ?>" required autocomplete="relationship">
        </div>

        <div class="d-flex gap-2 mt-3">
          <a class="btn btn-secondary w-50" href="personal_info.php">
            <i class="fa-solid fa-chevron-left me-1"></i> পূর্ববর্তী
          </a>
          <button type="submit" class="btn btn-next w-50">পরবর্তী</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Bottom nav -->
  <nav class="footer-nav">
    <a href="index.php"><i class="fas fa-home"></i>হোম</a>
    <a href="installments.php"><i class="fas fa-credit-card"></i>কিস্তি</a>
    <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
  </nav>

  <!-- JS: Convert Bangla digits in mobile on submit -->
  <script>
    (function(){
      const map = {'০':'0','১':'1','২':'2','৩':'3','৪':'4','৫':'5','৬':'6','৭':'7','৮':'8','৯':'9'};
      function toEnglishDigits(s){
        return s.replace(/[০-৯]/g, d => map[d] || d).replace(/[^0-9]/g,'');
      }
      const form = document.getElementById('nomineeForm');
      form.addEventListener('submit', function(){
        const mobile = form.querySelector('input[name="mobile"]');
        if (mobile) mobile.value = toEnglishDigits(mobile.value);
        ['name','relationship'].forEach(n=>{
          const el = form.querySelector(`input[name="${n}"]`);
          if (el) el.value = el.value.trim();
        });
      });
    })();
  </script>
</body>
</html>
