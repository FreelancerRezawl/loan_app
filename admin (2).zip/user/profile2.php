<?php
// user/profile.php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }

$user_id = $_SESSION['user_id'];
$name    = $_SESSION['user_name'] ?? '';

// Fetch mobile
$mobile = '';
$stmt = $pdo->prepare("SELECT mobile FROM users WHERE id = ?");
$stmt->execute([$user_id]);
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) $mobile = $row['mobile'] ?? '';

// Fetch photo
$photo_url = '';
$stmt = $pdo->prepare("SELECT user_photo FROM documents WHERE user_id = ?");
$stmt->execute([$user_id]);
if ($doc = $stmt->fetch(PDO::FETCH_ASSOC)) {
  if (!empty($doc['user_photo'])) $photo_url = "../uploads/" . $doc['user_photo'];
}

// Fetch personal info
$pi = [];
$stmt = $pdo->prepare("SELECT * FROM personal_info WHERE user_id = ?");
$stmt->execute([$user_id]);
if ($data = $stmt->fetch(PDO::FETCH_ASSOC)) $pi = $data;

// Helper
function s($v){ return htmlspecialchars($v ?? '—'); }
$disp = [
  'name'              => $pi['name'] ?? $name,
  'mobile'            => $pi['mobile'] ?? $mobile,
  'nid'               => $pi['nid'] ?? '—',
  'family_members'    => $pi['family_members'] ?? '—',
  'earning_members'   => $pi['earning_members'] ?? '—',
  'job'               => $pi['job'] ?? '—',
  'income'            => $pi['income'] ?? '—',
  'present_address'   => $pi['present_address'] ?? '—',
  'permanent_address' => $pi['permanent_address'] ?? '—',
  'car_own'           => $pi['car_own'] ?? '—',
  'house_own'         => $pi['house_own'] ?? '—',
  'loan_purpose'      => $pi['loan_purpose'] ?? '—',
];
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
<title>প্রোফাইল</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>

<style>
  :root{
    --main:#0b3d62;
    --bg:#f2f4f7;
    --ink:#111827;
    --app-max:420px;
    --footer-h:84px;
  }
  *{ box-sizing:border-box; }
  html,body{
    margin:0; padding:0; width:100%; min-height:100%;
    overflow-x:hidden; background:var(--bg); color:var(--ink);
    font-family:system-ui,'SolaimanLipi',-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  }
  .app{
    max-width:var(--app-max); margin:0 auto;
    padding:0 12px calc(var(--footer-h) + env(safe-area-inset-bottom) + 16px);
  }

  .profile-photo{ text-align:center; padding:20px 0 10px; }
  .profile-photo img{
    width:90px; height:90px; border-radius:50%; object-fit:cover;
    border:3px solid #fff; box-shadow:0 3px 10px rgba(0,0,0,.2);
  }
  .profile-name{ font-weight:800; font-size:1.1rem; margin-top:8px; color:var(--main); }
  .profile-mobile{ font-size:.9rem; font-weight:600; color:#6b7b93; }

  .card-box{
    background:#fff; border-radius:14px; padding:14px;
    box-shadow:0 4px 16px rgba(0,0,0,.08);
    border:1px solid #e3e8ef; margin:0 2px;
  }
  .card-title{
    display:flex; align-items:center; justify-content:space-between;
    font-weight:800; font-size:1rem; margin-bottom:10px; color:#2c3e50;
  }
  .card-title span i{ color:var(--main); margin-right:6px; font-size:1.1rem; }
  .edit-icon{ color:var(--main); text-decoration:none; font-size:1.1rem; }
  .edit-icon:hover{ color:#ff9800; }

  /* info list */
  .list{ list-style:none; margin:0; padding:0; }
  .item{
    display:flex; justify-content:space-between; align-items:flex-start; gap:10px;
    padding:9px 0; border-bottom:1px solid #f1f3f6; font-size:.95rem;
  }
  .item:last-child{ border-bottom:none; }
  .item:hover{ background:#f9fbfd; border-radius:6px; }
  .k{ font-weight:700; color:#2d4058; }
  .v{ font-weight:600; color:#111; text-align:right; max-width:60%; word-break:break-word; }
  .item.muted .v{ color:#6f809a; }

  /* footer */
  .footer{
    position:fixed; bottom:0; left:0; right:0;
    background:var(--main); color:#fff;
    max-width:var(--app-max); margin:0 auto;
    display:flex; justify-content:space-around; padding:8px 0;
    border-top-left-radius:12px; border-top-right-radius:12px;
    box-shadow:0 -4px 16px rgba(0,0,0,.25); z-index:1000;
  }
  .footer a{ flex:1; text-align:center; text-decoration:none; color:#fff; font-weight:700; font-size:.9rem; padding:4px 0; }
  .footer i{ display:block; font-size:1.2rem; margin-bottom:2px; }
</style>
</head>
<body>
<div class="app">

  <!-- Profile header -->
  <div class="profile-photo">
    <?php if ($photo_url): ?>
      <img src="<?= htmlspecialchars($photo_url) ?>" alt="প্রোফাইল ছবি" loading="lazy">
    <?php else: ?>
      <img src="https://via.placeholder.com/90x90.png?text=User" alt="प्रোফাইল ছবি" loading="lazy">
    <?php endif; ?>
    <div class="profile-name"><?= s($disp['name']) ?></div>
    <div class="profile-mobile"><?= s($disp['mobile']) ?></div>
  </div>

  <!-- Card -->
  <div class="card-box">
    <div class="card-title">
      <span><i class="fa-solid fa-user"></i> ব্যক্তিগত তথ্য</span>
      <!-- Edit option removed as requested -->
    </div>

    <!-- All fields -->
    <ul class="list">
      <li class="item"><span class="k">নাম</span><span class="v"><?= s($disp['name']) ?></span></li>
      <li class="item"><span class="k">মোবাইল</span><span class="v"><?= s($disp['mobile']) ?></span></li>
      <li class="item"><span class="k">জাতীয় পরিচয়পত্র</span><span class="v"><?= s($disp['nid']) ?></span></li>
      <li class="item"><span class="k">পরিবারের সদস্য</span><span class="v"><?= s($disp['family_members']) ?></span></li>
      <li class="item"><span class="k">উপার্জনকারী</span><span class="v"><?= s($disp['earning_members']) ?></span></li>
      <li class="item"><span class="k">পেশা</span><span class="v"><?= s($disp['job']) ?></span></li>
      <li class="item"><span class="k">মাসিক আয়</span><span class="v"><?= s($disp['income']) ?></span></li>
      <li class="item"><span class="k">বর্তমান ঠিকানা</span><span class="v"><?= s($disp['present_address']) ?></span></li>
      <li class="item"><span class="k">স্থায়ী ঠিকানা</span><span class="v"><?= s($disp['permanent_address']) ?></span></li>
      <li class="item"><span class="k">গাড়ি আছে</span><span class="v"><?= s($disp['car_own']) ?></span></li>
      <li class="item"><span class="k">বাড়ি আছে</span><span class="v"><?= s($disp['house_own']) ?></span></li>
      <li class="item muted"><span class="k">লোনের উদ্দেশ্য</span><span class="v"><?= s($disp['loan_purpose']) ?></span></li>
    </ul>
  </div>

</div>

<!-- Footer -->
<div class="footer">
  <a href="index.php"><i class="fas fa-home"></i>হোম</a>
  <a href="installments.php"><i class="fas fa-credit-card"></i>কিস্তি কার্ড</a>
  <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
