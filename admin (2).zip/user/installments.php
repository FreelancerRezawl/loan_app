<?php
// user/installments.php — Single-card UI with in-card data, EMI parity with homepage
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../index.php'); exit(); }

$user_id   = $_SESSION['user_id'];
$name      = $_SESSION['user_name'] ?? '';

// Static card face (replace with DB values if available)
$card_number = '5247  ****  ****  9976';
$card_holder = strtoupper(htmlspecialchars($name));
$valid_till  = '01/12/2029';

// Fetch latest loan regardless of status
$stmt = $pdo->prepare("
  SELECT amount, duration_months, total_amount, interest_rate, status, created_at
  FROM loan_requests
  WHERE user_id = ?
  ORDER BY created_at DESC, id DESC
  LIMIT 1
");
$stmt->execute([$user_id]);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);

$hasLoan = (bool)$loan;
$status  = $hasLoan ? ($loan['status'] ?? 'Pending') : 'Pending';
$amount  = $hasLoan ? (float)$loan['amount'] : 0;
$months  = $hasLoan ? max(1, (int)$loan['duration_months']) : 0;

// Same algorithm as homepage: simple interest 0.20% per month
$monthly_rate = 0.002; // 0.20% মাসিক সুদ
$emi = ($hasLoan && $months > 0)
  ? round(($amount * (1 + $monthly_rate * $months)) / $months, 2)
  : 0;

$isApproved = in_array($status, ['Success','Approved'], true);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
  <title>কিস্তি/কার্ড</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --g1:#ff9966; --g2:#ff5e62; /* warm gradient */
    }
    *{box-sizing:border-box}
    body{
      margin:0; background:#f4f6fb;
      font-family: system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial; color:#111827;
      min-height:100vh; display:flex; flex-direction:column; align-items:center;
      padding:18px 12px 90px; overflow-x:hidden;
    }
    .wrap{ width:100%; max-width:420px; display:grid; place-items:center; gap:14px; }

    /* Card */
    .card-visa{      position:relative; width:100%; max-width:380px; height:260px; margin-top:10px; border-radius:18px; overflow:hidden;      background: linear-gradient(135deg, var(--g1), var(--g2));      box-shadow: 0 16px 38px rgba(0,0,0,.22);      color:#fff;    }
    .card-body{ position:relative; height:100%; padding:18px; padding-bottom:66px; display:flex; flex-direction:column; }
    .top{ display:flex; align-items:center; justify-content:space-between; }
    .chip{
      width:54px; height:40px; border-radius:10px; display:grid; place-items:center; font-size:1.15rem;
      background: linear-gradient(145deg, #ffd89b, #f7b733); color:#1a2537;
      box-shadow: inset 0 1px 0 rgba(255,255,255,.6);
    }
    .brand{ font-weight:900; letter-spacing:1px; }
    .contactless{ position:absolute; top:22px; left:88px; opacity:.9; transform:rotate(90deg); }
    .number{ margin-top:26px; font-size:1.5rem; letter-spacing:3px; font-weight:700; text-shadow:0 1px 3px rgba(0,0,0,.35); }
    .row{ margin-top:auto; display:flex; align-items:flex-end; justify-content:space-between; }
    .label{ display:block; font-size:.72rem; letter-spacing:1px; opacity:.9; }
    .holder strong, .expiry strong{ font-size:1rem; letter-spacing:.4px; }
    .visa-water{ position:absolute; right:16px; bottom:16px; font-weight:900; font-size:2rem; letter-spacing:1px; opacity:.15; }

    /* In-card info panel */
    .info-panel{ position:absolute; left:14px; right:14px; bottom:10px; display:flex; align-items:center; justify-content:flex-start; gap:12px; padding:0; border-radius:12px; background:transparent; border:0; backdrop-filter:none; }
    .info-item small{ display:block; font-size:.75rem; opacity:.9; color:#fff; }
    .info-item .value{ color:#fff; font-weight:800; font-size:1.05rem; letter-spacing:.3px; }
    .info-right{ margin-left:auto; text-align:right; }}
    .info-panel .unit{ font-size:.85rem; opacity:.9; margin-left:4px; font-weight:600; }
    .info-sep{ height:32px; width:1px; background:rgba(255,255,255,.35); }

    /* Footer */
    .footer-nav{
      position:fixed; bottom:0; left:0; right:0; width:100%; max-width:420px; margin:0 auto;
      background:#0d3a58; color:#fff; display:flex; justify-content:space-around; text-align:center;
      padding:10px 6px; box-shadow:0 -6px 16px rgba(0,0,0,.25); z-index:10; border-radius:12px 12px 0 0;
    }
    .footer-nav a{ color:#fff; font-size:.92rem; text-decoration:none; flex:1; }
    .footer-nav i{ font-size:1.35rem; display:block; margin-bottom:4px; }
    .footer-nav a.active i,.footer-nav a.active{ filter:brightness(1.1); font-weight:700; }
  </style>
</head>
<body>
  <div class="wrap">

    <!-- Pretty card -->
    <div class="card-visa" aria-label="VISA Card">
      <div class="card-body">
        <div class="top">
          <div class="chip"><i class="fa-solid fa-microchip"></i></div>
          <div class="brand">VISA</div>
        </div>
        <i class="fa-solid fa-wifi contactless"></i>

        <div class="number"><?= htmlspecialchars($card_number) ?></div>

        <div class="row">
          <div class="holder">
            <span class="label">CARD HOLDER</span>
            <strong><?= $card_holder ?></strong>
          </div>
          <div class="expiry">
            <span class="label">VALID TILL</span>
            <strong><?= htmlspecialchars($valid_till) ?></strong>
          </div>
        </div>

        <div class="visa-water">VISA</div>

        <?php if ($hasLoan): ?>
          <div class="info-panel">
            <?php if ($isApproved): ?>
              <div class="info-item">
                <small>মোট টাকা</small>
                <div class="value">৳<?= number_format($amount, 0) ?></div>
              </div>
              <div class="info-sep"></div>
              <div class="info-item info-right">
                <small>কিস্তি</small>
                <div class="value"><?= number_format($emi, 2) ?> <span class="unit">/ <?= $months ?> মাস</span></div>
              </div>
            <?php else: ?>
              <div class="info-item info-right">
                <small>কিস্তি</small>
                <div class="value"><?= number_format($emi, 2) ?> <span class="unit">/ <?= $months ?> মাস</span></div>
              </div>
            <?php endif; ?>
          </div>
        <?php else: ?>
          <div class="info-panel" style="justify-content:center;">
    <div class="info-item" style="text-align:right; width:auto;">
              <small>কোনো ঋণ আবেদন নেই</small>
              <div class="value">
                <a href="loan_request.php" class="btn btn-light btn-sm mt-1" style="font-weight:700;">ঋণ আবেদন</a>
              </div>
            </div>
          </div>
        <?php endif; ?>

      </div>
    </div>

  </div>

  <!-- Footer -->
  <div class="footer-nav">
    <a href="index.php"><i class="fas fa-home"></i>হোম</a>
    <a href="installments.php" class="active"><i class="fas fa-credit-card"></i>কিস্তি/কার্ড</a>
    <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
