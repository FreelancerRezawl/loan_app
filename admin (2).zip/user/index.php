<?php
// user/index.php — Dashboard (mobile-first, BN copy, 0.20% monthly interest, random globe spin)
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: ../index.php");
  exit();
}

$user_id = $_SESSION['user_id'];
$name    = $_SESSION['user_name'] ?? '';

// মোট অনুমোদিত ঋণ (Success স্ট্যাটাস)
$stmt = $pdo->prepare("SELECT SUM(amount) AS total FROM loan_requests WHERE user_id = ? AND status = 'Success'");
$stmt->execute([$user_id]);
$total_loan = (float)($stmt->fetch()['total'] ?? 0);

// সর্বশেষ লোন (সর্বশেষ আইডি/টাইম অনুসারে)
$stmt = $pdo->prepare("
  SELECT amount, duration_months, status
  FROM loan_requests
  WHERE user_id = ?
  ORDER BY created_at DESC, id DESC
  LIMIT 1
");
$stmt->execute([$user_id]);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);

$monthly       = 0.00;
$status        = 'Pending';
$monthly_rate  = 0.002; // 0.20% মাসিক সুদ

if ($loan) {
  $status = $loan['status'] ?? 'Pending';
  if ($status === 'Success') {
    $amount = (float)$loan['amount'];
    $months = max(1, (int)$loan['duration_months']);

    // সরল সুদ: মোট = P * (1 + r * n), কিস্তি = মোট / n
    $monthly = round(($amount * (1 + $monthly_rate * $months)) / $months, 2);

    // যদি EMI চান (চক্রবৃদ্ধি): মন্তব্য খুলে দিন
    // $r = $monthly_rate; $n = $months;
    // $monthly = $r > 0 ? round($amount * $r * pow(1+$r, $n) / (pow(1+$r, $n) - 1), 2) : round($amount/$n, 2);
  }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
  <title>ড্যাশবোর্ড</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <style>
    :root{
      --brand:#0a3d62;
      --brand-dark:#093252;
      --bg:#f4f6f9;
      --ink:#0f172a;
      --maxw:420px;
      --footer-h:84px;
      --radius:14px;
      --shadow:0 3px 8px rgba(0,0,0,.08);
    }
    *{box-sizing:border-box}
    html,body{
      margin:0;padding:0;width:100%;min-height:100%;
      overflow-x:hidden;background:var(--bg);color:var(--ink)
    }
    body{
      padding-bottom:calc(var(--footer-h) + env(safe-area-inset-bottom) + 12px);
      font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,'SolaimanLipi',sans-serif
    }
    .app{max-width:var(--maxw);margin:0 auto;padding:12px}

    /* Header / Welcome */
    .welcome{
      background: linear-gradient(135deg, var(--brand) 0%, var(--brand-dark) 100%);
      color:#fff;border-radius:12px;padding:16px 14px;
      display:flex;align-items:center;justify-content:space-between
    }
    .welcome p{margin:0;font-size:.95rem;opacity:.9}
    .welcome h5{margin:4px 0 0;font-weight:700}

    .logo-badge{
      width:56px;height:56px;border-radius:50%;
      display:grid;place-items:center;
      background:#ffffff1a;border:1px solid #ffffff33;
      box-shadow:inset 0 1px 0 rgba(255,255,255,.35), 0 2px 6px rgba(0,0,0,.15)
    }

    /* Globe: random 360° spin */
    .globe{
      width:36px;height:36px;object-fit:contain;will-change:transform;
      animation: globe-spin var(--spin-duration, 6s) linear infinite;
      animation-direction: var(--spin-direction, normal);
      animation-delay: var(--spin-delay, 0s);
    }
    @keyframes globe-spin{
      from{ transform: rotate(var(--start-rot, 0deg)); }
      to  { transform: rotate(calc(var(--start-rot, 0deg) + 360deg)); }
    }
    @media (prefers-reduced-motion: reduce){
      .globe{ animation: none !important; }
    }

    /* Summary cards */
    .summary-card{border-radius:var(--radius);padding:14px;background:#fff;text-align:center;box-shadow:var(--shadow)}
    .summary-card small{display:block;color:#64748b}
    .summary-card i{font-size:1.35rem;margin-bottom:6px}

    /* CTAs */
    .btn-brand{background:var(--brand);border:none;border-radius:12px;color:#fff;padding:12px 16px;font-weight:700}
    .btn-brand:hover{background:var(--brand-dark)}

    /* Slider */
    .slider{width:100%;height:190px;border-radius:12px;overflow:hidden;box-shadow:var(--shadow);margin-top:14px}
    .slider img{width:100%;height:100%;object-fit:cover}

    /* Loan status */
    .status-wrap{text-align:center}
    .status-pill{display:inline-block;border-radius:999px;padding:8px 14px;font-weight:800;color:#fff;margin:12px 0 6px}
    .status-success{background:#0f5132}
    .status-danger{background:#842029}
    .status-note{font-size:.95rem;color:#374151;font-weight:600}

    /* Feature icons */
    .icon-box{background:#fff;border-radius:12px;padding:10px;margin-top:14px;box-shadow:var(--shadow);display:flex;justify-content:space-between;gap:6px}
    .icon-item{flex:0 0 25%;text-align:center;font-size:.86rem;color:#334155}
    .icon-item i{font-size:1.35rem;margin-bottom:6px}

    /* Footer */
    .footer-nav{position:fixed;left:0;right:0;bottom:0;background:var(--brand);color:#fff;z-index:1000}
    .footer-inner{max-width:var(--maxw);margin:0 auto;display:flex;justify-content:space-around;align-items:center;padding:8px 0}
    .footer-nav a{color:#fff;text-decoration:none;font-size:.9rem;text-align:center}
    .footer-nav i{display:block;font-size:1.2rem;margin-bottom:4px}
  </style>
</head>
<body>
<div class="app">

  <!-- Welcome -->
  <div class="welcome">
    <div>
      <p>বিশ্ব ব্যাংক হতে আপনাকে স্বাগতম!</p>
      <h5><?= htmlspecialchars($name) ?></h5>
    </div>
    <div class="logo-badge">
      <img src="../img/2.png" class="globe" alt="Logo">
    </div>
  </div>

  <!-- Summary -->
  <div class="row g-3 mt-2">
    <div class="col-6">
      <div class="summary-card">
        <i class="fa-solid fa-money-bill-wave text-success"></i>
        <small>মোট অনুমোদিত ঋণ</small>
        <h5 class="mb-0"><?= number_format($total_loan, 2) ?> ৳</h5>
      </div>
    </div>
    <div class="col-6">
      <div class="summary-card">
        <i class="fa-solid fa-credit-card" style="color:#0a3d62"></i>
        <small>মাসিক কিস্তি </small>
        <h5 class="mb-0"><?= number_format($monthly, 2) ?> ৳</h5>
      </div>
    </div>
  </div>

  <!-- CTA: Loan request -->
  <div class="mt-3">
    <a href="loan_request.php" class="btn btn-brand w-100">
      লোন আবেদন করুন
    </a>
  </div>

  <!-- Slider -->
  <div id="carouselExample" class="carousel slide slider" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active"><img src="slider/IMG-WA0010.jpg" alt="slide-1"></div>
      <div class="carousel-item"><img src="slider/IMG-WA0011.jpg" alt="slide-2"></div>
      <div class="carousel-item"><img src="slider/IMG-WA0012.jpg" alt="slide-3"></div>
    </div>
  </div>

  <!-- CTA: Profile -->
  <div class="mt-3">
    <a href="personal_info.php" class="btn btn-brand w-100">
        ব্যক্তিগত তথ্য জমা দিন
    </a>
  </div>

  <!-- Loan Status -->
  <?php if ($status === 'Success'): ?>
    <div class="status-wrap">
      <div class="status-pill status-success">আপনার লোন অনুমোদিত হয়েছে</div>
    </div>
    <p class="status-note">আপনার কিস্তি সময়মতো পরিশোধ করতে দয়া করে “কিস্তি/কার্ড” মেনু দেখুন।</p>
  <?php elseif ($status === 'Pending'): ?>
    <div class="status-wrap">
      <div class="status-pill status-danger">আপনার আবেদন পর্যালোচনায় আছে</div>
    </div>
  <?php elseif ($status === 'Process'): ?>
    <div class="status-wrap">
      <div class="status-pill status-danger">আপনার আবেদন প্রক্রিয়াধীন</div>
    </div>
  <?php elseif ($status === 'Cancel' || $status === 'Rejected'): ?>
    <div class="status-wrap">
      <div class="status-pill status-danger">দুঃখিত, আপনার আবেদন বাতিল করা হয়েছে</div>
    </div>
  <?php endif; ?>

  <!-- Feature icons -->
  <div class="icon-box">
    <div class="icon-item">
      <i class="fa-solid fa-file-lines" style="color:#f59e0b"></i>
      <div>আবেদন</div>
    </div>
    <div class="icon-item">
      <i class="fa-solid fa-shield-heart" style="color:#10b981"></i>
      <div>নিরাপত্তা</div>
    </div>
    <div class="icon-item">
      <i class="fa-solid fa-book" style="color:#f97316"></i>
      <div>গাইড</div>
    </div>
    <div class="icon-item">
      <a href="../help.php" style="text-decoration:none;color:inherit">
        <i class="fa-solid fa-headset" style="color:#22c55e"></i>
        <div>সহায়তা</div>
      </a>
    </div>
  </div>

  <div style="height:calc(var(--footer-h) + 10px)"></div>
</div>

<!-- Footer -->
<nav class="footer-nav">
  <div class="footer-inner">
    <a href="index.php"><i class="fa-solid fa-house"></i>হোম</a>
    <a href="installments.php"><i class="fa-solid fa-credit-card"></i>কিস্তি/কার্ড</a>
    <a href="profile.php"><i class="fa-solid fa-user"></i>প্রোফাইল</a>
  </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
/* Randomize globe spin each load */
(function(){
  const el = document.querySelector('.globe');
  if(!el) return;

  const dur   = (Math.random() * 4 + 5).toFixed(2) + 's'; // 5–9s
  const dir   = Math.random() > 0.5 ? 'normal' : 'reverse';
  const delay = (Math.random() * 1).toFixed(2) + 's';     // 0–1s
  const start = Math.floor(Math.random() * 360) + 'deg';  // any start angle

  el.style.setProperty('--spin-duration', dur);
  el.style.setProperty('--spin-direction', dir);
  el.style.setProperty('--spin-delay', delay);
  el.style.setProperty('--start-rot', start);
})();
</script>
</body>
</html>
