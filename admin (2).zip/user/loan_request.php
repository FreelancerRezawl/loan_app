<?php
// user/loan_status.php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }
$user_id = $_SESSION['user_id'];

/* Fetch the most recent loan request for this user */
$stmt = $pdo->prepare("SELECT id, amount, duration_months, method, account_number, status, created_at
                       FROM loan_requests
                       WHERE user_id = ?
                       ORDER BY created_at DESC, id DESC
                       LIMIT 1");
$stmt->execute([$user_id]);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);

/* If there is no request yet, force user to start flow */
if (!$loan) { header("Location: transfer_method.php"); exit(); }

/* Helpers to parse flattened bank string & mask account */
$method  = $loan['method'] ?? '';
$accRaw  = $loan['account_number'] ?? '';

$bankName   = '';
$branchName = '';
$holderName = '';
$acctNumber = $accRaw;

/* If Bank, parse "Bank: X | Branch: Y | Holder: Z | Ac: N | Routing: R" */
if (strtolower($method) === 'bank') {
  $parts = array_map('trim', explode('|', $accRaw));
  foreach ($parts as $p) {
    if (stripos($p, 'Bank:') === 0)   $bankName   = trim(substr($p, 5));
    if (stripos($p, 'Branch:') === 0) $branchName = trim(substr($p, 7));
    if (stripos($p, 'Holder:') === 0) $holderName = trim(substr($p, 7));
    if (stripos($p, 'Ac:') === 0)     $acctNumber = trim(substr($p, 3));
  }
}

/* Mask wallet/bank account number: keep last 3 visible */
function mask_number($s) {
  if (!$s) return '';
  $digits = preg_replace('/\D+/', '', $s);
  $len = mb_strlen($digits, 'UTF-8');
  if ($len <= 3) return $digits;
  $end = mb_substr($digits, -3, null, 'UTF-8');
  return str_repeat('•', max(0, $len - 3)) . $end;
}
$masked = mask_number($acctNumber);

/* Status presentation */
$status = $loan['status'] ?? 'Pending';
$statusText = [
  'Pending' => 'আপনার আবেদন প্রক্রিয়াধীন রয়েছে।',
  'Process' => 'আপনার আবেদন যাচাই করা হচ্ছে।',
  'Success' => '',
  'Cancel'  => 'দুঃখিত, আবেদনটি বাতিল হয়েছে।'
];

/* Use brand color for Pending/Process */
$brandColor = '#0b3d62';
$badge = [
  'Pending' => ['bg' => '#e8f0ff', 'fg' => $brandColor, 'btn' => 'বিচারাধীন…'],
  'Process' => ['bg' => '#f0f7ff', 'fg' => $brandColor, 'btn' => 'যাচাই চলছে…'],
  'Success' => ['bg' => '#eaf7ee', 'fg' => '#1b7a3a',   'btn' => 'সফল'],
  'Cancel'  => ['bg' => '#fdeaea', 'fg' => '#9c1c1c',   'btn' => 'বাতিল']
];
$sty = $badge[$status] ?? $badge['Pending'];

/* ---------- Deposit settings to embed on this page ---------- */
$st  = $pdo->query("SELECT * FROM deposit_settings WHERE id=1");
$set = $st->fetch(PDO::FETCH_ASSOC);
$isDepositOpen = ($set && !empty($set['is_active']));

$msg = '';
$upload_dir = '../uploads/';
if (!is_dir($upload_dir)) { @mkdir($upload_dir, 0777, true); }

// Handle deposit submit (same-page POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['__deposit_form'])) {
  $d_method = $_POST['method'] ?? '';
  $d_amount = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
  $d_file   = $_FILES['slip'] ?? null;

  if (!in_array($d_method, ['bKash','Nagad'], true)) {
    $msg = 'মেথড নির্বাচন করুন।';
  } elseif ($d_amount <= 0) {
    $msg = 'টাকার পরিমাণ দিন।';
  } elseif (!$d_file || $d_file['error'] !== UPLOAD_ERR_OK) {
    $msg = 'ছবি আপলোড করুন।';
  } else {
    $ext = strtolower(pathinfo($d_file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','pdf'])) {
      $msg = 'শুধু JPG/PNG/PDF ফাইল দিন।';
    } else {
      $new = 'deposit_user'.$user_id.'_'.time().rand(100,999).'.'.$ext;
      if (move_uploaded_file($d_file['tmp_name'], $upload_dir.$new)) {
        $pdo->prepare("INSERT INTO deposits (user_id, method, amount, slip_path) VALUES (?,?,?,?)")
            ->execute([$user_id, $d_method, $d_amount, $new]);
        header("Location: index.php?ok=1");
        exit();
      } else {
        $msg = 'ফাইল আপলোড ব্যর্থ হয়েছে।';
      }
    }
  }
}

/* --------- Review avatars (you will replace '#' with your own image URLs/paths) --------- */
$reviews = [
  ['img'=>'https://img.freepik.com/premium-photo/portrait-bangladeshi-man_53876-84050.jpg', 'name'=>'মাহিন ইসলাম',   'amount'=>'100,000', 'loc'=>'ঢাকা, বাংলাদেশ',      'text'=>'দ্রুত প্রসেস, কাগজপত্রও সহজ ছিল। ধন্যবাদ!'],
  ['img'=>'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShm86W4J0N-A45cpGDEDAgN9y2vuT8r98l2g&s', 'name'=>'নাদিয়া রহমান',  'amount'=>'150,000', 'loc'=>'চট্টগ্রাম, বাংলাদেশ', 'text'=>'অনলাইনে আবেদন করেই পাই। কাস্টমার সাপোর্ট চমৎকার।'],
  ['img'=>'https://images.unsplash.com/photo-1690037901153-7fd75205941a?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YmFuZ2xhZGVzaGklMjBib3l8ZW58MHx8MHx8fDA%3D', 'name'=>'সাদমান হোসেন', 'amount'=>'200,000', 'loc'=>'সিলেট, বাংলাদেশ',     'text'=>'ইএমআই ক্যালকুলেশন পরিষ্কার, বাজেট ম্যানেজ করা সহজ।'],
  ['img'=>'https://media.istockphoto.com/id/962485000/photo/indian-woman-portrait-at-the-temple.jpg?s=612x612&w=0&k=20&c=ZVkkx-WGVst9cz-sk-TqTMtd45ZVFDMGLAybzgwXmrQ=', 'name'=>'মৌ দত্ত',       'amount'=>'80,000',  'loc'=>'রাজশাহী, বাংলাদেশ',   'text'=>'ডকুমেন্ট চেক ফাস্ট, ২ দিনের মধ্যে অ্যাপ্রুভ।'],
  ['img'=>'https://live.staticflickr.com/7359/12601842865_1434198cbc_b.jpg', 'name'=>'শারমিন ইসলাম',  'amount'=>'95,000',  'loc'=>'ফেনী, বাংলাদেশ',      'text'=>'সাপোর্টের সাথে যোগাযোগ খুব দ্রুত হয়েছে।'],
  ['img'=>'https://media.licdn.com/dms/image/v2/D5612AQGIlD5ezOWSUQ/article-cover_image-shrink_720_1280/article-cover_image-shrink_720_1280/0/1714849405380?e=2147483647&v=beta&t=VkufAPgQV2pkyoZIylUIe_B3-BO70EbXL0y_1VS-eNQ', 'name'=>'আরিফুল হক',     'amount'=>'300,000', 'loc'=>'খুলনা, বাংলাদেশ',      'text'=>'সুদ রেট ভালো, কিস্তি সময়মতো দিতে পারছি।'],
  ['img'=>'https://i.pinimg.com/736x/94/a4/19/94a419660a7b37aa5154f9b10db33e06.jpg', 'name'=>'রিয়াদ খান',    'amount'=>'90,000',  'loc'=>'রংপুর, বাংলাদেশ',     'text'=>'ড্যাশবোর্ডে স্ট্যাটাস দেখা যায়—খুব সুবিধা।'],
  ['img'=>'https://img.freepik.com/free-photo/indian-woman-posing-cute-stylish-outfit-camera-smiling_482257-122351.jpg?semt=ais_hybrid&w=740&q=80', 'name'=>'আনিকা চৌধুরী',  'amount'=>'250,000', 'loc'=>'ময়মনসিংহ, বাংলাদেশ', 'text'=>'ভাবনার চেয়ে সহজ প্রক্রিয়া, সাপোর্ট টিম সহায়ক।'],
  ['img'=>'https://images.pexels.com/photos/2375936/pexels-photo-2375936.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500', 'name'=>'অর্ণব দেব',     'amount'=>'500,000', 'loc'=>'কুমিল্লা, বাংলাদেশ',   'text'=>'বড় এমাউন্টেও ঝামেলা হয়নি, টিম কোলাবোরেটিভ।'],
  ['img'=>'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQjvJ8AQIzt3iXlKTmspAG-R7n7ZPzw7r255w&s', 'name'=>'শায়লা ইসলাম',  'amount'=>'110,000', 'loc'=>'গাজীপুর, বাংলাদেশ',   'text'=>'সাপোর্টের সাথে যোগাযোগ দ্রুত রেসপন্সিভ।'],
];

/* === NEW: fetch per-user “Loan Status – Extra Line” === */
$ue_stmt = $pdo->prepare("SELECT label, value FROM user_status_extra WHERE user_id=? LIMIT 1");
$ue_stmt->execute([$user_id]);
$ue = $ue_stmt->fetch(PDO::FETCH_ASSOC);
$ls_extra_label = $ue['label'] ?? '';
$ls_extra_value = $ue['value'] ?? '';

/* === Calculate Display Amount for big-amount === */
$display_amount = 0; // Default to 0
if ($ls_extra_value !== '' && is_numeric($ls_extra_value)) {
  $display_amount = (float)$ls_extra_value;
} elseif ($isDepositOpen && isset($set['payable_amt']) && is_numeric($set['payable_amt'])) {
  $display_amount = (float)$set['payable_amt'];
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
<title>লোন স্ট্যাটাস</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  :root{
    --brand:#0b3d62; --brand-dark:#092f4d; --text:#22313f; --bg:#f5f7fa;
    --app-max:420px; --footer-h:86px; --ring:0 0 0 3px rgba(11,61,98,.15);
    --line:#e8eef6; --danger-bg:#ffe9e9; --danger-br:#ffcdcd; --danger-tx:#a23333;
  }
  *{ box-sizing:border-box; }
  html, body{ margin:0; padding:0; width:100%; min-height:100%;
    overflow-x:hidden; background:var(--bg); color:var(--text);
    font-family:'SolaimanLipi',system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; }
  .app{ max-width:var(--app-max); margin:0 auto; padding:16px 14px calc(var(--footer-h) + env(safe-area-inset-bottom) + 16px); }
  .card-like{ background:#fff; border-radius:16px; padding:18px 16px; box-shadow:0 8px 24px rgba(0,0,0,.06); }
  .topbar{ display:flex; align-items:center; gap:10px; margin-bottom:12px; }
  .back{ width:36px; height:36px; display:grid; place-items:center; border-radius:8px; background:rgba(11,61,98,.12); color:var(--brand); text-decoration:none; }
  .title{ font-weight:800; font-size:1.05rem; color:#0b2244; margin:0; }
  .sub{ color:#3a4a63; font-weight:700; margin:10px 0 8px; }
  .blue-panel{ background:var(--brand); color:#fff; border-radius:14px; padding:14px; }
  .blue-row{ display:flex; justify-content:space-between; gap:8px; padding:6px 0; border-bottom:1px dashed rgba(255,255,255,.35); }
  .blue-row:last-child{ border-bottom:none; }
  .blue-row .k{ opacity:.95; font-weight:700; }
  .blue-row .v{ font-weight:700; text-align:right; }
  .status-text{ text-align:center; color:#5b6781; font-weight:700; padding:0 6px; }
  .btn-pill{ display:block; width:200px; margin:12px auto 4px; background:#0a3d62; border:none; height:46px; border-radius:12px; color:#fff; font-weight:800; }
  .btn-pill:focus{ outline:none; box-shadow:var(--ring); }
  .review-card{ background:#fff; border-radius:12px; padding:12px; margin-top:10px; box-shadow:0 1px 6px rgba(0,0,0,.05); display:flex; gap:12px; align-items:flex-start; }
  .avatar{ width:44px; height:44px; border-radius:50%; object-fit:cover; border:2px solid #e7eef6; flex:0 0 44px; }
  .review-name{ font-weight:700; color:#1b7a3a; }
  .review-amount{ font-size:.88rem; color:#677483; }
  .review-loc{ font-size:.82rem; color:#8a97a3; }

  .cardish{background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 8px 24px rgba(0,0,0,.05);padding:14px}
  .warn{background:var(--danger-bg);border:1px solid var(--danger-br);color:var(--danger-tx);border-radius:12px;padding:12px;font-weight:700}
  .big-amount{font-size:32px;font-weight:900;text-align:center;margin:12px 0 14px;color:#0b2244}
  .agent{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--line);border-radius:12px;padding:12px;margin-bottom:10px}
  .agent img{width:42px;height:42px;border-radius:10px;object-fit:cover}
  .agent .lbl{font-weight:800;margin-bottom:2px}
  .method-wrap{display:flex;gap:8px;margin:10px 0 12px}
  .btn-check+label{flex:1;border:1px solid var(--line);border-radius:10px;padding:10px 8px;font-weight:800;cursor:pointer;background:#fff;text-align:center}
  .btn-check:checked+label{background:var(--brand);color:#fff;border-color:var(--brand)}
  .form-label{font-weight:700}
  .submit-btn{height:46px;font-weight:900}

  .footer-shell{ position:fixed; left:0; right:0; bottom:0; background:transparent; z-index:1000; }
  .footer-nav{ max-width:var(--app-max); margin:0 auto; background:var(--brand); color:#fff;
    display:flex; justify-content:space-around; align-items:center; padding:10px 6px;
    border-radius:12px 12px 0 0; box-shadow:0 -6px 16px rgba(0,0,0,.25); }
  .footer-nav a{ flex:1; color:#fff; text-decoration:none; text-align:center; }
  .footer-nav i{ font-size:1.35rem; display:block; margin-bottom:4px; }
  .footer-nav span{ font-size:.9rem; }
</style>
</head>
<body>

<div class="app">
  <div class="card-like">
    <div class="topbar">
      <a class="back" href="index.php"><i class="fa-solid fa-chevron-left"></i></a>
      <h5 class="title mb-0">টাকা উত্তোলন</h5>
    </div>

    <div class="sub">ব্যাংক তথ্য</div>

    <div class="blue-panel">
      <div class="blue-row"><div class="k">মাধ্যম</div><div class="v">: <?= htmlspecialchars($method ?: '—') ?></div></div>
      <div class="blue-row"><div class="k">দাতার নাম</div><div class="v">: <?= $holderName ? htmlspecialchars($holderName) : 'Not Set' ?></div></div>
      <div class="blue-row"><div class="k">ব্যাংকের নাম</div><div class="v">: <?= $bankName ? htmlspecialchars($bankName) : 'Not Set' ?></div></div>
      <div class="blue-row"><div class="k">একাউন্ট নাম্বার</div><div class="v">: <?= htmlspecialchars($masked ?: '—') ?></div></div>

      <?php if ($ls_extra_label !== '' && $ls_extra_value !== ''): ?>
        <div class="blue-row">
          <div class="k"><?= htmlspecialchars($ls_extra_label) ?></div>
          <div class="v">: <?= htmlspecialchars($ls_extra_value) ?></div>
        </div>
      <?php endif; ?>
    </div>

    <p class="status-text">
      <?php
        $msgText = $statusText[$status] ?? $statusText['Pending'];
        if (trim($msgText) !== '') { echo htmlspecialchars($msgText); }
      ?>
    </p>

    <?php if ($status !== 'Success'): ?>
      <?php $fg = $sty['fg']; $bgAlpha = (strlen($fg) === 7 ? $fg . '22' : $fg); ?>
      <button class="btn-pill" style="background:<?= htmlspecialchars($bgAlpha) ?>;color:<?= htmlspecialchars($fg) ?>;border:2px solid <?= htmlspecialchars($fg) ?>;">
        <?= htmlspecialchars($sty['btn']) ?>
      </button>
    <?php endif; ?>
  </div>

  <!-- Embedded Deposit Section -->
  <?php if ($isDepositOpen): ?>
    <div class="cardish mt-3 mb-2">
      <div class="warn">
        <?= $set['note_html'] /* trusted from admin */ ?>
      </div>

      <?php if (!empty($ls_extra_label) && $ls_extra_value !== '' && is_numeric($ls_extra_value)): ?>
        <div style="text-align:center; font-size:0.85rem; color:#6c757d; margin-bottom:-8px;">
          <?= htmlspecialchars($ls_extra_label) ?>
        </div>
      <?php endif; ?>
      <div class="big-amount"><?= number_format($display_amount, 2) ?> টাকা</div>

      <?php if (!empty($set['bkash_agent'])): ?>
        <div class="agent">
          <img src="https://play-lh.googleusercontent.com/1CRcUfmtwvWxT2g-xJF8s9_btha42TLi6Lo-qVkVomXBb_citzakZX9BbeY51iholWs=w240-h480-rw" alt="bKash">
          <div>
            <div class="lbl">বিকাশ এজেন্ট:</div>
            <div><?= htmlspecialchars($set['bkash_agent']) ?></div>
          </div>
        </div>
      <?php endif; ?>

      <?php if (!empty($set['nagad_agent'])): ?>
        <div class="agent">
          <img src="https://play-lh.googleusercontent.com/EQC9NtbtRvsNcU1r_5Dr8pWm3hPfN3OjGjzkOqzCEPDJvqBGKyfU9-a2ajNtcrIg1rs" alt="Nagad">
          <div>
            <div class="lbl">নগদ এজেন্ট:</div>
            <div><?= htmlspecialchars($set['nagad_agent']) ?></div>
          </div>
        </div>
      <?php endif; ?>

      <?php if (isset($_GET['ok'])): ?>
        <div class="alert alert-success mt-2">সাবমিট হয়েছে। ভেরিফাই হলে জানানো হবে।</div>
      <?php elseif ($msg): ?>
        <div class="alert alert-danger mt-2"><?= htmlspecialchars($msg) ?></div>
      <?php endif; ?>

      <form method="POST" enctype="multipart/form-data" class="mt-2">
        <input type="hidden" name="__deposit_form" value="1">
        <div class="method-wrap">
          <input class="btn-check" type="radio" name="method" id="m_bkash" value="bKash" checked>
          <label for="m_bkash"><i class="fa-solid fa-mobile-screen me-1"></i> bKash</label>

          <input class="btn-check" type="radio" name="method" id="m_nagad" value="Nagad">
          <label for="m_nagad"><i class="fa-solid fa-wallet me-1"></i> Nagad</label>
        </div>

        <div class="mb-3">
          <label class="form-label">টাকার পরিমাণ</label>
          <input type="number" step="0.01" min="0" name="amount" class="form-control"
                 placeholder="যেমন: <?= number_format($display_amount,2) ?>"
                 value="<?= htmlspecialchars($display_amount) ?>" required>
        </div>

        <div class="mb-2">
          <label class="form-label">ছবি আপলোড করুন</label>
          <input type="file" name="slip" class="form-control" accept="image/*,application/pdf" required>
          <div class="form-text text-muted">JPG/PNG/PDF — ক্যাশআউট/পেমেন্ট রিসিপ্ট</div>
        </div>

        <button class="btn btn-primary w-100 submit-btn">সাবমিট করুন</button>
      </form>
    </div>
  <?php else: ?>
    <div class="alert alert-warning mt-3">ডিপোজিট বর্তমানে বন্ধ রয়েছে।</div>
  <?php endif; ?>

  <!-- Reviews -->
  <h6 class="mt-3" style="font-weight:700;color:#0b2244;">ব্যবহারকারীদের মতামত</h6>
  <?php foreach ($reviews as $rv): ?>
    <div class="review-card">
      <img class="avatar" src="<?= htmlspecialchars($rv['img']) ?>" alt="<?= htmlspecialchars($rv['name']) ?>">
      <div>
        <div class="review-name"><?= htmlspecialchars($rv['name']) ?></div>
        <div class="review-loc"><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($rv['loc']) ?></div>
        <div class="review-amount"><?= htmlspecialchars($rv['amount']) ?> টাকা ঋণ পেয়েছি</div>
        <div><?= htmlspecialchars($rv['text']) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Footer -->
<div class="footer-shell">
  <nav class="footer-nav">
    <a href="index.php"><i class="fas fa-home"></i><span>হোম</span></a>
    <a href="installments.php"><i class="fas fa-credit-card"></i><span>কিস্তি</span></a>
    <a href="profile.php"><i class="fas fa-user"></i><span>প্রোফাইল</span></a>
  </nav>
</div>
</body>
</html>
