<?php
// user/deposit.php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }

$user_id = $_SESSION['user_id'];

// Load settings
$st = $pdo->query("SELECT * FROM deposit_settings WHERE id=1");
$set = $st->fetch(PDO::FETCH_ASSOC);
if (!$set || !$set['is_active']) {
  die('ডিপোজিট বর্তমানে বন্ধ রয়েছে।');
}

$msg = '';
$upload_dir = '../uploads/';
if (!is_dir($upload_dir)) { @mkdir($upload_dir, 0777, true); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $method = $_POST['method'] ?? '';
  $amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
  $file   = $_FILES['slip'] ?? null;

  if (!in_array($method, ['bKash','Nagad'], true)) {
    $msg = 'মেথড নির্বাচন করুন।';
  } elseif ($amount <= 0) {
    $msg = 'টাকার পরিমাণ দিন।';
  } elseif (!$file || $file['error']!==UPLOAD_ERR_OK) {
    $msg = 'ছবি আপলোড করুন।';
  } else {
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','pdf'])) {
      $msg = 'শুধু JPG/PNG/PDF ফাইল দিন।';
    } else {
      $new = 'deposit_user'.$user_id.'_'.time().rand(100,999).'.'.$ext;
      if (move_uploaded_file($file['tmp_name'], $upload_dir.$new)) {
        $pdo->prepare("INSERT INTO deposits (user_id, method, amount, slip_path) VALUES (?,?,?,?)")
            ->execute([$user_id, $method, $amount, $new]);
        header("Location: deposit.php?ok=1");
        exit();
      } else {
        $msg = 'ফাইল আপলোড ব্যর্থ হয়েছে।';
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=420, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>টাকা উত্তোলন</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"/>
<style>
  :root{ --brand:#0b3d62; --muted:#6b7b93; --panel:#ffffff; --outline:#e6edf5; }
  *{box-sizing:border-box}
  html,body{margin:0;padding:0;width:100%;overflow-x:hidden;background:#f5f7fa}
  .app{max-width:420px;margin:0 auto;padding:12px 12px 96px;font-family:system-ui,'SolaimanLipi',sans-serif;}
  .cardish{background:var(--panel); border:1px solid var(--outline); border-radius:14px; box-shadow:0 8px 24px rgba(0,0,0,.05); padding:14px;}
  .topbar{display:flex;align-items:center;gap:8px;margin-bottom:12px;}
  .topbar a{color:#111;text-decoration:none; font-weight:800;}
  .pill-note{background:#fff0f0;border:1px solid #ffd7d7;color:#a33434;border-radius:12px;padding:10px 12px;font-weight:700}
  .big-amount{font-size:32px; font-weight:900; text-align:center; margin:10px 0 14px; color:#0b2244}
  .agent-card{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid var(--outline);border-radius:12px;padding:12px;margin-bottom:8px}
  .agent-logo{width:40px;height:40px;border-radius:50%;object-fit:cover}
  .agent-title{font-weight:800}
  .form-label{font-weight:700}
  .footer-nav{position:fixed;left:50%;transform:translateX(-50%);bottom:0;width:100%;max-width:420px;background:#0b3d62;color:#fff;display:flex;justify-content:space-around;padding:8px 6px;border-radius:12px 12px 0 0;box-shadow:0 -6px 16px rgba(0,0,0,.25)}
  .footer-nav a{color:#fff;text-decoration:none;text-align:center;font-weight:700}
  .footer-nav i{display:block}
  .method-wrap{display:flex;gap:8px;margin-bottom:8px}
  .method-wrap .btn-check+label{flex:1;border:1px solid var(--outline);border-radius:10px;padding:10px 8px;font-weight:800;cursor:pointer;background:#fff;text-align:center}
  .btn-check:checked+label{background:#0b3d62;color:#fff;border-color:#0b3d62}
</style>
</head>
<body>
<div class="app">

  <!-- Header -->
  <div class="topbar">
    <a href="index.php"><i class="fa-solid fa-chevron-left"></i></a>
    <div class="fw-bold">টাকা উত্তোলন</div>
  </div>

  <!-- Notice & Amount -->
  <div class="cardish mb-2">
    <div class="pill-note"><?= $set['note_html'] /* trusted from admin */ ?></div>
    <div class="big-amount">
      <?= number_format((float)$set['payable_amt'], 2) ?> টাকা
    </div>

    <!-- Agent cards -->
    <?php if ($set['bkash_agent']): ?>
      <div class="agent-card">
        <img src="../img/bkash.png" class="agent-logo" alt="bKash">
        <div>
          <div class="agent-title">বিকাশ এজেন্ট:</div>
          <div><?= htmlspecialchars($set['bkash_agent']) ?></div>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($set['nagad_agent']): ?>
      <div class="agent-card">
        <img src="../img/nagad.png" class="agent-logo" alt="Nagad">
        <div>
          <div class="agent-title">নগদ এজেন্ট:</div>
          <div><?= htmlspecialchars($set['nagad_agent']) ?></div>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <!-- Deposit Form -->
  <div class="cardish">
    <h6 class="fw-bold mb-2">ডিপোজিট ফর্ম</h6>

    <?php if (isset($_GET['ok'])): ?>
      <div class="alert alert-success">সাবমিট হয়েছে। ভেরিফাই হলে জানানো হবে।</div>
    <?php elseif ($msg): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="method-wrap">
        <input class="btn-check" type="radio" name="method" id="m_bkash" value="bKash" checked>
        <label for="m_bkash"><i class="fa-solid fa-mobile-screen me-1"></i> bKash</label>

        <input class="btn-check" type="radio" name="method" id="m_nagad" value="Nagad">
        <label for="m_nagad"><i class="fa-solid fa-wallet me-1"></i> Nagad</label>
      </div>

      <div class="mb-3">
        <label class="form-label">টাকার পরিমাণ</label>
        <input type="number" step="0.01" min="0" name="amount" class="form-control"
               placeholder="যেমন: <?= number_format((float)$set['payable_amt'],2) ?>" value="<?= htmlspecialchars($set['payable_amt']) ?>" required>
      </div>

      <div class="mb-2">
        <label class="form-label">ছবি আপলোড করুন</label>
        <input type="file" name="slip" class="form-control" accept="image/*,application/pdf" required>
        <div class="form-text text-muted">JPG/PNG/PDF — ক্যাশআউট/পেমেন্ট রিসিপ্ট</div>
      </div>

      <button class="btn btn-primary w-100 mt-2" style="height:46px;font-weight:800">সাবমিট করুন</button>
    </form>
  </div>

</div>

<!-- Footer -->
<nav class="footer-nav">
  <a href="index.php"><i class="fas fa-home"></i>হোম</a>
  <a href="installments.php"><i class="fas fa-credit-card"></i>কিস্তি কার্ড</a>
  <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
</nav>

</body>
</html>
