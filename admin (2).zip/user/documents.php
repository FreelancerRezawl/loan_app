<?php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }

$user_id    = $_SESSION['user_id'];
$message    = '';
$upload_dir = '../uploads/';

if (!is_dir($upload_dir)){
  if (!mkdir($upload_dir, 0777, true)) { $message = "আপলোড ফোল্ডার তৈরি করা যায়নি।"; }
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $allowed = ['jpg','jpeg','png','pdf'];
  $fields  = ['nid_front','nid_back','user_photo','nominee_photo','signature'];
  $paths   = [];

  foreach($fields as $f){
    if(!isset($_FILES[$f]) || $_FILES[$f]['error'] !== 0){ $message = ucfirst(str_replace('_',' ',$f))." আপলোড করুন।"; break; }
    $name = $_FILES[$f]['name'];  $tmp = $_FILES[$f]['tmp_name'];
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if(!in_array($ext,$allowed)){ $message = "অবৈধ ফাইল ফরম্যাট: $f (JPG/PNG/PDF)"; break; }

    $fname = "{$f}_user{$user_id}_".time().rand(100,999).".$ext";
    if(move_uploaded_file($tmp, $upload_dir.$fname)){ $paths[$f] = $fname; }
    else { $message = "ফাইল আপলোড ব্যর্থ: $f"; break; }
  }

  if(empty($message) && $paths){
    try{
      $has = $pdo->prepare("SELECT 1 FROM documents WHERE user_id=?");
      $has->execute([$user_id]);
      if($has->rowCount()>0){
        $set=[]; $vals=[];
        foreach($paths as $k=>$v){ $set[]="$k=?"; $vals[]=$v; }
        $vals[]=$user_id;
        $pdo->prepare("UPDATE documents SET ".implode(', ',$set)." WHERE user_id=?")->execute($vals);
      }else{
        $cols = implode(', ', array_keys($paths));
        $qs   = rtrim(str_repeat('?,', count($paths)), ',');
        $stmt = $pdo->prepare("INSERT INTO documents (user_id,$cols) VALUES (?, $qs)");
        $stmt->execute(array_merge([$user_id], array_values($paths)));
      }
      header("Location: rin.php?msg=document_uploaded");
      exit();
    }catch(Exception $e){ $message = "ডাটাবেজ ত্রুটি: ".$e->getMessage(); }
  }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>ডকুমেন্ট আপলোড</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  :root{
    --brand:#0b3d62;
    --bg:#f5f7fa;
    --text:#1f2a37;
    --muted:#6b7b93;
    --border:#d5deea;
    --app-max:420px;
    --footer-h:68px;
  }
  *{ box-sizing:border-box; }
  html,body{
    margin:0; padding:0; width:100%; min-height:100%;
    background:var(--bg); color:var(--text); overflow-x:hidden;
    font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,'SolaimanLipi',sans-serif;
  }
  .page{
    max-width:var(--app-max); margin:0 auto;
    padding:10px 10px calc(var(--footer-h) + env(safe-area-inset-bottom) + 12px);
  }

  /* Compact card */
  .card-like{
    background:#fff; border:1px solid var(--border);
    border-radius:10px; padding:12px;
    box-shadow:0 4px 14px rgba(0,0,0,.04);
  }

  /* Compact stepper */
  .stepper{ display:flex; justify-content:space-between; gap:6px; margin-bottom:10px; }
  .step{ width:33.33%; display:flex; flex-direction:column; align-items:center; gap:4px; }
  .dot{
    width:26px; height:26px; border-radius:50%; display:grid; place-items:center;
    font-weight:700; font-size:.85rem;
  }
  .dot.active{ background:var(--brand); color:#fff; }
  .dot.inactive{ background:#e9eef5; color:#44546a; }
  .sublabel{ font-size:.78rem; font-weight:700; color:#2d3b4b; }
  .muted{ color:var(--muted); }

  .title{
    font-weight:800; font-size:1rem; text-align:center;
    margin:4px 0 10px;
  }

  /* Compact form */
  .form-label{
    color:#2f3f54; font-weight:600; font-size:.85rem;
    margin-bottom:4px;
  }
  .form-control{
    height:40px; border-radius:10px; font-size:.95rem; padding:.4rem .65rem;
  }
  input[type="file"].form-control{
    padding:.3rem .6rem; height:40px;
  }
  .form-control:focus{
    border-color:var(--brand);
    box-shadow:0 0 0 3px rgba(11,61,98,.12);
  }
  .mb-3{ margin-bottom:.65rem !important; }
  .mb-2{ margin-bottom:.5rem !important; }
  .hint{ font-size:.78rem; color:var(--muted); margin-top:4px; }

  /* Preview compact */
  .preview{
    border:1px solid #e6edf5; background:#f9fbff;
    border-radius:10px; padding:8px; margin-top:8px;
    display:flex; align-items:center; gap:8px;
  }
  .preview img{
    width:56px; height:56px; border-radius:8px; object-fit:cover; border:1px solid #dde7f2;
  }
  .pdf-badge{
    width:56px; height:56px; border-radius:8px; border:1px dashed #9bb3ca;
    display:flex; align-items:center; justify-content:center; font-weight:800; color:#304255;
  }
  .fname{ font-size:.85rem; color:#304255; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }

  /* Footer compact */
  .footer-nav{
    position:fixed; left:50%; transform:translateX(-50%);
    bottom:0; width:100%; max-width:var(--app-max);
    background:var(--brand); color:#fff; z-index:999;
    padding:8px 6px; display:flex; justify-content:space-around; gap:6px;
    border-top-left-radius:10px; border-top-right-radius:10px;
    box-shadow:0 -6px 16px rgba(0,0,0,.2);
  }
  .footer-nav a{
    color:#fff; text-decoration:none; font-size:.82rem; line-height:1.1;
    display:flex; flex-direction:column; align-items:center; gap:2px; flex:1;
  }
  .footer-nav i{ font-size:1.05rem; }

  .btn-submit, .btn-secondary{
    height:40px; border-radius:10px; font-weight:700; border:0; font-size:.92rem;
  }
  .btn-submit{ background:var(--brand); color:#fff; }
  .btn-submit:hover{ background:#092f4d; }
  .btn-secondary{ background:#e9eef5; color:#1c2a3a; }
  .btn-secondary:hover{ background:#dfe7f2; }
</style>
</head>
<body>
  <div class="page">
    <!-- Stepper -->
    <div class="stepper card-like">
      <div class="step">
        <div class="dot inactive">1</div><div class="sublabel muted">আপনার তথ্য</div>
      </div>
      <div class="step">
        <div class="dot inactive">2</div><div class="sublabel muted">নমিনির তথ্য</div>
      </div>
      <div class="step">
        <div class="dot active">3</div><div class="sublabel">ছবি</div>
      </div>
    </div>

    <div class="card-like">
      <h5 class="title">ডকুমেন্ট আপলোড করুন</h5>

      <?php if($message): ?>
        <div class="alert alert-danger" style="border-radius:10px; padding:.5rem .75rem; font-size:.9rem;"><?= htmlspecialchars($message) ?></div>
      <?php endif; ?>

      <form method="POST" enctype="multipart/form-data" novalidate>
        <!-- NID front -->
        <div class="mb-3">
          <label class="form-label">আপনার আইডি কার্ডের সামনের দিক</label>
          <input type="file" id="nid_front" name="nid_front" class="form-control" accept="image/*,application/pdf" required>
          <div class="hint">JPG/PNG/PDF</div>
          <div id="pv_nid_front" class="preview d-none"></div>
        </div>

        <!-- NID back -->
        <div class="mb-3">
          <label class="form-label">আপনার আইডি কার্ডের বিপরীত দিক</label>
          <input type="file" id="nid_back" name="nid_back" class="form-control" accept="image/*,application/pdf" required>
          <div id="pv_nid_back" class="preview d-none"></div>
        </div>

        <!-- user photo -->
        <div class="mb-3">
          <label class="form-label">আপনার ছবি</label>
          <input type="file" id="user_photo" name="user_photo" class="form-control" accept="image/*" required>
          <div class="hint">সাদা ব্যাকগ্রাউন্ড হলে ভালো</div>
          <div id="pv_user_photo" class="preview d-none"></div>
        </div>

        <!-- nominee photo -->
        <div class="mb-3">
          <label class="form-label">নমিনির ছবি বা আইডি কার্ড</label>
          <input type="file" id="nominee_photo" name="nominee_photo" class="form-control" accept="image/*" required>
          <div id="pv_nominee_photo" class="preview d-none"></div>
        </div>

        <!-- signature -->
        <div class="mb-2">
          <label class="form-label">স্বাক্ষর</label>
          <input type="file" id="signature" name="signature" class="form-control" accept="image/*,application/pdf" required>
          <div id="pv_signature" class="preview d-none"></div>
        </div>

        <div class="d-flex gap-2 mt-3">
          <a class="btn btn-secondary w-50" href="nominee_info.php">
            <i class="fa-solid fa-chevron-left me-1"></i> পূর্ববর্তী
          </a>
          <button type="submit" class="btn btn-submit w-50">জমা দিন</button>
        </div>
      </form>
    </div>
  </div>

  <nav class="footer-nav">
    <a href="index.php"><i class="fas fa-home"></i>হোম</a>
    <a href="installments.php"><i class="fas fa-credit-card"></i>কিস্তি</a>
    <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
  </nav>

  <!-- tiny preview helper -->
  <script>
    function setupPreview(inputId, previewId){
      const input=document.getElementById(inputId);
      const box=document.getElementById(previewId);
      if(!input||!box) return;

      input.addEventListener('change', ()=>{
        box.classList.add('d-none');
        box.innerHTML='';
        const file=input.files && input.files[0];
        if(!file) return;

        const name=file.name;
        const ext=name.split('.').pop().toLowerCase();
        if(ext==='pdf'){
          box.innerHTML=`<div class="pdf-badge">PDF</div><div class="fname">${name}</div>`;
        }else{
          const url=URL.createObjectURL(file);
          box.innerHTML=`<img src="${url}" alt=""><div class="fname">${name}</div>`;
        }
        box.classList.remove('d-none');
      });
    }

    setupPreview('nid_front','pv_nid_front');
    setupPreview('nid_back','pv_nid_back');
    setupPreview('user_photo','pv_user_photo');
    setupPreview('nominee_photo','pv_nominee_photo');
    setupPreview('signature','pv_signature');
  </script>
</body>
</html>
