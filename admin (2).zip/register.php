<?php
session_start();
include 'config.php';
$error = ''; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $mobile   = trim($_POST['mobile'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $mobile === '' || $password === '') {
        $error = "সব ফিল্ড পূরণ করুন।";
    } elseif (!preg_match('/^01[3-9]\d{8}$/', $mobile)) {
        $error = "অবৈধ মোবাইল নম্বর।";
    } else {
        $stmt = $pdo->prepare("SELECT 1 FROM users WHERE mobile = ?");
        $stmt->execute([$mobile]);
        if ($stmt->rowCount() > 0) {
            $error = "এই মোবাইল নম্বর ইতিমধ্যে ব্যবহার হয়েছে।";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, mobile, password) VALUES (?, ?, ?)");
            if ($stmt->execute([$name, $mobile, $hashed])) {
                $user_id = $pdo->lastInsertId();
                $_SESSION['user_id']   = $user_id;
                $_SESSION['user_name'] = $name;
                $_SESSION['mobile']    = $mobile;
                header("Location: user/index.php");
                exit;
            } else {
                $error = "কিছু ভুল হয়েছে।";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>রেজিস্টার</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    :root{
      --brand:#0967ac;    /* banner color */
      --btn:#049dc3;      /* button color */
      --btn-hover:#0386a8;
      --text:#0f172a;
      --ring: 0 0 0 3px rgba(4,157,195,.18);
    }

    body{
      margin:0;
      background:#fff;
      font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,'SolaimanLipi',sans-serif;
      color:var(--text);
      display:flex;
      flex-direction:column;
      align-items:center;
    }

    /* Top banner */
    .hero{
      width:100%;
      background:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      padding:14px 0;
    }
    .hero__img{
      width:200px;
      height:auto;
    }

    /* Container */
    .wrap{
      width:100%;
      max-width:420px;
      padding:20px;
      margin:30px auto;
    }

    .title{
      text-align:center;
      margin-bottom:16px;
      font-size:16px;
      font-weight:700;
    }

    /* Inputs */
    .form-label{
      font-size:13px;
      font-weight:600;
      margin-bottom:4px;
    }
    .pill{
      height:42px;
      border:2px solid var(--brand);
      border-radius:999px;
      padding:6px 14px;
      font-size:14px;
      width:100%;
      transition:border-color .15s, box-shadow .15s;
    }
    .pill:focus{box-shadow:var(--ring); border-color:var(--btn)}
    .field{margin:14px 0}

    /* Buttons */
    .btn-pill{
      width:100%;
      height:44px;
      border:none;
      border-radius:999px;
      background:var(--btn);
      color:#fff !important;
      font-weight:600;
      font-size:15px;
      display:flex;
      align-items:center;
      justify-content:center;
      transition:background .15s, transform .05s;
      text-decoration:none;
    }
    .btn-pill:hover{background:var(--btn-hover); color:#fff}
    .btn-pill:active{transform:translateY(1px)}
    .btn-pill:focus-visible{box-shadow:var(--ring); outline:0}

    .btn-spacer{margin-top:18px}

    .alert{
      border-radius:10px;
      padding:8px 12px;
      font-size:14px;
    }
  </style>
</head>
<body>

  <!-- Top banner -->
  <div class="hero">
    <img src="img/wb-top.png" alt="Logo" class="hero__img">
  </div>

  <!-- Register form -->
  <div class="wrap">
    <?php if ($error): ?>
      <div class="alert alert-danger text-center mb-3"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <h5 class="title">Register</h5>

    <form method="POST" novalidate>
      <div class="field">
        <label class="form-label">আপনার নাম</label>
        <input type="text" name="name" class="pill" placeholder="আপনার নাম" required>
      </div>

      <div class="field">
        <label class="form-label">মোবাইল নম্বর</label>
        <input type="tel" name="mobile" class="pill" placeholder="মোবাইল নম্বর দিন (ইংরেজি)" required>
      </div>

      <div class="field">
        <label class="form-label">পাসওয়ার্ড</label>
        <input type="password" name="password" class="pill" placeholder="পাসওয়ার্ড দিন (ইংরেজি)" required>
      </div>

      <div class="btn-spacer">
        <button type="submit" class="btn-pill">রেজিস্টার করুন</button>
      </div>

      <div class="btn-spacer">
        <a href="index.php" class="btn-pill" role="button">আপনার  অ্যাকাউন্ট লগ ইন করুন</a>
      </div>
    </form>
  </div>

</body>
</html>