<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <title>সাহায্য</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>

  <style>
    /* Base */
    *{margin:0;padding:0;box-sizing:border-box}
    body{
      font-family: Arial, "Helvetica Neue", sans-serif;
      background:#fff;
      color:#111;
      line-height:1.6;
      max-width:420px;
      margin:0 auto;
      min-height:100vh;
      padding-bottom:80px; /* footer space */
    }
    .container{padding:16px}

    /* Top Bar */
    .topbar{
      background:#0a3d62;
      color:#fff;
      height:48px;
      display:flex;
      align-items:center;
      padding:0 12px;
    }
    .topbar a{
      color:#fff;
      text-decoration:none;
      display:flex;
      align-items:center;
      gap:8px;
      font-size:1.05rem;
      font-weight:700;
    }
    .topbar i{font-size:1.1rem}

    /* Big Icon */
    .big-icon{
      text-align:center;
      margin:18px 0 10px;
    }
    .big-icon i{
      font-size:6rem;
      color:#111;
    }

    /* Paragraphs */
    .content{
      font-size:0.98rem;
      color:#222;
      margin:10px 0;
      text-align:justify;
    }

    /* Red Contact Cards */
    .contact-card{
      display:flex;
      align-items:center;
      gap:10px;
      background:#f44336;
      border-radius:10px;
      padding:10px 12px;
      margin:12px 0;
      text-decoration:none;
      color:#fff;
    }
    .contact-card i{
      font-size:1.8rem;
      width:40px;height:40px;
      display:flex;align-items:center;justify-content:center;
      background:rgba(255,255,255,.15);
      border-radius:8px;
      color:#fff;
      flex-shrink:0;
    }
    .contact-info{
      display:block;
      line-height:1.35;
    }
    .contact-title{
      font-weight:700;
      font-size:1rem;
      color:#fff;
      display:block;
    }
    .contact-link{
      display:inline-block;
      font-size:1rem;
      color:#0a66c2;
      background:#fff;
      padding:2px 0;
      border-radius:4px;
      text-decoration:none;
      margin-top:2px;
    }

    /* Footer Navigation */
    .footer-nav {
      position: fixed;
      bottom: 0; left: 0; right: 0;
      width: 100%;
      background: #0a3d62;
      color: white;
      padding: 8px 0;
      z-index: 1000;
      max-width: 420px;
      margin: 0 auto;
      display: flex;
      justify-content: space-around;
      text-align: center;
      border-radius: 12px 12px 0 0;
      box-shadow: 0 -3px 8px rgba(0,0,0,.25);
    }
    .footer-nav a {
      color: white;
      font-size: 0.85rem;
      text-decoration: none;
      flex:1;
    }
    .footer-nav i {
      font-size: 1.3rem;
      display: block;
      margin-bottom: 3px;
    }
  </style>
</head>
<body>

  <!-- Top Bar -->
  <div class="topbar">
    <a href="javascript:history.back()">
      <i class="fas fa-chevron-left"></i>
      <span>সাহায্য</span>
    </a>
  </div>

  <div class="container">

    <!-- Big Icon -->
    <div class="big-icon">
      <i class="fas fa-headset"></i>
    </div>

    <!-- Text Blocks -->
    <p class="content">
      নিচে দেওয়া যেকোনো মাধ্যমে আপনি আমাদের সাথে যোগাযোগ করতে পারেন অথবা সরাসরি অফিসে এসে যোগাযোগ করতে অ্যাপয়েন্টমেন্ট নিতে পারেন।
    </p>

    <p class="content">
     বাংলাদেশ বিশ্বব্যাংকের ঠিকানা: ঢাকা আগারগাও শেরেবাংলা নগর ১২০৭, ৩২ নাম্বার রোড ৮ নম্বর বাড়ি।
    </p>

    <p class="content">
      সদর দপ্তর : সদর দপ্তর যুক্তরাষ্ট্রের ওয়াশিংটন, ডি. সি.-তে অবস্থিত।
    </p>

    <!-- WhatsApp Card -->
    <a class="contact-card" href="https://wa.me/8801873-825101">
      <i class="fab fa-whatsapp"></i>
      <span class="contact-info">
        <span class="contact-title">WhatsApp - এ যোগাযোগ করুন</span>
        <span>
          <a class="contact-link" href="https://wa.me/8801873-825101">+8801873-825101</a>
        </span>
      </span>
    </a>

    <!-- Imo Card -->
    <a class="contact-card" href="tel:+8801873-825101">
      <i class="fas fa-comment-dots"></i>
      <span class="contact-info">
        <span class="contact-title">Imo - তে যোগাযোগ করুন</span>
        <span>
          <a class="contact-link" href="tel:+8801873-825101">+8801873-825101</a>
        </span>
      </span>
    </a>

  </div>

  <!-- Bottom Navigation -->
  <nav class="footer-nav">
    <a href="user/index.php">
      <i class="fas fa-home"></i>
      হোম
    </a>
    <a href="user/installments.php">
      <i class="fas fa-credit-card"></i>
      কিস্তি/কার্ড
    </a>
    <a href="user/profile.php">
      <i class="fas fa-user"></i>
      প্রোফাইল
    </a>
  </nav>

</body>
</html>
