<?php
// user/profile.php - Profile Menu
include '../config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$name = $_SESSION['user_name'];

// Fetch mobile number
$mobile = '';
$stmt = $pdo->prepare("SELECT mobile FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
if ($user) {
    $mobile = $user['mobile'];
}

// Fetch user profile photo from documents table
$photo_url = '';
$stmt = $pdo->prepare("SELECT user_photo FROM documents WHERE user_id = ?");
$stmt->execute([$user_id]);
$doc = $stmt->fetch();
if ($doc && !empty($doc['user_photo'])) {
    $photo_url = "../uploads/" . htmlspecialchars($doc['user_photo']);
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=420, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <title>প্রোফাইল</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
  <style>
    body {
      font-family: 'Helvetica Neue', Arial, sans-serif;
      background: #f4f6f9;
      padding-bottom: 70px;
      margin: 0;
      max-width: 420px;
      margin-left: auto;
      margin-right: auto;
      position: relative;
      overflow-x: hidden;
    }
    .profile-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    .profile-card {
      width: 100%;
      max-width: 400px;
      border-radius: 20px;
      background: white;
      box-shadow: 0 10px 20px rgba(0,0,0,0.08);
      overflow: hidden;
      padding: 20px;
      text-align: center;
    }
    .profile-header {
      padding: 20px 0;
      margin-bottom: 20px;
    }
    .profile-icon, .profile-img {
      width: 90px;
      height: 90px;
      border-radius: 50%;
      margin: 0 auto 10px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .profile-icon {
      background: #0a3d62;
      color: white;
      font-size: 2rem;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .profile-img {
      object-fit: cover;
      border: 3px solid #0a3d62;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .profile-title {
      font-size: 1.5rem;
      font-weight: 700;
      color: #2c3e50;
      margin: 0;
    }
    .profile-mobile {
      font-size: 1rem;
      color: #666;
      margin: 5px 0 0;
    }
    .menu-item {
      display: flex;
      align-items: center;
      gap: 10px;
      width: 100%;
      padding: 14px 20px;
      margin: 10px 0;
      background: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 12px;
      text-decoration: none;
      color: #333;
      font-size: 1rem;
      transition: all 0.2s ease;
    }
    .menu-item:hover { background: #e9ecef; transform: translateY(-1px); }
    .menu-item i { font-size: 1.1rem; }
    .logout-link { color: #dc3545 !important; border-color: #dc3545 !important; }
    .logout-link:hover { background: #f8d7da; color: #a9373b; }
    .footer-nav {
      position: fixed;
      bottom: 0;
      width: 100%;
      background: #0a3d62;
      color: white;
      padding: 8px 0;
      z-index: 1000;
      max-width: 420px;
      margin: 0 auto;
      left: 0;
      right: 0;
      display: flex;
      justify-content: space-around;
      text-align: center;
    }
    .footer-nav a { color: white; font-size: 0.85rem; text-decoration: none; }
    .footer-nav i { font-size: 1.2rem; display: block; margin-bottom: 4px; }
    .footer-nav a.active { font-weight: bold; }
  </style>
</head>
<body>

<div class="profile-container">
  <div class="profile-card">
    <div class="profile-header">
      <!-- Profile Icon / Photo -->
      <?php if ($photo_url): ?>
        <img src="<?= $photo_url ?>" alt="প্রোফাইল ছবি" class="profile-img">
      <?php else: ?>
        <div class="profile-icon">
          <i class="fas fa-user"></i>
        </div>
      <?php endif; ?>
      <div class="profile-title"><?= htmlspecialchars($name) ?></div>
      <div class="profile-mobile"><?= htmlspecialchars($mobile) ?></div>
    </div>
           <!-- 🔹 New Loan Request Menu -->
    <a href="loan_request.php" class="menu-item">
      <i class="fas fa-hand-holding-usd"></i> লোন আবেদন
    </a>
       <a href="personal_info.php" class="menu-item">
      <i class="fas fa-user"></i> ব্যক্তিগত তথ্য
    </a>
    <a href="bank_account.php" class="menu-item">
      <i class="fas fa-university"></i> ব্যাংক একাউন্ট
    </a>
    <a href="change_password.php" class="menu-item">
      <i class="fas fa-lock"></i> পাসওয়ার্ড পরিবর্তন
    </a>
    <a href="documents.php" class="menu-item">
      <i class="fas fa-upload"></i> ডকুমেন্ট আপলোড
    </a>
    <a href="nominee_info.php" class="menu-item">
      <i class="fas fa-users"></i> নমিনি তথ্য
    </a>

    <a href="../logout.php" class="menu-item logout-link">
      <i class="fas fa-sign-out-alt"></i> লগ আউট
    </a>


<!-- Bottom Navigation -->
<div class="footer-nav">
  <a href="index.php">
    <i class="fas fa-home"></i>
    হোম
  </a>
  <a href="installments.php">
    <i class="fas fa-credit-card"></i>
    কিস্তি/কার্ড
  </a>
  <a href="profile.php" class="active">
    <i class="fas fa-user"></i>
    প্রোফাইল
  </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
