<!-- Bottom Navigation Footer -->
<nav class="footer-nav">
  <div class="row text-center">
    <div class="col">
      <a href="index.php">
        <i class="fas fa-home"></i>
        <small>হোম</small>
      </a>
    </div>
    <div class="col">
      <a href="installments.php">
        <i class="fas fa-credit-card"></i>
        <small>কিস্তি/কার্ড</small>
      </a>
    </div>
    <div class="col">
      <a href="profile.php">
        <i class="fas fa-user"></i>
        <small>প্রোফাইল</small>
      </a>
    </div>
  </div>
</nav>