<?php
// user/index.php - Dashboard with Loan Status Box (Dark Colors, text-width box)
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$name    = $_SESSION['user_name'] ?? '';

// Total Loan Amount
$stmt = $pdo->prepare("SELECT SUM(amount) as total FROM loan_requests WHERE user_id = ? AND status = 'Success'");
$stmt->execute([$user_id]);
$total_loan = $stmt->fetch()['total'] ?? 0;

// Last loan
$stmt = $pdo->prepare("SELECT amount, duration_months, status FROM loan_requests WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 1");
$stmt->execute([$user_id]);
$loan = $stmt->fetch();

$monthly = 0;
if ($loan && $loan['status'] === 'Success') {
  $monthly = round(($loan['amount'] * 1.1) / max(1, (int)$loan['duration_months']), 2);
}

// Loan status
$status = $loan['status'] ?? 'Pending';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
  <title>হোম</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <style>
    :root{
      --main:#0b3d62;
      --bg:#e9f0f5;
      --ink:#0f172a;
      --gutter:12px;
      --app-max:420px;
      --footer-h:84px;
    }
    *{box-sizing:border-box;}
    html,body{
      margin:0;
      padding:0;
      width:100%;
      min-height:100%;
      overflow-x:hidden;         /* stop left/right scroll */
      background:var(--bg);
      color:var(--ink);
      font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,'SolaimanLipi',sans-serif;
      padding-bottom:calc(var(--footer-h) + env(safe-area-inset-bottom) + 16px);
    }
    .app{
      max-width:var(--app-max);
      margin:0 auto;
      padding:0 var(--gutter);
    }
    .welcome-box{
      background:var(--main); color:#fff; border-radius:12px;
      padding:14px 16px; margin-top:14px;
      display:flex; justify-content:space-between; align-items:center;
    }
    .welcome-left p{margin:0;font-size:.95rem;opacity:.9}
    .welcome-left h5{margin:4px 0 0;font-weight:700}

    /* 🔵 Floating logo badge (very light background) + randomized 360° spin */
    .logo-wrap{
      --ring-hue: 210; /* JS will randomize this slightly each load */
      width:56px; height:56px; border-radius:50%;
      display:grid; place-items:center;
      background:
        radial-gradient(70% 70% at 30% 30%, hsla(var(--ring-hue), 85%, 98%, 1) 0%, hsla(var(--ring-hue), 85%, 97%, 1) 60%, hsla(var(--ring-hue), 85%, 96%, 1) 100%),
        linear-gradient(135deg, hsla(var(--ring-hue), 90%, 95%, .55), hsla(var(--ring-hue), 90%, 92%, .45));
      box-shadow:
        0 2px 6px rgba(0,0,0,.12),
        inset 0 1px 0 rgba(255,255,255,.35);
      border:1px solid rgba(255,255,255,.25);
      position:relative;
      isolation:isolate;
    }
    .logo-wrap::after{
      content:"";
      position:absolute; inset:4px;
      border-radius:50%;
      background:radial-gradient(60% 60% at 30% 30%, rgba(255,255,255,.35), rgba(255,255,255,0));
      pointer-events:none;
      z-index:-1;
    }
    .globe-logo{
      width:36px; height:36px; object-fit:contain;
      filter: drop-shadow(0 1px 1px rgba(0,0,0,.15));
      transform-origin:center;
      /* randomized via JS: duration + direction + start angle */
      animation: spin var(--spin-duration, 6s) linear infinite;
      animation-direction: var(--spin-direction, normal);
    }
    @keyframes spin{
      from{ transform:rotate(0deg); }
      to{   transform:rotate(360deg); }
    }

    .summary-card{
      border-radius:14px; padding:15px; background:#fff; text-align:center;
      box-shadow:0 3px 8px rgba(0,0,0,.08);
    }
    .btn-primary{background:var(--main)!important; border:none}
    .btn-primary:hover{background:#092f4d!important}
    .btn-lg{font-size:1.05rem;padding:12px 16px;border-radius:12px}
    .slider{width:100%;height:200px;border-radius:12px;overflow:hidden;box-shadow:0 3px 8px rgba(0,0,0,.08);margin-top:20px}
    .slider img{width:100%;height:100%;object-fit:cover}

    /* Loan status */
    .loan-approve-wrap { text-align:center; }
    .loan-approve-box {
      display:inline-block;
      border-radius:8px;
      padding:8px 14px;
      font-weight:800;
      margin:14px auto 8px;
      color:#fff;
      white-space:nowrap;
    }
    .loan-approve-box.success { background:#0f5132; border:2px solid #0f5132; }
    .loan-approve-box.danger  { background:#842029; border:2px solid #842029; }
    .loan-instruction { text-align:center; font-size:.95rem; color:#374151; font-weight:600; }

    .icon-box{
      background:#fff; border-radius:12px; padding:10px; margin-top:16px;
      box-shadow:0 3px 8px rgba(0,0,0,.08);
      display:flex; justify-content:space-between; gap:6px;
    }
    .icon-item{flex:0 0 25%; text-align:center; font-size:.86rem; color:#334155}
    .icon-item i{font-size:1.35rem;margin-bottom:6px}
    .page-spacer{height:calc(var(--footer-h) + 12px);}
    .footer-nav{position:fixed;left:0;right:0;bottom:0;background:var(--main);color:#fff;z-index:1000;}
    .footer-inner{max-width:var(--app-max);margin:0 auto;display:flex;justify-content:space-around;align-items:center;padding:8px 0;}
    .footer-nav a{color:#fff;text-decoration:none;font-size:.9rem;text-align:center}
    .footer-nav i{display:block;font-size:1.2rem;margin-bottom:4px}
  </style>
</head>
<body>
<div class="app">

  <!-- Welcome -->
  <div class="welcome-box">
    <div class="welcome-left">
      <p>বিশ্ব ব্যাংক হতে আপনাকে স্বাগতম!</p>
      <h5><?= htmlspecialchars($name) ?></h5>
    </div>
    <!-- 🌎 World Bank logo inside soft circular badge -->
    <div class="logo-wrap">
      <img src="../img/2.png" class="globe-logo" alt="World Bank Logo">
    </div>
  </div>

  <!-- Summary -->
  <div class="row g-3 mt-2">
    <div class="col-6">
      <div class="summary-card">
        <i class="fas fa-money-bill-wave text-success"></i>
        <small>টাকার পরিমাণ</small>
        <h5 class="mb-0"><?= number_format($total_loan, 2) ?> ৳</h5>
      </div>
    </div>
    <div class="col-6">
      <div class="summary-card">
        <i class="fas fa-credit-card" style="color:#0b3d62"></i>
        <small>কিস্তির পরিমাণ</small>
        <h5 class="mb-0"><?= number_format($monthly, 2) ?> ৳</h5>
      </div>
    </div>
  </div>

  <!-- CTA -->
  <div class="mt-3">
    <a href="loan_request.php" class="btn btn-primary btn-lg w-100">উত্তোলন করুন / একাউন্ট দিন</a>
  </div>

  <!-- Slider -->
  <div id="carouselExample" class="carousel slide slider" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active"><img src="slider/IMG-WA0010.jpg" alt=""></div>
      <div class="carousel-item"><img src="slider/IMG-WA0011.jpg" alt=""></div>
      <div class="carousel-item"><img src="slider/IMG-WA0012.jpg" alt=""></div>
    </div>
  </div>

  <!-- CTA -->
  <div class="mt-3">
    <a href="personal_info.php" class="btn btn-primary btn-lg w-100">আপনার ব্যক্তিগত তথ্য জমা দিন</a>
  </div>

  <!-- Loan Status -->
  <?php if ($status === 'Success'): ?>
    <div class="loan-approve-wrap">
      <div class="loan-approve-box success">
        আপনার লোনটি অনুমোদন হয়েছে।
      </div>
    </div>
    <p class="loan-instruction">
      আপনি গ্রাহক সেবার সাথে যোগাযোগ করে আপনার লোন পরিমাণ টাকা উত্তোলন সম্পন্ন করে নিন।
    </p>
  <?php elseif ($status === 'Pending'): ?>
    <div class="loan-approve-wrap">
      <div class="loan-approve-box danger">
        আপনার আবেদন প্রক্রিয়াধীন রয়েছে।
      </div>
    </div>
  <?php elseif ($status === 'Process'): ?>
    <div class="loan-approve-wrap">
      <div class="loan-approve-box danger">
        আপনার আবেদন যাচাই করা হচ্ছে।
      </div>
    </div>
  <?php elseif ($status === 'Cancel'): ?>
    <div class="loan-approve-wrap">
      <div class="loan-approve-box danger">
        দুঃখিত, আবেদনটি বাতিল হয়েছে।
      </div>
    </div>
  <?php endif; ?>
 <br>
  <!-- Feature icons -->
  <div class="icon-box">
    <div class="icon-item"><i class="fas fa-lightbulb" style="color:#f59e0b"></i><div>পে বিল</div></div>
    <div class="icon-item"><i class="fas fa-shield-heart" style="color:#10b981"></i><div>মাইক্রোক্রেডিট</div></div>
    <div class="icon-item"><i class="fas fa-book" style="color:#f97316"></i><div>এডুকেশন ফি</div></div>
    <div class="icon-item"><a href="../help.php"><i class="fas fa-headset" style="color:#22c55e"></i><div>সাহায্য</div></a></div>
  </div>

  <div class="page-spacer"></div>
</div>

<!-- Footer -->
<div class="footer-nav">
  <div class="footer-inner">
    <a href="index.php"><i class="fas fa-home"></i>হোম</a>
    <a href="installments.php"><i class="fas fa-credit-card"></i>কিস্তি</a>
    <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // 🎲 Randomize spin: speed, direction, start angle + gentle hue shift for badge
  (function(){
    const logo = document.querySelector('.globe-logo');
    const wrap = document.querySelector('.logo-wrap');
    if(!logo || !wrap) return;

    const dur = (Math.random()*4 + 5.5).toFixed(2) + 's'; // 5.5s – 9.5s
    const dir = Math.random() > 0.5 ? 'normal' : 'reverse';
    const delay = (Math.random()*0.8).toFixed(2) + 's';
    const start = Math.floor(Math.random()*360);
    const hue = 200 + Math.floor(Math.random()*30) - 15; // 185–215 subtle variance

    logo.style.setProperty('--spin-duration', dur);
    logo.style.setProperty('--spin-direction', dir);
    logo.style.animationDelay = delay;
    logo.style.transform = `rotate(${start}deg)`;
    wrap.style.setProperty('--ring-hue', hue);
  })();
</script>
</body>
</html>
