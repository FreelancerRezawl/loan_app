<?php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name              = trim($_POST['name'] ?? '');
    $mobile            = trim($_POST['mobile'] ?? '');
    $nid               = trim($_POST['nid'] ?? '');
    $present_address   = trim($_POST['present_address'] ?? '');
    $permanent_address = trim($_POST['permanent_address'] ?? '');
    $job               = trim($_POST['job'] ?? '');
    $income            = trim($_POST['income'] ?? '');
    $family_members    = trim($_POST['family_members'] ?? '');
    $earning_members   = trim($_POST['earning_members'] ?? '');
    $loan_purpose      = trim($_POST['loan_purpose'] ?? '');  // ← simple input now
    $house_own         = trim($_POST['house_own'] ?? '');
    $car_own           = trim($_POST['car_own'] ?? '');

    $yn = ['হ্যাঁ', 'না'];
    if (!in_array($house_own, $yn)) $house_own = 'না';
    if (!in_array($car_own, $yn)) $car_own = 'না';

    try {
        $stmt = $pdo->prepare("SELECT 1 FROM personal_info WHERE user_id = ?");
        $stmt->execute([$user_id]);

        if ($stmt->rowCount() > 0) {
            $sql = "UPDATE personal_info
                    SET name = ?, mobile = ?, nid = ?, present_address = ?, permanent_address = ?, 
                        job = ?, income = ?, family_members = ?, earning_members = ?, 
                        loan_purpose = ?, house_own = ?, car_own = ?
                    WHERE user_id = ?";
            $pdo->prepare($sql)->execute([
                $name, $mobile, $nid, $present_address, $permanent_address,
                $job, $income, $family_members, $earning_members,
                $loan_purpose, $house_own, $car_own, $user_id
            ]);
        } else {
            $sql = "INSERT INTO personal_info
                    (user_id, name, mobile, nid, present_address, permanent_address, 
                     job, income, family_members, earning_members, loan_purpose, house_own, car_own)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $pdo->prepare($sql)->execute([
                $user_id, $name, $mobile, $nid, $present_address, $permanent_address,
                $job, $income, $family_members, $earning_members,
                $loan_purpose, $house_own, $car_own
            ]);
        }

        header("Location: nominee_info.php?msg=personal_saved");
        exit();
    } catch (Exception $e) {
        $message = "ত্রুটি: " . $e->getMessage();
    }
}

$stmt = $pdo->prepare("SELECT * FROM personal_info WHERE user_id = ?");
$stmt->execute([$user_id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>ব্যক্তিগত তথ্য</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root{
            --brand:#0b3d62; --bg:#f5f7fa; --text:#1f2a37; --muted:#6b7b93; --border:#d5deea;
            --app-max:420px; --footer-h:68px;
        }
        *{box-sizing:border-box}
        html,body{
            margin:0; padding:0; width:100%; min-height:100%;
            background:var(--bg); color:var(--text); overflow-x:hidden;
            font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,'SolaimanLipi',sans-serif;
        }
        .page{
            max-width:var(--app-max); margin:0 auto;
            padding:10px 10px calc(var(--footer-h) + env(safe-area-inset-bottom) + 12px);
        }

        .card-like{
            background:#fff; border:1px solid var(--border);
            border-radius:10px; padding:12px;
            box-shadow:0 4px 14px rgba(0,0,0,.04);
        }

        .stepper{ display:flex; justify-content:space-between; gap:6px; margin-bottom:10px; }
        .step{ width:33.33%; display:flex; flex-direction:column; align-items:center; gap:4px; }
        .dot{
            width:26px; height:26px; border-radius:50%; display:grid; place-items:center;
            font-weight:700; font-size:.85rem;
        }
        .dot.active{ background:var(--brand); color:#fff; }
        .dot.inactive{ background:#e9eef5; color:#44546a; }
        .sublabel{ font-size:.78rem; font-weight:700; color:#2d3b4b; }
        .muted{ color:var(--muted); }

        .title{
            font-weight:800; font-size:1rem; text-align:center;
            margin:4px 0 10px;
        }

        .form-label{
            color:#2f3f54; font-weight:600; font-size:.85rem;
            margin-bottom:4px;
        }
        .form-control, .form-select{
            height:40px; border-radius:10px; font-size:.95rem; padding:.4rem .65rem;
        }
        textarea.form-control{
            min-height:64px; height:auto; padding:.5rem .65rem; line-height:1.35;
        }
        .form-control:focus, .form-select:focus{
            border-color:var(--brand);
            box-shadow:0 0 0 3px rgba(11,61,98,.12);
        }
        .mb-3{ margin-bottom:.65rem !important; }
        .row.g-3{ --bs-gutter-x:.5rem; --bs-gutter-y:.5rem; }

        .btn-next{
            height:42px; border-radius:10px; background:var(--brand);
            font-weight:700; border:0; color:#fff; font-size:.95rem;
        }
        .btn-next:hover{ background:#092f4d; }

        .alert{ border-radius:10px; padding:.5rem .75rem; font-size:.9rem; }

        .footer-nav{
            position:fixed; left:50%; transform:translateX(-50%);
            bottom:0; width:100%; max-width:var(--app-max);
            background:var(--brand); color:#fff; z-index:999;
            padding:8px 6px; display:flex; justify-content:space-around; gap:6px;
            border-top-left-radius:10px; border-top-right-radius:10px;
            box-shadow:0 -6px 16px rgba(0,0,0,.2);
        }
        .footer-nav a{
            color:#fff; text-decoration:none; font-size:.82rem; line-height:1.1;
            display:flex; flex-direction:column; align-items:center; gap:2px; flex:1;
        }
        .footer-nav i{ font-size:1.05rem; }
    </style>
</head>
<body>
    <div class="page">
        <div class="stepper card-like">
            <div class="step">
                <div class="dot active">1</div>
                <div class="sublabel">আপনার তথ্য</div>
            </div>
            <div class="step">
                <div class="dot inactive">2</div>
                <div class="sublabel muted">নমিনির তথ্য</div>
            </div>
            <div class="step">
                <div class="dot inactive">3</div>
                <div class="sublabel muted">ছবি</div>
            </div>
        </div>

        <div class="card-like">
            <h5 class="title">আপনার ব্যক্তিগত তথ্য</h5>

            <?php if ($message): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <form method="POST" novalidate>
                <div class="mb-3">
                    <label class="form-label">আপনার নাম</label>
                    <input type="text" name="name" class="form-control"
                           value="<?= htmlspecialchars($data['name'] ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">মোবাইল নাম্বার</label>
                    <input type="tel" name="mobile" inputmode="numeric" class="form-control" placeholder="01XXXXXXXXX"
                           value="<?= htmlspecialchars($data['mobile'] ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">NID নম্বর</label>
                    <input type="text" name="nid" inputmode="numeric" class="form-control" placeholder="উদাহরণ: 1234567890"
                           value="<?= htmlspecialchars($data['nid'] ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">বর্তমান ঠিকানা</label>
                    <textarea name="present_address" class="form-control" rows="2"
                              placeholder="গ্রাম/পাড়া, ডাকঘর, উপজেলা, জেলা" required><?= htmlspecialchars($data['present_address'] ?? '') ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">স্থায়ী ঠিকানা</label>
                    <textarea name="permanent_address" class="form-control" rows="2"
                              placeholder="গ্রাম/পাড়া, ডাকঘর, উপজেলা, জেলা" required><?= htmlspecialchars($data['permanent_address'] ?? '') ?></textarea>
                </div>

                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label">পেশা</label>
                        <input type="text" name="job" class="form-control" placeholder="যেমন: ব্যবসা/চাকরি/কৃষি"
                               value="<?= htmlspecialchars($data['job'] ?? '') ?>" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">মাসিক আয় (টাকা)</label>
                        <input type="number" name="income" class="form-control" placeholder="যেমন: 20000"
                               value="<?= htmlspecialchars($data['income'] ?? '') ?>" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">পরিবারের সদস্য সংখ্যা</label>
                        <input type="number" name="family_members" class="form-control" placeholder="যেমন: 5"
                               value="<?= htmlspecialchars($data['family_members'] ?? '') ?>" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">উপার্জনকারী সদস্য সংখ্যা</label>
                        <input type="number" name="earning_members" class="form-control" placeholder="যেমন: 1"
                               value="<?= htmlspecialchars($data['earning_members'] ?? '') ?>" required>
                    </div>
                </div>

                <!-- 🔁 Replaced select with normal input -->
                <div class="mb-3 mt-1">
                    <label class="form-label">লোনের উদ্দেশ্য</label>
                    <input type="text" name="loan_purpose" class="form-control"
                           placeholder="যেমন: চিকিৎসা, শিক্ষা, ব্যবসা ইত্যাদি"
                           value="<?= htmlspecialchars($data['loan_purpose'] ?? '') ?>" required>
                </div>

                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label">আপনার কি বাড়ি আছে?</label>
                        <select name="house_own" class="form-select" required>
                            <?php
                            $ops = ['হ্যাঁ', 'না'];
                            $house = $data['house_own'] ?? '';
                            foreach ($ops as $o) {
                                $selected = ($house === $o) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($o, ENT_QUOTES) . "' $selected>$o</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">আপনার কি গাড়ি আছে?</label>
                        <select name="car_own" class="form-select" required>
                            <?php
                            $car = $data['car_own'] ?? '';
                            foreach ($ops as $o) {
                                $selected = ($car === $o) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($o, ENT_QUOTES) . "' $selected>$o</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-next w-100 mt-3">পরবর্তী</button>
            </form>
        </div>
    </div>

    <nav class="footer-nav">
        <a href="index.php"><i class="fas fa-home"></i>হোম</a>
        <a href="installments.php"><i class="fas fa-credit-card"></i>কিস্তি</a>
        <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
    </nav>

    <!-- No extra JS needed now (select removed) -->
</body>
</html>
