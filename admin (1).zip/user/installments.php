<?php
// user/installments.php - VISA Card + Last Approved Loan summary
include '../config.php';
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }

$user_id   = $_SESSION['user_id'];
$name      = $_SESSION['user_name'] ?? '';

/* Fake/static card face (you can replace from DB if you store card info) */
$card_number = '5247  ****  ****  9976';
$card_holder = strtoupper(htmlspecialchars($name));
$valid_till  = '01/12/2029';

/* Fetch LAST approved loan for this user */
$stmt = $pdo->prepare("
  SELECT amount, duration_months, total_amount, interest_rate, created_at
  FROM loan_requests
  WHERE user_id = ? AND status IN ('Success','Approved')
  ORDER BY created_at DESC, id DESC
  LIMIT 1
");
$stmt->execute([$user_id]);
$loan = $stmt->fetch(PDO::FETCH_ASSOC);

$hasApproved = (bool)$loan;
$amount      = $hasApproved ? (float)$loan['amount'] : 0;
$months      = $hasApproved ? (int)$loan['duration_months'] : 0;
$total       = $hasApproved ? (float)$loan['total_amount'] : 0;
$emi         = ($hasApproved && $months > 0) ? ($total / $months) : 0;
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
  <title>কিস্তি/কার্ড</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --bg:#0d1220; --text:#e8f1ff;
      --g1:#ff9966; --g2:#ff5e62; /* warm gradient like screenshot */
      --app-max:420px;
      --footer-h:86px;
    }
    *{box-sizing:border-box}
    html, body{
      margin:0; padding:0; width:100%; min-height:100%;
      overflow-x:hidden; background:#f4f6fb; color:#111827;
      font-family: system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;
    }
    body{
      display:flex; flex-direction:column; align-items:center;
      padding:18px 12px calc(var(--footer-h) + env(safe-area-inset-bottom) + 16px);
    }
    .wrap{ width:100%; max-width:var(--app-max); display:grid; place-items:center; gap:14px; }

    /* Card */
    .card-visa{
      position:relative; width:100%; max-width:380px; height:210px; border-radius:18px; overflow:hidden;
      background: linear-gradient(135deg, var(--g1), var(--g2));
      box-shadow: 0 16px 38px rgba(0,0,0,.22);
      color:#fff;
    }
    .card-body{ position:relative; height:100%; padding:18px; display:flex; flex-direction:column; }
    .top{ display:flex; align-items:center; justify-content:space-between; }
    .chip{
      width:54px; height:40px; border-radius:10px; display:grid; place-items:center; font-size:1.15rem;
      background: linear-gradient(145deg, #ffd89b, #f7b733); color:#1a2537;
      box-shadow: inset 0 1px 0 rgba(255,255,255,.6);
    }
    .brand{ font-weight:900; letter-spacing:1px; }
    .contactless{ position:absolute; top:22px; left:88px; opacity:.9; transform:rotate(90deg); }
    .number{ margin-top:26px; font-size:1.5rem; letter-spacing:3px; font-weight:700; text-shadow:0 1px 3px rgba(0,0,0,.35); }

    /* Avoid Bootstrap .row negative margins ⇒ use .card-row */
    .card-row{ margin-top:auto; display:flex; align-items:flex-end; justify-content:space-between; }
    .label{ display:block; font-size:.72rem; letter-spacing:1px; opacity:.9; }
    .holder strong, .expiry strong{ font-size:1rem; letter-spacing:.4px; }
    .visa-water{ position:absolute; right:16px; bottom:16px; font-weight:900; font-size:2rem; letter-spacing:1px; opacity:.15; }

    /* Loan summary bar */
    .summary{
      width:100%; max-width:380px; background:#ffffff; border-radius:12px;
      box-shadow: 0 6px 16px rgba(0,0,0,.08); padding:12px 14px; display:flex; justify-content:space-between; gap:10px;
    }
    .sum-left, .sum-right{ font-size:1rem; font-weight:700; color:#111827; }
    .sum-left::before{ content:'৳'; margin-right:2px; }
    .sum-right small{ font-weight:600; color:#6b7280; margin-left:6px; }

    /* Empty state */
    .empty{
      width:100%; max-width:380px; background:#fff; border-radius:12px; padding:16px; text-align:center;
      color:#374151; box-shadow:0 6px 16px rgba(0,0,0,.06);
    }

    /* Footer (centered, no overflow) */
    .footer-nav{
      position:fixed; left:0; right:0; bottom:0; width:100%; max-width:var(--app-max); margin:0 auto;
      background:#0d3a58; color:#fff; display:flex; justify-content:space-around; text-align:center;
      padding:10px 6px; box-shadow:0 -6px 16px rgba(0,0,0,.25); z-index:10; border-radius:12px 12px 0 0;
    }
    .footer-nav a{ color:#fff; font-size:.92rem; text-decoration:none; flex:1; }
    .footer-nav i{ font-size:1.35rem; display:block; margin-bottom:4px; }
    .footer-nav a.active i,.footer-nav a.active{ filter:brightness(1.1); font-weight:700; }
  </style>
</head>
<body>
  <div class="wrap">

    <!-- Pretty card -->
    <div class="card-visa" aria-label="VISA Card">
      <div class="card-body">
        <div class="top">
          <div class="chip"><i class="fa-solid fa-microchip"></i></div>
          <div class="brand">VISA</div>
        </div>
        <i class="fa-solid fa-wifi contactless"></i>

        <div class="number"><?= htmlspecialchars($card_number) ?></div>

        <div class="card-row">
          <div class="holder">
            <span class="label">CARD HOLDER</span>
            <strong><?= $card_holder ?></strong>
          </div>
          <div class="expiry">
            <span class="label">VALID TILL</span>
            <strong><?= htmlspecialchars($valid_till) ?></strong>
          </div>
        </div>

        <div class="visa-water">VISA</div>
      </div>
    </div>

    <?php if ($hasApproved): ?>
      <!-- Loan summary: Left = principal (amount), Right = EMI / months -->
      <div class="summary">
        <div class="sum-left"><?= number_format($amount, 0) ?></div>
        <div class="sum-right">
          <?= number_format($emi, 2) ?> <small>/ <?= $months ?> মাস</small>
        </div>
      </div>
    <?php else: ?>
      <!-- Empty state if no approved loans -->
      <div class="empty">
        বর্তমানে কোনো অনুমোদিত ঋণ নেই। নতুন করে আবেদন করতে
        <a href="loan_request.php" class="link-primary" style="text-decoration:none;">ঋণ আবেদন</a> পেজে যান।
      </div>
    <?php endif; ?>

  </div>

  <!-- Footer -->
  <div class="footer-nav">
    <a href="index.php"><i class="fas fa-home"></i>হোম</a>
    <a href="installments.php" class="active"><i class="fas fa-credit-card"></i>কিস্তি/কার্ড</a>
    <a href="profile.php"><i class="fas fa-user"></i>প্রোফাইল</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
