<?php
// user/transfer_method.php
include '../config.php';
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['loan_amount']) || !isset($_SESSION['loan_months'])) {
  header("Location: rin.php"); exit();
}

$user_id = $_SESSION['user_id'];
$amount  = (int)$_SESSION['loan_amount'];
$months  = (int)$_SESSION['loan_months'];
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $method        = $_POST['method'] ?? '';
  $wallet_number = trim($_POST['wallet_number'] ?? '');
  $bank_name     = trim($_POST['bank_name'] ?? '');
  $branch_name   = trim($_POST['branch_name'] ?? '');
  $holder_name   = trim($_POST['holder_name'] ?? '');
  $bank_account  = trim($_POST['bank_account'] ?? '');
  $routing_no    = trim($_POST['routing_no'] ?? '');

  if ($method==='') {
    $error = "পদ্ধতি নির্বাচন করুন।";
  } else {
    if ($method==='Bank') {
      if ($bank_name==='' || $branch_name==='' || $holder_name==='' || $bank_account==='') {
        $error = "ব্যাংকের প্রয়োজনীয় তথ্য পূরণ করুন।";
      }
    } else {
      if ($wallet_number==='') {
        $error = "ওয়ালেট নম্বর দিন।";
      }
    }
  }

  if (!$error) {
    $interest_rate = 0.2; // percent
    $total_amount  = $amount * (1 + $interest_rate/100);

    $account_for_store = $wallet_number;
    if ($method==='Bank') {
      $account_for_store = "Bank: {$bank_name} | Branch: {$branch_name} | Holder: {$holder_name} | Ac: {$bank_account}"
                         . ($routing_no ? " | Routing: {$routing_no}" : "");
    }

    try{
      $stmt = $pdo->prepare("INSERT INTO loan_requests
        (user_id, amount, duration_months, interest_rate, total_amount, method, account_number, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')");
      $stmt->execute([$user_id, $amount, $months, $interest_rate, $total_amount, $method, $account_for_store]);

      unset($_SESSION['loan_amount'], $_SESSION['loan_months']);

      header("Location: index.php?msg=applied");
      exit();
    }catch(Exception $e){
      $error = "ডাটাবেজ ত্রুটি: ".$e->getMessage();
    }
  }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
  <title>পেমেন্ট পদ্ধতি</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    :root{
      --brand:#0b3d62;
      --brand-dark:#092f4d;
      --border:#d5e1f0;
      --text:#22313f;
      --muted:#6b7b93;
      --ring:0 0 0 3px rgba(11,61,98,.14);
      --app-max:420px;
      --footer-h:68px;
    }
    *{box-sizing:border-box}
    html,body{
      margin:0; padding:0; width:100%; min-height:100%;
      overflow-x:hidden; background:#f7f9fc; color:var(--text);
      font-family:'SolaimanLipi',system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    }
    .app{
      max-width:var(--app-max);
      margin:0 auto;
      padding:10px 10px calc(var(--footer-h) + env(safe-area-inset-bottom) + 12px);
    }

    .topbar{
      background:var(--brand); color:#fff; padding:10px 12px; border-radius:10px;
      display:flex; align-items:center; gap:8px; margin-bottom:12px;
    }
    .topbar a{ color:#fff; text-decoration:none; font-weight:800; }
    .topbar span{ font-weight:800; }

    .section-card{
      background:#fff; border-radius:12px; box-shadow:0 1px 6px rgba(0,0,0,.06);
      border:1px solid var(--border); padding:12px; margin-bottom:12px;
    }
    .form-label{ font-weight:700; color:var(--text); margin-bottom:6px; font-size:.9rem; }
    .form-control,.form-select{
      border-radius:10px; height:40px; font-size:.95rem; padding:.4rem .65rem;
    }
    .form-control:focus,.form-select:focus{ border-color:var(--brand); box-shadow:var(--ring); }

    .btn-success{
      display:block; width:100%; height:42px; font-weight:800; border-radius:12px;
      background:var(--brand); border:none; color:#fff; font-size:.95rem; margin-top:6px;
    }
    .btn-success:hover{ background:var(--brand-dark); }
    .btn-success:focus{ outline:none; box-shadow:var(--ring); }

    .alert{ border-radius:10px; margin-bottom:12px; }

    /* Footer centered within app width */
    .footer-nav{
      position:fixed; left:50%; transform:translateX(-50%); bottom:0;
      width:100%; max-width:var(--app-max);
      background:var(--brand); color:#fff; z-index:1000;
      display:flex; justify-content:space-around; align-items:center;
      padding:8px 6px; border-radius:12px 12px 0 0; box-shadow:0 -6px 16px rgba(0,0,0,.25);
    }
    .footer-nav a{ flex:1; color:#fff; text-decoration:none; text-align:center; font-size:.85rem; }
    .footer-nav i{ font-size:1.2rem; display:block; margin-bottom:4px; }
    .footer-nav span{ font-size:.82rem; }
    .footer-nav a.active i,.footer-nav a.active span{ filter:brightness(1.1); }

    .hint{ font-size:.78rem; color:var(--muted); margin-top:4px; }
  </style>
</head>
<body>
  <div class="app">

    <div class="topbar">
      <a href="rin.php"><i class="fa-solid fa-chevron-left"></i></a>
      <span>পেমেন্ট পদ্ধতি</span>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" id="methodForm">
      <div class="section-card">
        <div class="mb-3">
          <label class="form-label">পদ্ধতি</label>
          <select name="method" id="methodSelect" class="form-select" required>
            <option value="" selected disabled>নির্বাচন করুন</option>
            <option value="bKash">bKash</option>
            <option value="Nagad">Nagad</option>
            <option value="Rocket">Rocket</option>
            <option value="Bank">ব্যাংক</option>
          </select>
        </div>

        <!-- Wallet -->
        <div class="mb-0" id="walletRow">
          <label class="form-label">মোবাইল ওয়ালেট নম্বর(ইংরেজী তে )</label>
          <input type="tel" name="wallet_number" class="form-control"
                 inputmode="numeric" pattern="[0-9]{10,14}"
                 placeholder="01XXXXXXXXX" aria-describedby="walletHelp">
        </div>

        <!-- Bank -->
        <div id="bankExtras" style="display:none">
          <div class="mt-2">
            <label class="form-label">ব্যাংকের নাম</label>
            <input type="text" name="bank_name" class="form-control" placeholder="যেমন: Sonali Bank PLC">
          </div>
          <div class="mt-2">
            <label class="form-label">শাখার নাম</label>
            <input type="text" name="branch_name" class="form-control" placeholder="যেমন: আগারগাঁও">
          </div>
          <div class="mt-2">
            <label class="form-label">একাউন্ট হোল্ডারের নাম</label>
            <input type="text" name="holder_name" class="form-control" placeholder="পূর্ণ নাম">
          </div>
          <div class="mt-2">
            <label class="form-label">ব্যাংক একাউন্ট নম্বর</label>
            <input type="text" name="bank_account" class="form-control" placeholder="একাউন্ট নম্বর">
          </div>
          <div class="mt-2">
            <label class="form-label">রাউটিং/BRSC কোড (ঐচ্ছিক)</label>
            <input type="text" name="routing_no" class="form-control" placeholder="যদি জানা থাকে">
          </div>
        </div>
      </div>

      <button type="submit" class="btn-success">সংরক্ষণ করুন</button>
    </form>
  </div>

  <!-- Footer -->
  <nav class="footer-nav">
    <a href="index.php"><i class="fas fa-home"></i><span>হোম</span></a>
    <a href="installments.php"><i class="fas fa-credit-card"></i><span>কিস্তি</span></a>
    <a href="profile.php" class="active"><i class="fas fa-user"></i><span>প্রোফাইল</span></a>
  </nav>

  <script>
    // Toggle wallet/bank fields
    const methodSelect=document.getElementById('methodSelect');
    const bankExtras=document.getElementById('bankExtras');
    const walletRow=document.getElementById('walletRow');

    methodSelect.addEventListener('change', ()=>{
      if(methodSelect.value==='Bank'){
        bankExtras.style.display='block';
        walletRow.style.display='none';
      }else{
        bankExtras.style.display='none';
        walletRow.style.display='block';
      }
    });

    // Convert Bangla digits → English for wallet before submit
    (function(){
      const map = {'০':'0','১':'1','২':'2','৩':'3','৪':'4','৫':'5','৬':'6','৭':'7','৮':'8','৯':'9'};
      function toEnglishDigits(s){
        return (s || '').replace(/[০-৯]/g, d => map[d] || d).replace(/[^0-9]/g,'');
      }
      const form = document.getElementById('methodForm');
      form.addEventListener('submit', function(){
        const wallet = form.querySelector('input[name="wallet_number"]');
        if (wallet) wallet.value = toEnglishDigits(wallet.value);
      });
    })();
  </script>
</body>
</html>
