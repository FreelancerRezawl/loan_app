<?php
include 'config.php';
session_start();
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mobile   = trim($_POST['mobile'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($mobile === '' || $password === '') {
        $error = "সব ফিল্ড পূরণ করুন।";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE mobile = ?");
        $stmt->execute([$mobile]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            header("Location: user/index.php");
            exit;
        } else {
            $error = "মোবাইল বা পাসওয়ার্ড ভুল।";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>লগইন</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    :root{
      --brand:#0967ac;    /* banner background */
      --btn:#049dc3;      /* button color */
      --btn-hover:#0386a8;
      --text:#0f172a;
      --ring: 0 0 0 3px rgba(4,157,195,.18);
    }

    body{
      margin:0;
      background:#fff;
      font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,'SolaimanLipi',sans-serif;
      color:var(--text);
      display:flex;
      flex-direction:column;
      align-items:center;
    }

    /* Banner */
    .hero{
      width:100%;
      background:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      padding:14px 0;
    }
    .hero__img{
      width:200px;   /* smaller logo */
      height:auto;
    }

    /* Container */
    .wrap{
      width:100%;
      max-width:420px;  /* compact size for PC */
      padding:20px;
      margin:30px auto;
    }

    /* Input fields */
    .pill{
      height:42px;
      border:2px solid var(--brand);
      border-radius:999px;
      padding:6px 14px;
      font-size:14px;
      width:100%;
      transition:border-color .15s, box-shadow .15s;
    }
    .pill:focus{box-shadow:var(--ring); border-color:var(--btn)}

    .field{margin:14px 0}

    /* Buttons */
    .btn-pill{
      width:100%;
      height:44px;
      border:none;
      border-radius:999px;
      background:var(--btn);
      color:#fff !important;
      font-weight:600;
      font-size:15px;
      display:flex;
      align-items:center;
      justify-content:center;
      transition:background .15s, transform .05s;
      text-decoration:none;   /* remove underline for links */
    }
    .btn-pill:hover{background:var(--btn-hover); color:#fff;}
    .btn-pill:active{transform:translateY(1px)}
    .btn-pill:focus-visible{box-shadow:var(--ring); outline:0}

    .btn-spacer{margin-top:18px}

    .alert{
      border-radius:10px;
      padding:8px 12px;
      font-size:14px;
    }
  </style>
</head>
<body>

  <!-- Banner -->
  <div class="hero">
    <img src="img/wb-top.png" alt="Logo" class="hero__img">
  </div>

  <!-- Form -->
  <div class="wrap">
    <?php if ($error): ?>
      <div class="alert alert-danger text-center mb-3"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="form-box">
      <form method="POST" novalidate>
        <div class="field">
          <input
            type="tel"
            name="mobile"
            class="pill"
            placeholder="মোবাইল নম্বর দিন (ইংরেজি)"
            required
          >
        </div>
        <div class="field">
          <input
            type="password"
            name="password"
            class="pill"
            placeholder="পাসওয়ার্ড দিন (ইংরেজি)"
            required
          >
        </div>

        <div class="btn-spacer">
          <button type="submit" class="btn-pill">লগইন</button>
        </div>

        <div class="btn-spacer">
          <a href="register.php" class="btn-pill" role="button">নতুন একাউন্ট তৈরি করুন</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>
