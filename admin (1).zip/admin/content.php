<?php include 'header.php'; include 'config.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (isset($_POST['update'])) {
    $key = trim($_POST['key']);
    $value = trim($_POST['value']);
    // Assuming a content table or settings table exists
    // For now, just a placeholder
    // $pdo->prepare("UPDATE settings SET value=? WHERE key=?")->execute([$value, $key]);
  }
}

// Placeholder content
$content = [
  'site_title' => 'WBLB Admin',
  'footer_text' => '© 2025 WBLB. All rights reserved.',
  'contact_email' => 'admin@yourloan.com'
];
?>
<div class="panel">
  <h3 class="h">কনটেন্ট ম্যানেজমেন্ট</h3>
  <p>এখানে সাইটের কনটেন্ট আপডেট করুন।</p>

  <form method="post" class="form-row">
    <input class="input" name="key" placeholder="কী (e.g. site_title)" required>
    <input class="input" name="value" placeholder="ভ্যালু" required>
    <button class="btn primary" name="update">আপডেট</button>
  </form>

  <table class="table">
    <thead><tr><th>কী</th><th>ভ্যালু</th></tr></thead>
    <tbody>
      <?php foreach($content as $k => $v): ?>
      <tr>
        <td><?= htmlspecialchars($k) ?></td>
        <td><?= htmlspecialchars($v) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include 'footer.php'; ?>
