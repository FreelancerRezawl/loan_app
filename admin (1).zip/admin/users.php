<?php
include 'header.php';
include 'config.php';

// Handle user creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    $name = trim($_POST['name'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $password = $_POST['password'] ?? '';
    $bank_method = trim($_POST['bank_method'] ?? '');
    $bank_account = trim($_POST['bank_account'] ?? '');

    if (!empty($name) && !empty($mobile) && !empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, mobile, password, bank_method, bank_account) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $mobile, $hashed_password, $bank_method, $bank_account]);
            $success_message = "User created successfully!";
        } catch (PDOException $e) {
            $error_message = "Error creating user: " . $e->getMessage();
        }
    } else {
        $error_message = "Please fill in all required fields.";
    }
}

// Handle user update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $user_id = (int)$_POST['user_id'];
    $name = trim($_POST['edit_name'] ?? '');
    $mobile = trim($_POST['edit_mobile'] ?? '');
    $bank_method = trim($_POST['edit_bank_method'] ?? '');
    $bank_account = trim($_POST['edit_bank_account'] ?? '');

    if ($user_id > 0 && !empty($name) && !empty($mobile)) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET name=?, mobile=?, bank_method=?, bank_account=? WHERE id=?");
            $stmt->execute([$name, $mobile, $bank_method, $bank_account, $user_id]);
            $success_message = "User updated successfully!";
        } catch (PDOException $e) {
            $error_message = "Error updating user: " . $e->getMessage();
        }
    } else {
        $error_message = "Please fill in all required fields.";
    }
}

/**
 * Users + Personal Info + Nominee + Documents + Latest Loan (per user)
 * Latest loan নেওয়ার জন্য MAX(id) সাবকোয়েরি ব্যবহার করা হয়েছে।
 */
$sql = "
SELECT
  u.id, u.name, u.mobile, u.bank_method, u.bank_account, u.bank_name, u.branch_name, u.account_holder, u.created_at,

  pi.nid, pi.present_address, pi.permanent_address, pi.job, pi.income, pi.family_members, pi.earning_members, pi.loan_purpose,

  ni.name  AS nominee_name,
  ni.mobile AS nominee_mobile,
  ni.relationship AS nominee_relationship,

  d.user_photo, d.nid_front, d.nid_back, d.signature, d.nominee_photo,

  lr.status       AS last_status,
  lr.amount       AS last_amount,
  lr.duration_months AS last_duration,
  lr.interest_rate AS last_interest,
  lr.total_amount AS last_total,
  lr.method       AS last_method,
  lr.account_number AS last_account,
  lr.created_at   AS last_loan_time

FROM users u
LEFT JOIN personal_info pi   ON pi.user_id = u.id
LEFT JOIN nominee_info  ni   ON ni.user_id = u.id
LEFT JOIN documents     d    ON d.user_id  = u.id
LEFT JOIN (
  SELECT t.*
  FROM loan_requests t
  JOIN (
    SELECT user_id, MAX(id) AS max_id
    FROM loan_requests
    GROUP BY user_id
  ) m ON m.user_id = t.user_id AND m.max_id = t.id
) lr ON lr.user_id = u.id
ORDER BY u.id DESC
LIMIT 500
";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

function thumb($path) {
  if (!$path) return '';
  return '<a class="btn ghost" href="../uploads/'.htmlspecialchars($path).'" target="_blank">দেখুন</a>';
}
?>
<div class="panel">
  <h3 class="h">ইউজার তথ্য</h3>

  <!-- Success/Error Messages -->
  <?php if (isset($success_message)): ?>
    <div style="background:#d4edda; color:#155724; padding:10px; border-radius:5px; margin-bottom:15px;">
      <?= htmlspecialchars($success_message) ?>
    </div>
  <?php endif; ?>
  <?php if (isset($error_message)): ?>
    <div style="background:#f8d7da; color:#721c24; padding:10px; border-radius:5px; margin-bottom:15px;">
      <?= htmlspecialchars($error_message) ?>
    </div>
  <?php endif; ?>

  <!-- Create User Form -->
  <div style="margin-bottom:20px; padding:15px; border-radius:8px;">
    <h4 style="margin:0 0 10px 0;">নতুন ইউজার যোগ করুন</h4>
    <form method="post" class="form-row">
      <input class="input" type="text" name="name" placeholder="নাম" required style="max-width:200px;">
      <input class="input" type="text" name="mobile" placeholder="মোবাইল" required style="max-width:200px;">
      <input class="input" type="password" name="password" placeholder="পাসওয়ার্ড" required style="max-width:200px;">
      <select name="bank_method" class="select" style="max-width:150px;">
        <option value="">ব্যাংক মেথড</option>
        <option value="bKash">bKash</option>
        <option value="Nagad">Nagad</option>
        <option value="Rocket">Rocket</option>
        <option value="Bank">Bank</option>
      </select>
      <input class="input" type="text" name="bank_account" placeholder="একাউন্ট নাম্বার" style="max-width:200px;">
      <button class="btn primary" name="create_user" type="submit">ইউজার যোগ করুন</button>
    </form>
  </div>

  <table class="table">
    <thead>
      <tr>
        <th>ইউজার</th>
        <th>পার্সোনাল</th>
        <th>এড্রেস</th>
        <th>নমিনি</th>
        <th>ডকুমেন্ট</th>
        <th>সর্বশেষ লোন</th>
        <th>ব্যাংক/পেমেন্ট</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <!-- User -->
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <?php if(!empty($r['user_photo'])): ?>
                <img src="../uploads/<?= htmlspecialchars($r['user_photo']) ?>" style="width:44px;height:44px;border-radius:50%;object-fit:cover">
              <?php else: ?>
                <div style="width:44px;height:44px;border-radius:50%;background:#17365f;display:grid;place-items:center;color:#dfe8f7;font-weight:800">
                  <?= strtoupper(mb_substr($r['name']??'U',0,1,'UTF-8')) ?>
                </div>
              <?php endif; ?>
              <div>
                <div style="font-weight:800"><?= htmlspecialchars($r['name'] ?? '—') ?></div>
                <small><?= htmlspecialchars($r['mobile'] ?? '—') ?></small><br>
                <small>ID #<?= (int)$r['id'] ?> • <?= htmlspecialchars($r['created_at']) ?></small>
              </div>
            </div>
          </td>

          <!-- Personal -->
          <td>
            NID: <b><?= htmlspecialchars($r['nid'] ?? '—') ?></b><br>
            পেশা: <?= htmlspecialchars($r['job'] ?? '—') ?><br>
            আয়: <?= $r['income']!==null ? number_format($r['income']).' ৳' : '—' ?><br>
            পরিবার: <?= htmlspecialchars($r['family_members'] ?? '—') ?>,
            উপার্জনকারী: <?= htmlspecialchars($r['earning_members'] ?? '—') ?><br>
            উদ্দেশ্য: <?= htmlspecialchars($r['loan_purpose'] ?? '—') ?>
          </td>

          <!-- Address -->
          <td style="max-width:280px">
            বর্তমান: <?= htmlspecialchars($r['present_address'] ?? '—') ?><br>
            স্থায়ী: <?= htmlspecialchars($r['permanent_address'] ?? '—') ?>
          </td>

          <!-- Nominee -->
          <td>
            নাম: <?= htmlspecialchars($r['nominee_name'] ?? '—') ?><br>
            মোবাইল: <?= htmlspecialchars($r['nominee_mobile'] ?? '—') ?><br>
            সম্পর্ক: <?= htmlspecialchars($r['nominee_relationship'] ?? '—') ?>
          </td>

          <!-- Documents -->
          <td>
            ইউজার ছবি: <?= $r['user_photo'] ? thumb($r['user_photo']) : '—' ?><br>
            NID ফ্রন্ট: <?= $r['nid_front'] ? thumb($r['nid_front']) : '—' ?><br>
            NID ব্যাক: <?= $r['nid_back'] ? thumb($r['nid_back']) : '—' ?><br>
            স্বাক্ষর: <?= $r['signature'] ? thumb($r['signature']) : '—' ?><br>
            নমিনি ছবি: <?= $r['nominee_photo'] ? thumb($r['nominee_photo']) : '—' ?>
          </td>

          <!-- Latest Loan -->
          <td>
            <?php if($r['last_amount']!==null): ?>
              পরিমাণ: <b><?= number_format($r['last_amount']) ?> ৳</b><br>
              মেয়াদ: <?= (int)$r['last_duration'] ?> ম, সুদ: <?= (float)$r['last_interest'] ?>%<br>
              মোট: <?= number_format($r['last_total']) ?> ৳<br>
              মেথড: <?= htmlspecialchars($r['last_method'] ?? '—') ?><br>
              একাউন্ট: <?= htmlspecialchars($r['last_account'] ?? '—') ?><br>
              স্ট্যাটাস:
              <?php
                $cls = ['Pending'=>'badge pending','Process'=>'badge process','Success'=>'badge success','Rejected'=>'badge reject'][$r['last_status']] ?? 'badge';
              ?>
              <span class="<?= $cls ?>"><?= htmlspecialchars($r['last_status']) ?></span><br>
              <small><?= htmlspecialchars($r['last_loan_time']) ?></small>
            <?php else: ?>
              —
            <?php endif; ?>
          </td>

          <!-- Bank -->
          <td>
            মেথড: <?= htmlspecialchars($r['bank_method'] ?? '—') ?><br>
            একাউন্ট: <?= htmlspecialchars($r['bank_account'] ?? '—') ?><br>
            ব্যাংক: <?= htmlspecialchars($r['bank_name'] ?? '—') ?><br>
            ব্রাঞ্চ: <?= htmlspecialchars($r['branch_name'] ?? '—') ?><br>
            একাউন্ট হোল্ডার: <?= htmlspecialchars($r['account_holder'] ?? '—') ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include 'footer.php'; ?>
