<?php
// admin/auth.php
include 'config.php';
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}
$admin_id = $_SESSION['admin_id'];
$admin_email = $_SESSION['admin_email'] ?? '';
