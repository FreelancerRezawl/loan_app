<?php include 'header.php'; include 'config.php';
$u = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$r = $pdo->query("SELECT COUNT(*) FROM loan_requests")->fetchColumn();
$p = $pdo->query("SELECT COUNT(*) FROM loan_requests WHERE status='Pending'")->fetchColumn();
$s = $pdo->query("SELECT COUNT(*) FROM loan_requests WHERE status='Success'")->fetchColumn();
?>
<div class="panel">
  <h3 class="h">ড্যাশবোর্ড</h3>
  <div class="form-row">
    <div class="col panel"><div class="h">ইউজার</div><div style="font-size:28px;font-weight:800;"><?= $u ?></div></div>
    <div class="col panel"><div class="h">রিকোয়েস্ট</div><div style="font-size:28px;font-weight:800;"><?= $r ?></div></div>
    <div class="col panel"><div class="h">পেন্ডিং</div><div style="font-size:28px;font-weight:800;"><?= $p ?></div></div>
    <div class="col panel"><div class="h">সাকসেস</div><div style="font-size:28px;font-weight:800;"><?= $s ?></div></div>
  </div>
</div>
<?php include 'footer.php'; ?>
