<?php include 'header.php'; include 'config.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (isset($_POST['create'])) {
    $amt = max(0, (int)$_POST['amount']);
    $dur = max(1, (int)$_POST['duration_months']);
    $rate = max(0, (float)$_POST['interest_rate']);
    if ($amt > 0 && $dur > 0 && $rate >= 0) {
      $pdo->prepare("INSERT INTO loan_settings(amount,duration_months,interest_rate) VALUES (?,?,?)")
          ->execute([$amt,$dur,$rate]);
    }
  }
  if (isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $amt = max(0, (int)$_POST['amount']);
    $dur = max(1, (int)$_POST['duration_months']);
    $rate = max(0, (float)$_POST['interest_rate']);
    if ($id > 0 && $amt > 0 && $dur > 0 && $rate >= 0) {
      $pdo->prepare("UPDATE loan_settings SET amount=?, duration_months=?, interest_rate=? WHERE id=?")
          ->execute([$amt,$dur,$rate,$id]);
    }
  }
  if (isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    if ($id > 0) {
      $pdo->prepare("DELETE FROM loan_settings WHERE id=?")->execute([$id]);
    }
  }
}

$rows = $pdo->query("SELECT * FROM loan_settings ORDER BY amount ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="panel">
  <h3 class="h">লোন প্ল্যান</h3>

  <form method="post" class="form-row">
    <input class="input" type="number" name="amount" placeholder="পরিমাণ (৳)" required>
    <input class="input" type="number" name="duration_months" placeholder="মেয়াদ (মাস)" required>
    <input class="input" step="0.01" type="number" name="interest_rate" placeholder="সুদ (%)" required>
    <button class="btn primary" name="create">যোগ করুন</button>
  </form>

  <table class="table">
    <thead><tr><th>পরিমাণ</th><th>মেয়াদ</th><th>সুদ</th><th>অ্যাকশন</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?= number_format($r['amount']) ?> ৳</td>
          <td><?= $r['duration_months'] ?> মাস</td>
          <td><?= $r['interest_rate'] ?>%</td>
          <td>
            <form method="post" class="form-row" style="align-items:center">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <input class="input" type="number" name="amount" value="<?= $r['amount'] ?>" style="max-width:120px">
              <input class="input" type="number" name="duration_months" value="<?= $r['duration_months'] ?>" style="max-width:120px">
              <input class="input" step="0.01" type="number" name="interest_rate" value="<?= $r['interest_rate'] ?>" style="max-width:120px">
              <button class="btn ok" name="update">আপডেট</button>
              <button class="btn danger" name="delete" onclick="return confirm('ডিলিট করবেন?')">ডিলিট</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include 'footer.php'; ?>
