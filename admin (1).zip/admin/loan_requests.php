<?php include 'header.php'; include 'config.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $id = (int)$_POST['id'];
  $ui_status = trim($_POST['status'] ?? '');
  $reason = trim($_POST['reason'] ?? '');

  // UI <-> DB mapping
  $ui_to_db = ['Rejected' => 'Fail'];
  $db_to_ui = ['Fail' => 'Rejected'];

  // Convert UI value to DB value if needed
  $status = $ui_to_db[$ui_status] ?? $ui_status;

  // Validate against DB-allowed statuses
  $allowed_db_statuses = ['Pending', 'Process', 'Success', 'Fail'];
  if (!in_array($status, $allowed_db_statuses, true)) {
    $status = 'Pending';
  }

  // Sanitize reason for safe output later
  $reason = htmlspecialchars($reason, ENT_QUOTES, 'UTF-8');

  $stmt = $pdo->prepare("UPDATE loan_requests SET status=?, reason=?, updated_at=NOW() WHERE id=?");
  $stmt->execute([$status, $reason, $id]);
}

// Fetch rows
$rows = $pdo->query("
  SELECT lr.*, u.name, u.mobile, ls.amount AS plan_amount
  FROM loan_requests lr
  JOIN users u ON u.id = lr.user_id
  LEFT JOIN loan_settings ls ON ls.id = lr.loan_id
  ORDER BY lr.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Helper: get UI status (display string)
function display_status($db_status) {
  return $db_status === 'Fail' ? 'Rejected' : $db_status;
}
?>
<div class="panel">
  <h3 class="h">লোন রিকোয়েস্ট</h3>
  <table class="table">
    <thead>
      <tr>
        <th>ইউজার</th>
        <th>প্ল্যান</th>
        <th>টোটাল</th>
        <th>মেথড</th>
        <th>স্ট্যাটাস</th>
        <th>অ্যাকশন</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <?php
        // For badge class & select value handling
        $dbStatus   = $r['status'];
        $uiStatus   = display_status($dbStatus); // 'Rejected' if 'Fail', else same
        $badgeClassMap = [
          'Pending'  => 'badge pending',
          'Process'  => 'badge process',
          'Success'  => 'badge success',
          'Fail'     => 'badge reject', // map Fail -> reject style
        ];
        $cls = $badgeClassMap[$dbStatus] ?? 'badge';
      ?>
      <tr>
        <td><?= htmlspecialchars($r['name']) ?><br><small><?= htmlspecialchars($r['mobile']) ?></small></td>
        <td><?= number_format($r['amount']) ?> ৳ / <?= (int)$r['duration_months'] ?> ম / <?= (float)$r['interest_rate'] ?>%</td>
        <td><?= number_format($r['total_amount']) ?> ৳</td>
        <td><?= htmlspecialchars($r['method']) ?><br><small><?= htmlspecialchars($r['account_number']) ?></small></td>
        <td>
          <span class="<?= $cls ?>"><?= $uiStatus ?></span>
          <?php if(!empty($r['reason'])): ?>
            <div style="color:#ffb0b0; font-size:.85rem; margin-top:4px"><?= htmlspecialchars($r['reason']) ?></div>
          <?php endif; ?>
        </td>
        <td>
          <form method="post" class="form-row" style="align-items:center">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <select name="status" class="select" style="max-width:140px">
              <?php
                // These are the UI-visible options
                $uiOptions = ['Pending','Process','Success','Rejected'];
                foreach ($uiOptions as $opt):
                  // Mark selected if UI option matches current UI status
                  $selected = ($opt === $uiStatus) ? 'selected' : '';
              ?>
                <option value="<?= $opt ?>" <?= $selected ?>><?= $opt ?></option>
              <?php endforeach; ?>
            </select>
            <input class="input" name="reason" placeholder="নোট/কারণ (ঐচ্ছিক)" style="max-width:200px">
            <button class="btn ok" type="submit">সেভ</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include 'footer.php'; ?>
