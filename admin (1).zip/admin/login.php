<?php
include 'config.php';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $pass  = $_POST['password'] ?? '';

  // Validate email format
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $err = 'ভুল ইমেইল ফরম্যাট';
  } elseif ($email === '' || $pass === '') {
    $err = 'ইমেইল ও পাসওয়ার্ড দিন';
  } else {
    $st = $pdo->prepare("SELECT * FROM admins WHERE email=?");
    $st->execute([$email]);
    $a = $st->fetch();
    if ($a && password_verify($pass, $a['password'])) {
      $_SESSION['admin_id'] = $a['id'];
      $_SESSION['admin_email'] = $a['email'];
      header("Location: index.php");
      exit;
    } else {
      $err = 'ভুল ইমেইল/পাসওয়ার্ড';
    }
  }
}
?>
<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login</title>
<link rel="stylesheet" href="assets/admin.css">
<style>
  body{ justify-content:center; align-items:center; }
  .login{ width:100%; max-width:420px; }
  .card{ background:#0f1e35; border:1px solid var(--border); border-radius:14px; padding:16px }
  .title{ font-weight:800; margin:0 0 12px }
  .err{ background:#3a0b0b; color:#ffc7c7; padding:8px 10px; border-radius:10px; margin-bottom:10px }
  label{ display:block; margin-bottom:6px; color:var(--muted) }
</style>
</head><body>
<div class="login">
  <div class="card">
    <h3 class="title">Admin Login</h3>
    <?php if ($err): ?><div class="err"><?= htmlspecialchars($err) ?></div><?php endif; ?>
    <form method="post">
      <label>ইমেইল</label>
      <input class="input" type="email" name="email" required>
      <div style="height:10px"></div>
      <label>পাসওয়ার্ড</label>
      <input class="input" type="password" name="password" required>
      <div style="height:12px"></div>
      <button class="btn primary" type="submit">লগ ইন</button>
    </form>
  </div>
</div>
</body></html>
