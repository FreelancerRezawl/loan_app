<?php require __DIR__.'/auth.php'; ?>
<!doctype html>
<html lang="bn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>WBLB Admin</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
  <aside class="sidebar">
    <div class="brand">
      <div style="width:38px; height:38px; border-radius:50%; background:linear-gradient(45deg, var(--brand), var(--ok)); display:flex; align-items:center; justify-content:center; font-weight:800; color:#fff; font-size:14px;">W</div>
      <div class="t">WBLB Admin</div>
    </div>
    <nav class="nav">
      <a href="index.php"         class="<?= basename($_SERVER['PHP_SELF'])==='index.php'?'active':'' ?>">🏠 ড্যাশবোর্ড</a>
      <a href="users.php"         class="<?= basename($_SERVER['PHP_SELF'])==='users.php'?'active':'' ?>">👥 ইউজার</a>
      <a href="loan_settings.php" class="<?= basename($_SERVER['PHP_SELF'])==='loan_settings.php'?'active':'' ?>">💳 লোন প্ল্যান</a>
      <a href="loan_requests.php" class="<?= basename($_SERVER['PHP_SELF'])==='loan_requests.php'?'active':'' ?>">📩 লোন রিকোয়েস্ট</a>
      <a href="documents.php"     class="<?= basename($_SERVER['PHP_SELF'])==='documents.php'?'active':'' ?>">🗂️ ডকুমেন্ট</a>
      <a href="reviews.php"       class="<?= basename($_SERVER['PHP_SELF'])==='reviews.php'?'active':'' ?>">💬 রিভিউ</a>
      <a href="content.php"       class="<?= basename($_SERVER['PHP_SELF'])==='content.php'?'active':'' ?>">🧩 কনটেন্ট</a>
      <a href="logout.php">↩️ লগ আউট</a>
    </nav>
  </aside>
  <main class="main">
