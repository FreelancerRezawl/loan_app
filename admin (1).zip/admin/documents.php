<?php 
include 'header.php'; 
include 'config.php';

$rows = $pdo->query("
  SELECT u.id, u.name, u.mobile, d.nid_front, d.nid_back, d.user_photo, d.nominee_photo, d.signature
  FROM users u
  LEFT JOIN documents d ON d.user_id = u.id
  ORDER BY u.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

function thumb($path) {
  if (!$path) return '—';
  // শুধু ফাইলনেম রেখে পুরো ডোমেইন সহ লিংক তৈরি
  $file = basename($path);
  return '<a class="btn ghost" href="https://bdworldbank.com/uploads/'.htmlspecialchars($file).'" target="_blank">দেখুন</a>';
}
?>
<div class="panel">
  <h3 class="h">ইউজার ডকুমেন্ট</h3>
  <table class="table">
    <thead>
      <tr>
        <th>ইউজার</th>
        <th>ইউজার ছবি</th>
        <th>NID ফ্রন্ট</th>
        <th>NID ব্যাক</th>
        <th>নমিনি ছবি</th>
        <th>স্বাক্ষর</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr>
        <td>
          <div style="font-weight:800"><?= htmlspecialchars($r['name'] ?? '—') ?></div>
          <small>ID #<?= (int)$r['id'] ?> • <?= htmlspecialchars($r['mobile'] ?? '—') ?></small>
        </td>
        <td><?= thumb($r['user_photo']) ?></td>
        <td><?= thumb($r['nid_front']) ?></td>
        <td><?= thumb($r['nid_back']) ?></td>
        <td><?= thumb($r['nominee_photo']) ?></td>
        <td><?= thumb($r['signature']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include 'footer.php'; ?>
